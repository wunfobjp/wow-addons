print("|cff00ff00[调试] 成功读取了修改后的Lua文件！|r")
local addonName, addonTable = ...
local GetItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo

-- ==========================================
-- 1. 弹窗二次确认注册
-- ==========================================
StaticPopupDialogs["EPIC_LOOT_TRACKER_CONFIRM_DELETE"] = {
    text = "确定要删除 [%s] 的拾取记录吗？",
    button1 = "确定",
    button2 = "取消",
    OnAccept = function(self, data)
        if data and data.dbIndex and EpicLootTrackerDB[data.dbIndex] then
            table.remove(EpicLootTrackerDB, data.dbIndex)
            EpicLootTracker_BuildData()
            EpicLootTracker_UpdateUI()
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["EPIC_LOOT_TRACKER_CONFIRM_CLEAR"] = {
    text = "|cffFF0000确定要清空当前列表显示的所有记录吗？|r\n此操作无法撤销！",
    button1 = "确定清空",
    button2 = "取消",
    OnAccept = function(self)
        if mainFrame.currentTimeFilter == "ALL" and mainFrame.searchBox:GetText() == "" then
            table.wipe(EpicLootTrackerDB)
        else
            for i = #mainFrame.filteredData, 1, -1 do
                local dbIdx = mainFrame.filteredData[i].dbIndex
                table.remove(EpicLootTrackerDB, dbIdx)
            end
        end
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["EPIC_LOOT_TRACKER_ADD_WHITELIST"] = {
    text = "请输入物品ID，或按住Shift将物品贴入框内：",
    button1 = "添加",
    button2 = "取消",
    hasEditBox = true,
    OnAccept = function(self)
        local text = self.editBox:GetText()
        local itemID = tonumber(string.match(text, "item:(%d+)")) or tonumber(text)
        if itemID then
            EpicLootTrackerConfig.whitelist = EpicLootTrackerConfig.whitelist or {}
            EpicLootTrackerConfig.whitelist[itemID] = true
            if EpicLootTracker_UpdateWhitelistUI then EpicLootTracker_UpdateWhitelistUI() end
            print("|cff00ff00[EpicLootTracker] 物品已被加入白名单！|r")
        else
            print("|cffff0000[EpicLootTracker] 格式错误，请贴入物品链接或输入纯数字ID。|r")
        end
    end,
    EditBoxOnEnterPressed = function(self)
        local parent = self:GetParent()
        StaticPopupDialogs["EPIC_LOOT_TRACKER_ADD_WHITELIST"].OnAccept(parent)
        parent:Hide()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

-- ==========================================
-- 2. UI 界面构建
-- ==========================================
mainFrame = CreateFrame("Frame", "EpicLootTrackerFrame", UIParent, "BasicFrameTemplateWithInset")
mainFrame:SetSize(980, 520)
mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
mainFrame:Hide()
mainFrame:SetMovable(true)
mainFrame:EnableMouse(true)
mainFrame:RegisterForDrag("LeftButton")
mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing)

mainFrame.title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.title:SetPoint("CENTER", mainFrame.TitleBg, "CENTER", 0, 0)
mainFrame.title:SetText("高级战利品拾取记录")

mainFrame.filteredData = {}
mainFrame.currentTimeFilter = "ALL"

-- --- 顶部控制栏区 ---
-- 1. 搜索框
mainFrame.searchBox = CreateFrame("EditBox", nil, mainFrame, "InputBoxTemplate")
mainFrame.searchBox:SetSize(160, 22)
mainFrame.searchBox:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 25, -35)
mainFrame.searchBox:SetAutoFocus(false)
mainFrame.searchBox.label = mainFrame.searchBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
mainFrame.searchBox.label:SetPoint("BOTTOMLEFT", mainFrame.searchBox, "TOPLEFT", -5, 2)
mainFrame.searchBox.label:SetText("模糊搜索 (物品/地点/角色):")
mainFrame.searchBox:SetScript("OnTextChanged", function(self)
-- ================= 新增：白名单管理按钮与侧边面板 =================
mainFrame.whitelistBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
mainFrame.whitelistBtn:SetSize(90, 22)
mainFrame.whitelistBtn:SetPoint("LEFT", mainFrame.searchBox, "RIGHT", 15, 0)
mainFrame.whitelistBtn:SetText("白名单管理")

-- 白名单面板 (作为子窗口依附在主界面右侧)
mainFrame.wlPanel = CreateFrame("Frame", nil, mainFrame, "BasicFrameTemplateWithInset")
mainFrame.wlPanel:SetSize(280, 480)
mainFrame.wlPanel:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 5, 0) 
mainFrame.wlPanel:Hide()
mainFrame.wlPanel.title = mainFrame.wlPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.wlPanel.title:SetPoint("CENTER", mainFrame.wlPanel.TitleBg, "CENTER", 0, 0)
mainFrame.wlPanel.title:SetText("蓝装白名单")

mainFrame.whitelistBtn:SetScript("OnClick", function()
    if mainFrame.wlPanel:IsShown() then
        mainFrame.wlPanel:Hide()
    else
        mainFrame.wlPanel:Show()
        EpicLootTracker_UpdateWhitelistUI()
    end
end)

local wlAddBtn = CreateFrame("Button", nil, mainFrame.wlPanel, "UIPanelButtonTemplate")
wlAddBtn:SetSize(120, 24)
wlAddBtn:SetPoint("TOP", mainFrame.wlPanel, "TOP", 0, -35)
wlAddBtn:SetText("添加新物品")
wlAddBtn:SetScript("OnClick", function()
    StaticPopup_Show("EPIC_LOOT_TRACKER_ADD_WHITELIST")
end)

-- 白名单滚动列表
local wlScroll = CreateFrame("ScrollFrame", "EpicLootTrackerWLScroll", mainFrame.wlPanel, "FauxScrollFrameTemplate")
wlScroll:SetPoint("TOPLEFT", mainFrame.wlPanel, "TOPLEFT", 10, -70)
wlScroll:SetPoint("BOTTOMRIGHT", mainFrame.wlPanel, "BOTTOMRIGHT", -30, 10)

mainFrame.wlPanel.rows = {}
local WL_ROW_COUNT = 18
for i = 1, WL_ROW_COUNT do
    local row = CreateFrame("Frame", nil, mainFrame.wlPanel)
    row:SetSize(230, 22)
    if i == 1 then row:SetPoint("TOPLEFT", wlScroll, "TOPLEFT", 0, 0)
    else row:SetPoint("TOPLEFT", mainFrame.wlPanel.rows[i-1], "BOTTOMLEFT", 0, -2) end

    row.itemFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.itemFS:SetPoint("LEFT", row, "LEFT", 5, 0)
    row.itemFS:SetWidth(170)
    row.itemFS:SetJustifyH("LEFT")
    row.itemFS:SetWordWrap(false)
    
    row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.delBtn:SetSize(45, 20)
    row.delBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
    row.delBtn:SetText("移除")
    row.delBtn:SetScript("OnClick", function()
        if row.itemID and EpicLootTrackerConfig.whitelist then
            EpicLootTrackerConfig.whitelist[row.itemID] = nil
            EpicLootTracker_UpdateWhitelistUI()
        end
    end)
    
    -- 支持鼠标悬停查看装备属性
    row:EnableMouse(true)
    row:SetScript("OnEnter", function(self)
        if row.itemID then
            local _, link = GetItemInfo(row.itemID)
            if link then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetHyperlink(link)
                GameTooltip:Show()
            end
        end
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    mainFrame.wlPanel.rows[i] = row
end

function EpicLootTracker_UpdateWhitelistUI()
    if not mainFrame.wlPanel:IsShown() then return end
    
    local wlData = {}
    if EpicLootTrackerConfig and EpicLootTrackerConfig.whitelist then
        for id, _ in pairs(EpicLootTrackerConfig.whitelist) do
            table.insert(wlData, id)
        end
    end
    
    FauxScrollFrame_Update(wlScroll, #wlData, WL_ROW_COUNT, 22)
    local offset = FauxScrollFrame_GetOffset(wlScroll)
    
    for i = 1, WL_ROW_COUNT do
        local idx = offset + i
        local row = mainFrame.wlPanel.rows[i]
        if idx <= #wlData then
            local itemID = wlData[idx]
            row.itemID = itemID
            local _, itemLink = GetItemInfo(itemID)
            if itemLink then
                row.itemFS:SetText(itemLink)
            else
                row.itemFS:SetText("物品ID: " .. itemID)
            end
            row:Show()
        else
            row.itemID = nil
            row:Hide()
        end
    end
end

wlScroll:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, 22, EpicLootTracker_UpdateWhitelistUI)
end)
-- ================================================================
    EpicLootTracker_BuildData()
    EpicLootTracker_UpdateUI()
end)

-- 2. 是否记录蓝装开关
mainFrame.chkRecordBlue = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkRecordBlue:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -140, -35)
mainFrame.chkRecordBlue.text = mainFrame.chkRecordBlue:CreateFontString(nil, "OVERLAY", "GameFontNormal")
mainFrame.chkRecordBlue.text:SetPoint("LEFT", mainFrame.chkRecordBlue, "RIGHT", 2, 1)
mainFrame.chkRecordBlue.text:SetText("记录精良(蓝装)")
mainFrame.chkRecordBlue:SetScript("OnClick", function(self)
    EpicLootTrackerConfig.recordBlue = self:GetChecked()
end)

-- 3. 是否记录单人拾取开关
mainFrame.chkRecordSolo = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkRecordSolo:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -290, -35)
mainFrame.chkRecordSolo.text = mainFrame.chkRecordSolo:CreateFontString(nil, "OVERLAY", "GameFontNormal")
mainFrame.chkRecordSolo.text:SetPoint("LEFT", mainFrame.chkRecordSolo, "RIGHT", 2, 1)
mainFrame.chkRecordSolo.text:SetText("记录单人拾取")
mainFrame.chkRecordSolo:SetScript("OnClick", function(self)
    EpicLootTrackerConfig.recordSolo = self:GetChecked()
end)

-- 4. 显示品质与类型过滤
mainFrame.chkShowPurple = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowPurple:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -70)
mainFrame.chkShowPurple:SetChecked(true)
mainFrame.chkShowPurple.text = mainFrame.chkShowPurple:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowPurple.text:SetPoint("LEFT", mainFrame.chkShowPurple, "RIGHT", 2, 1)
mainFrame.chkShowPurple.text:SetText("显示紫装")
mainFrame.chkShowPurple:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

mainFrame.chkShowBlue = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowBlue:SetPoint("LEFT", mainFrame.chkShowPurple.text, "RIGHT", 10, -1)
mainFrame.chkShowBlue:SetChecked(true)
mainFrame.chkShowBlue.text = mainFrame.chkShowBlue:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowBlue.text:SetPoint("LEFT", mainFrame.chkShowBlue, "RIGHT", 2, 1)
mainFrame.chkShowBlue.text:SetText("显示蓝装")
mainFrame.chkShowBlue:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

-- 新增：只显示装备开关
mainFrame.chkShowEquip = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowEquip:SetPoint("LEFT", mainFrame.chkShowBlue.text, "RIGHT", 15, 0)
mainFrame.chkShowEquip:SetChecked(true)
mainFrame.chkShowEquip.text = mainFrame.chkShowEquip:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowEquip.text:SetPoint("LEFT", mainFrame.chkShowEquip, "RIGHT", 2, 1)
mainFrame.chkShowEquip.text:SetText("显示装备")
mainFrame.chkShowEquip:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

-- 新增：只显示图纸开关
mainFrame.chkShowRecipe = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowRecipe:SetPoint("LEFT", mainFrame.chkShowEquip.text, "RIGHT", 10, 0)
mainFrame.chkShowRecipe:SetChecked(true)
mainFrame.chkShowRecipe.text = mainFrame.chkShowRecipe:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowRecipe.text:SetPoint("LEFT", mainFrame.chkShowRecipe, "RIGHT", 2, 1)
mainFrame.chkShowRecipe.text:SetText("显示图纸")
mainFrame.chkShowRecipe:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

-- 5. 快捷日期过滤按钮
local timeFilters = {
    { key = "ALL", label = "全部" },
    { key = "TODAY", label = "今天" },
    { key = "3DAYS", label = "近3天" },
    { key = "1WEEK", label = "一周" },
    { key = "HALFMONTH", label = "半个月" },
    { key = "1MONTH", label = "一个月" }
}
local filterBtns = {}
for i, filter in ipairs(timeFilters) do
    local btn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
    btn:SetSize(65, 22)
    if i == 1 then
        -- 将时间按钮的锚点挂在“显示图纸”的右侧
        btn:SetPoint("LEFT", mainFrame.chkShowRecipe.text, "RIGHT", 30, 0)
    else
        btn:SetPoint("LEFT", filterBtns[i-1], "RIGHT", 5, 0)
    end
    btn:SetText(filter.label)
    btn:SetScript("OnClick", function()
        mainFrame.currentTimeFilter = filter.key
        for _, b in ipairs(filterBtns) do b:Enable() end
        btn:Disable()
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end)
    filterBtns[i] = btn
end
filterBtns[1]:Disable()

-- --- 表头排版定义 ---
local headers = {
    { title = "物品名", width = 175, xOffset = 20 },
    { title = "装等", width = 40, xOffset = 195 },
    { title = "需求", width = 40, xOffset = 240 },   -- 新增：穿戴需求列
    { title = "时间", width = 135, xOffset = 290 },
    { title = "地点", width = 145, xOffset = 430 },
    { title = "角色-服务器", width = 290, xOffset = 580 }, -- 右移并加宽，防止截断
    { title = "操作", width = 50, xOffset = 880 },   -- 按钮推至右侧边缘
}

for _, h in ipairs(headers) do
    local font = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    font:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", h.xOffset, -105)
    font:SetWidth(h.width)
    font:SetJustifyH("LEFT")
    font:SetText(h.title)
end

-- 滚动列表
local scrollFrame = CreateFrame("ScrollFrame", "EpicLootTrackerScroll", mainFrame, "FauxScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -125)
scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -35, 45)

local ROW_COUNT = 14
mainFrame.rows = {}
for i = 1, ROW_COUNT do
    local row = CreateFrame("Frame", nil, mainFrame)
    row:SetSize(930, 24)
    if i == 1 then row:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0)
    else row:SetPoint("TOPLEFT", mainFrame.rows[i-1], "BOTTOMLEFT", 0, -1) end

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.03 or 0.08)

   -- 物品名缩短宽度
    row.itemText = CreateFrame("Frame", nil, row)
    row.itemText:SetSize(180, 20)
    row.itemText:SetPoint("LEFT", row, "LEFT", 5, 0)
    row.itemFS = row.itemText:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.itemFS:SetAllPoints()
    row.itemFS:SetJustifyH("LEFT")
    row.itemFS:SetWordWrap(false)

    row.itemText:EnableMouse(true)
    row.itemText:SetScript("OnEnter", function(self)
        if row.itemLink then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetHyperlink(row.itemLink)
            GameTooltip:Show()
        end
    end)
    row.itemText:SetScript("OnLeave", function() GameTooltip:Hide() end)
    row.itemText:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" and IsShiftKeyDown() and row.itemLink then
            ChatEdit_InsertLink(row.itemLink)
        end
    end)

    -- 装等显示
    row.ilvlText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.ilvlText:SetPoint("LEFT", row, "LEFT", 190, 0)
    row.ilvlText:SetWidth(40)
    row.ilvlText:SetJustifyH("CENTER")

    -- 新增：需求等级显示
    row.reqLevelText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.reqLevelText:SetPoint("LEFT", row, "LEFT", 235, 0)
    row.reqLevelText:SetWidth(40)
    row.reqLevelText:SetJustifyH("CENTER")

    -- 时间显示
    row.timeText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.timeText:SetPoint("LEFT", row, "LEFT", 280, 0)
    row.timeText:SetWidth(140)
    row.timeText:SetJustifyH("LEFT")

    -- 地点显示
    row.locationText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.locationText:SetPoint("LEFT", row, "LEFT", 425, 0)
    row.locationText:SetWidth(145)
    row.locationText:SetJustifyH("LEFT")
    row.locationText:SetWordWrap(false)

    -- 角色-服务器显示 (X平移到575，宽度大幅扩展，避免截断)
    row.playerText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.playerText:SetPoint("LEFT", row, "LEFT", 575, 0)
    row.playerText:SetWidth(290) 
    row.playerText:SetJustifyH("LEFT")
    row.playerText:SetWordWrap(false)

    -- 删除按钮 (推移到880，缩小与角色栏的差距)
    row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.delBtn:SetSize(45, 20)
    row.delBtn:SetPoint("LEFT", row, "LEFT", 880, 0)
    row.delBtn:SetText("删除")
    row.delBtn:SetScript("OnClick", function()
        if row.dbIndex then
            local dialog = StaticPopup_Show("EPIC_LOOT_TRACKER_CONFIRM_DELETE", row.itemNameOnly or "该物品")
            if dialog then dialog.data = { dbIndex = row.dbIndex } end
        end
    end)

    mainFrame.rows[i] = row
end

local clearAllBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
clearAllBtn:SetSize(110, 24)
clearAllBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 12)
clearAllBtn:SetText("清空当前列表")
clearAllBtn:SetScript("OnClick", function()
    if #mainFrame.filteredData > 0 then
        StaticPopup_Show("EPIC_LOOT_TRACKER_CONFIRM_CLEAR")
    end
end)

-- ==========================================
-- 3. 数据过滤与排序引擎
-- ==========================================
function EpicLootTracker_BuildData()
    -- 0. 核心修复：强制对底层数据库进行时间倒序（最新的在前）排序
    table.sort(EpicLootTrackerDB, function(a, b)
        return (a.timestamp or 0) > (b.timestamp or 0)
    end)

    table.wipe(mainFrame.filteredData)
    local searchText = mainFrame.searchBox:GetText():lower()
    local currentTimestamp = time()
    
    -- 精确获取当天的零点时间戳
    local t_date = date("*t")
    local todayMidnight = time({year=t_date.year, month=t_date.month, day=t_date.day, hour=0, min=0, sec=0})
    
    -- 获取所有复选框的状态
    local showPurple = mainFrame.chkShowPurple:GetChecked()
    local showBlue = mainFrame.chkShowBlue:GetChecked()
    local showEquip = mainFrame.chkShowEquip:GetChecked()
    local showRecipe = mainFrame.chkShowRecipe:GetChecked()

    for i, data in ipairs(EpicLootTrackerDB) do
        local match = true
        
        -- 1. 品质过滤
        local rarity = data.rarity or 4
        if not ((showPurple and rarity >= 4) or (showBlue and rarity == 3)) then
            match = false
        end

        -- 2. 装备与图纸分类过滤
        if match then
            local isRecipe = false
            
            -- 获取物品分类 (classID = 9 表示配方/图纸)
            local _, _, _, _, _, _, _, _, _, _, _, classID = GetItemInfo(data.itemLink)
            
            if classID then
                if classID == 9 then isRecipe = true end
            else
                -- 兜底：如果游戏未缓存该物品，通过名字前缀文本进行模糊判断
                local itemName = string.match(data.itemLink or "", "%[(.-)%]") or ""
                if string.find(itemName, "设计图：") or string.find(itemName, "图样：") or 
                   string.find(itemName, "公式：") or string.find(itemName, "结构图：") or 
                   string.find(itemName, "指南：") or string.find(itemName, "图纸：") then
                    isRecipe = true
                end
            end
            
            -- 根据状态进行拦截
            if isRecipe and not showRecipe then
                match = false
            elseif not isRecipe and not showEquip then
                match = false
            end
        end

       -- 3. 搜索过滤
        if match and searchText ~= "" then
            -- 拼接搜索字符串时，加入 data.recorder。
            -- 这样你登录B角色时，只需搜索A角色的名字，就能查出A记录的所有历史掉落。
            local searchStr = string.lower((data.itemLink or "") .. (data.location or "") .. (data.player or "") .. (data.recorder or ""))
            if not string.find(searchStr, searchText, 1, true) then
                match = false
            end
        end

        -- 4. 时间过滤
        if match and mainFrame.currentTimeFilter ~= "ALL" then
            local recTime = data.timestamp or 0 
            if recTime > 0 then
                local diff = currentTimestamp - recTime
                local filter = mainFrame.currentTimeFilter
                if filter == "TODAY" and recTime < todayMidnight then match = false
                elseif filter == "3DAYS" and diff > 3*24*3600 then match = false
                elseif filter == "1WEEK" and diff > 7*24*3600 then match = false
                elseif filter == "HALFMONTH" and diff > 15*24*3600 then match = false
                elseif filter == "1MONTH" and diff > 30*24*3600 then match = false
                end
            else
                match = false 
            end
        end

        if match then
            table.insert(mainFrame.filteredData, { dbIndex = i, record = data })
        end
    end
end

function EpicLootTracker_UpdateUI()
    if not mainFrame:IsShown() then return end
    local totalItems = #mainFrame.filteredData
    FauxScrollFrame_Update(scrollFrame, totalItems, ROW_COUNT, 24)

    local offset = FauxScrollFrame_GetOffset(scrollFrame)
    for i = 1, ROW_COUNT do
        local idx = offset + i
        local row = mainFrame.rows[i]

        if idx <= totalItems then
            local dbWrapper = mainFrame.filteredData[idx]
            local data = dbWrapper.record
            row.dbIndex = dbWrapper.dbIndex
            row.itemLink = data.itemLink
            row.itemNameOnly = string.match(data.itemLink, "%[(.-)%]") or "未知装备"

           row.itemFS:SetText(data.itemLink)
            
            -- ================= 动态获取装等与需求等级 =================
            -- API 返回值中，第4个是装等，第5个是穿戴要求等级
            local _, _, _, itemLevel, itemMinLevel = GetItemInfo(data.itemLink)
            
            local displayIlvl = itemLevel or data.itemLevel or 0
            local displayReqLvl = itemMinLevel or data.reqLevel or 0
            
            -- 显示装等
            if displayIlvl > 1 then
                row.ilvlText:SetText(displayIlvl)
            else
                row.ilvlText:SetText("-")
            end

            -- 显示需求等级
            if displayReqLvl > 1 then
                row.reqLevelText:SetText(displayReqLvl)
            else
                row.reqLevelText:SetText("-")
            end
            -- ==========================================================
            
            row.timeText:SetText(data.time)
            row.locationText:SetText(data.location)
            
            local classColor = "ffffffff"
            if data.className and RAID_CLASS_COLORS[data.className] then
                classColor = RAID_CLASS_COLORS[data.className].colorStr
            end
            row.playerText:SetText(string.format("|c%s%s|r", classColor, data.player))

            row:Show()
        else
            row.dbIndex = nil
            row:Hide()
        end
    end
end

scrollFrame:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, 24, EpicLootTracker_UpdateUI)
end)

-- ==========================================
-- 4. 事件监听与旧数据兼容升级
-- ==========================================
local eventHandler = CreateFrame("Frame")
eventHandler:RegisterEvent("ADDON_LOADED")
eventHandler:RegisterEvent("ENCOUNTER_LOOT_RECEIVED")
eventHandler:RegisterEvent("CHAT_MSG_LOOT")

local function FormatPlayerName(rawName)
    if not rawName or rawName == "" then return UnitName("player") .. "-" .. GetRealmName() end
    if not string.find(rawName, "-") then return rawName .. "-" .. GetRealmName() end
    return rawName
end

-- 注意：这里彻底移除了硬编码的 BlueItemWhitelist 数组，改为动态读取面板数据

local function RecordLoot(itemLink, playerName, className)
    if not itemLink then return end
    
    -- 提取第 4 个(装等) 和 第 5 个(需求等级) 返回值
    local _, _, itemRarity, itemLevel, itemMinLevel = GetItemInfo(itemLink)
    if not itemRarity or itemRarity < 3 then return end
    
    -- ================= 动态UI白名单拦截逻辑 =================
    if itemRarity == 3 and not EpicLootTrackerConfig.recordBlue then 
        local itemID = tonumber(string.match(itemLink, "item:(%d+)"))
        -- 改为读取 EpicLootTrackerConfig.whitelist
        if not (itemID and EpicLootTrackerConfig.whitelist and EpicLootTrackerConfig.whitelist[itemID]) then
            return -- 没开记录蓝装，且不在UI白名单内，直接丢弃
        end
    end

    local record = {
        itemLink = itemLink,
        rarity = itemRarity,
        itemLevel = itemLevel or 0, 
        reqLevel = itemMinLevel or 0, 
        timestamp = time(),
        time = date("%Y-%m-%d %H:%M:%S"),
        location = GetRealZoneText() or "未知区域",
        player = FormatPlayerName(playerName),
        className = className,
        recorder = UnitName("player")
    }

    table.insert(EpicLootTrackerDB, 1, record)
    if mainFrame:IsShown() then 
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI() 
    end
end

eventHandler:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local addon = ...
        if addon == addonName then
            EpicLootTrackerDB = EpicLootTrackerDB or {}
            
            -- ==========================================
            -- ★ 旧数据无缝升级模块 ★
            -- ==========================================
            local currentYear = tonumber(date("%Y"))
            for _, data in ipairs(EpicLootTrackerDB) do
                -- 1. 补全缺失的品质标识 (默认按紫装处理)
                if not data.rarity then data.rarity = 4 end
                
                -- 2. 补全年份和底层时间戳
                if not data.timestamp then
                    if data.time then
                        -- 如果是类似 "07-25 10:14:14" 的旧格式
                        local mo, d, h, m, s = string.match(data.time, "^(%d%d)%-(%d%d) (%d%d):(%d%d):(%d%d)$")
                        if mo then
                            -- 逆向生成时间戳
                            data.timestamp = time({year=currentYear, month=tonumber(mo), day=tonumber(d), hour=tonumber(h), min=tonumber(m), sec=tonumber(s)})
                            -- 在界面字符串前面强制拼上年份
                            data.time = string.format("%04d-%02d-%02d %02d:%02d:%02d", currentYear, tonumber(mo), tonumber(d), tonumber(h), tonumber(m), tonumber(s))
                        else
                            -- 无法识别的异常格式直接赋当前时间
                            data.timestamp = time()
                        end
                    else
                        data.timestamp = time()
                        data.time = date("%Y-%m-%d %H:%M:%S", data.timestamp)
                    end
                end
            end
            
            -- 初始化 Config 及向前兼容
            EpicLootTrackerConfig = EpicLootTrackerConfig or {}
            if EpicLootTrackerConfig.recordBlue == nil then EpicLootTrackerConfig.recordBlue = false end
            if EpicLootTrackerConfig.recordSolo == nil then EpicLootTrackerConfig.recordSolo = false end
         
            -- 初始化默认白名单数据库
            if not EpicLootTrackerConfig.whitelist then
                EpicLootTrackerConfig.whitelist = {
                    [9425] = true, -- 厄运钟摆
                    [9423] = true, -- 烈焰之父
                    [9431] = true, -- 教宗圆帽
                    [9429] = true, -- 矿工帽
                }
            end
            
            mainFrame.chkRecordBlue:SetChecked(EpicLootTrackerConfig.recordBlue)
            mainFrame.chkRecordSolo:SetChecked(EpicLootTrackerConfig.recordSolo)
        end

    elseif event == "ENCOUNTER_LOOT_RECEIVED" then
        if not IsInGroup() and not EpicLootTrackerConfig.recordSolo then return end
        local encounterID, itemID, itemLink, quantity, playerName, className = ...
        RecordLoot(itemLink, playerName, className)

    elseif event == "CHAT_MSG_LOOT" then
        if not IsInGroup() and not EpicLootTrackerConfig.recordSolo then return end
        local text, rawPlayer = ...
        local itemLink = string.match(text, "(|c%x+|Hitem:.-|h%[.-%] |h|r)")
        if itemLink then
            if string.find(itemLink:lower(), "|cff0070dd") or string.find(itemLink:lower(), "|cffa335ee") then
                RecordLoot(itemLink, rawPlayer, nil)
            end
        end
    end
end)

-- ==========================================
-- 旧数据迁移转换工具 (一次性使用)
-- ==========================================
SLASH_ELTCONVERT1 = "/eltconvert"
SlashCmdList["ELTCONVERT"] = function()
    -- 把你所有的旧数据全部粘贴到大括号里：
    local oldDataList = {
        "1784874654#0#553#1#我爱唱歌一-日落沼泽#8#1#item:23632::::::::80:65::1::1:28:1694:::::",
        "1784878965#0#553#1#歌唱命运爱我#2#1#item:24305::::::::80:65::1::1:28:2927:::::",
        "1784893985#0#553#1#我爱唱歌一-克尔苏加德#5#1#item:23637::::::::80:65::1::1:28:1694:::::",
        "1784907772#0#553#1#我爱唱歌一-日落沼泽#8#1#item:31339::::::::80:65::1:1:6660:2:9:16:28:1694:::::",
        "1784908595#0#553#1#我爱唱歌一-日落沼泽#8#1#item:23630::::::::80:65::1::1:28:1694:::::",
        "1784909213#0#553#1#歌唱命运爱我#2#1#item:31334::::::::80:65::1:1:6661:2:9:80:28:2927:::::",
        "1784943027#0#553#1#歌唱命运爱我#2#1#item:31321::::::::80:65::1:1:6660:2:9:80:28:2927:::::",
        "1784945176#0#553#1#我爱唱歌一-艾莫莉丝#9#1#item:31328::::::::80:65::1:1:6660:2:9:16:28:1694:::::",
        "1784945654#0#553#1#歌唱命运爱我#2#1#item:23622::::::::80:65::1::1:28:2927:::::",
        "1784995576#0#553#1#我爱唱歌一-艾莫莉丝#9#1#item:29729::::::::80:65::1::1:28:1694:::::",
    }
    
    -- 下面的逻辑代码保持不变...
    local count = 0
    for _, line in ipairs(oldDataList) do
        -- 按照 # 分割旧数据字符串
        local tsStr, _, mapIDStr, _, playerRaw, classIDStr, _, itemString = strsplit("#", line, 8)
        
        local timestamp = tonumber(tsStr) or time()
        local classID = tonumber(classIDStr)
        
        -- 1. 解析职业代码 (例如: 2=圣骑士, 8=法师)
        local className = "UNKNOWN"
        if classID then
            local _, classFile = GetClassInfo(classID)
            if classFile then className = classFile end
        end
        
        -- 2. 时间戳格式化
        local timeStr = date("%Y-%m-%d %H:%M:%S", timestamp)
        
        -- 3. 玩家名兼容处理 (如果没有服务器后缀则补齐)
        local player = playerRaw
        if player and not string.find(player, "-") then
            player = player .. "-" .. GetRealmName()
        end
        
        -- 4. 地图名称解析 (553 是生态船)
        local location = "未知区域"
        local mapID = tonumber(mapIDStr)
        if mapID == 553 then 
            location = "生态船" 
        elseif C_Map and C_Map.GetMapInfo then 
            local mapInfo = C_Map.GetMapInfo(mapID)
            if mapInfo then location = mapInfo.name end
        end

        -- 5. 通过客户端数据库查询真实的物品链接和品质
        local itemName, itemLink, itemRarity = GetItemInfo(itemString)
        
        -- 如果游戏缓存中存在该物品
        if itemLink then
            table.insert(EpicLootTrackerDB, {
                player = player,
                time = timeStr,
                className = className,
                location = location,
                timestamp = timestamp,
                itemLink = itemLink,
                rarity = itemRarity or 4,
            })
            count = count + 1
        else
            -- 偶尔客户端未缓存该物品时，生成一个占位链接（鼠标经过时游戏会自动请求数据修复它）
            print("|cffff0000[ELT] 物品缓存缺失: " .. itemString .. "，已使用占位符记录。|r")
            local fakeLink = string.format("|cffa335ee|H%s|h[未知装备:请悬停加载]|h|r", itemString)
            table.insert(EpicLootTrackerDB, {
                player = player,
                time = timeStr,
                className = className,
                location = location,
                timestamp = timestamp,
                itemLink = fakeLink,
                rarity = 4,
            })
            count = count + 1
        end
    end
    
    print(string.format("|cff00ff00[EpicLootTracker] 成功转换并导入了 %d 条历史记录！|r", count))
    
    -- 如果面板当前是打开的，强制刷新
    if mainFrame and mainFrame:IsShown() then
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end
end


-- ==========================================
-- 5. Slash 指令绑定
-- ==========================================
SLASH_EPICLOOTTRACKER1 = "/elt"
SLASH_EPICLOOTTRACKER2 = "/epicloot"
SlashCmdList["EPICLOOTTRACKER"] = function()
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        mainFrame:Show()
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end
end