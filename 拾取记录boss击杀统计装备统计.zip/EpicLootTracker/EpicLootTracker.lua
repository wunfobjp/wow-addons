print("|cff00ff00[调试] 成功读取了优化布局与插槽●显示的Lua文件！|r") 
local addonName, addonTable = ... 
local GetItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo 

-- 运行时 Boss 状态追踪
local currentBossName = nil 
local currentBossTime = 0 

-- ==========================================
-- 0. 物品额外属性（插槽●与第三属性）解析辅助函数
-- ==========================================
local EpicLootTooltipScan = nil 
local function GetItemExtraDetails(itemLink) 
    if not itemLink then return "-", "-" end 
    
    local socketCount = 0 
    local tertiaryMap = {} 
    
    local function parseLine(text) 
        if not text or text == "" then return end 
        
        if string.find(text, "装备：") or string.find(text, "装备:") or  
           string.find(text, "使用：") or string.find(text, "使用:") or 
           string.find(text, "Equip:") or string.find(text, "Use:") then 
            return 
        end 
        
        if string.find(text, "插槽") or string.find(text, "Socket") then 
            socketCount = socketCount + 1 
        end 
        
        if string.find(text, "加速") or string.find(text, "吸血") or string.find(text, "闪避") or string.find(text, "回避") or string.find(text, "永不磨损") or string.find(text, "不坏") or 
           string.find(text, "Speed") or string.find(text, "Leech") or string.find(text, "Avoidance") or string.find(text, "Indestructible") then 
            if string.find(text, "加速") or string.find(text, "Speed") then tertiaryMap["加速"] = true end 
            if string.find(text, "吸血") or string.find(text, "Leech") then tertiaryMap["吸血"] = true end 
            if string.find(text, "闪避") or string.find(text, "回避") or string.find(text, "Avoidance") then tertiaryMap["闪避"] = true end 
            if string.find(text, "永不磨损") or string.find(text, "不坏") or string.find(text, "Indestructible") then tertiaryMap["永不磨损"] = true end 
        end 
    end 
    
    if C_TooltipInfo and C_TooltipInfo.GetHyperlink then 
        local data = C_TooltipInfo.GetHyperlink(itemLink) 
        if data and data.lines then 
            for i = 2, #data.lines do 
                parseLine(data.lines[i].leftText) 
            end 
        end 
    else 
        if not EpicLootTooltipScan then 
            EpicLootTooltipScan = CreateFrame("GameTooltip", "EpicLootTooltipScan", nil, "GameTooltipTemplate") 
            EpicLootTooltipScan:SetOwner(UIParent, "ANCHOR_NONE") 
        end 
        EpicLootTooltipScan:ClearLines() 
        EpicLootTooltipScan:SetHyperlink(itemLink) 
        for i = 2, EpicLootTooltipScan:NumLines() do 
            local left = _G["EpicLootTooltipScanTextLeft" .. i] 
            if left then 
                parseLine(left:GetText()) 
            end 
        end 
    end 
    
    local socketStr = socketCount > 0 and string.format("|cff00ff00%s|r", string.rep("●", socketCount)) or "-" 
    
    local tertiaryList = {} 
    for k, _ in pairs(tertiaryMap) do 
        table.insert(tertiaryList, k) 
    end 
    local tertiaryStr = #tertiaryList > 0 and string.format("|cffff8000%s|r", table.concat(tertiaryList, "/")) or "-" 
    
    return socketStr, tertiaryStr 
end 

-- ==========================================
-- 1. 弹窗二次确认注册
-- ==========================================
StaticPopupDialogs["EPIC_LOOT_TRACKER_CONFIRM_DELETE"] = { 
    text = "确定要删除 [%s] 的拾取记录吗？", 
    button1 = "确定", 
    button2 = "取消", 
    OnAccept = function(self, data) 
        if data and data.dbIndex and EpicLootTrackerDB[data.dbIndex] then 
            table.remove(EpicLootTrackerDB, data.dbIndex) 
            EpicLootTracker_BuildData() 
            EpicLootTracker_UpdateUI() 
        end 
    end, 
    timeout = 0, 
    whileDead = true, 
    hideOnEscape = true, 
    preferredIndex = 3, 
} 

StaticPopupDialogs["EPIC_LOOT_TRACKER_CONFIRM_CLEAR"] = { 
    text = "|cffFF0000确定要清空当前列表显示的所有记录吗？|r\n此操作无法撤销！", 
    button1 = "确定清空", 
    button2 = "取消", 
    OnAccept = function(self) 
        if mainFrame.currentTimeFilter == "ALL" and mainFrame.searchBox:GetText() == "" then 
            table.wipe(EpicLootTrackerDB) 
        else 
            for i = #mainFrame.filteredData, 1, -1 do 
                local dbIdx = mainFrame.filteredData[i].dbIndex 
                table.remove(EpicLootTrackerDB, dbIdx) 
            end 
        end 
        EpicLootTracker_BuildData() 
        EpicLootTracker_UpdateUI() 
    end, 
    timeout = 0, 
    whileDead = true, 
    hideOnEscape = true, 
    preferredIndex = 3, 
} 

StaticPopupDialogs["EPIC_LOOT_TRACKER_ADD_WHITELIST"] = { 
    text = "请输入物品ID，或按住Shift将物品贴入框内：", 
    button1 = "添加", 
    button2 = "取消", 
    hasEditBox = true, 
    OnAccept = function(self) 
        local text = self.editBox:GetText() 
        local itemID = tonumber(string.match(text, "item:(%d+)")) or tonumber(text) 
        if itemID then 
            EpicLootTrackerConfig.whitelist = EpicLootTrackerConfig.whitelist or {} 
            EpicLootTrackerConfig.whitelist[itemID] = true 
            if EpicLootTracker_UpdateWhitelistUI then EpicLootTracker_UpdateWhitelistUI() end 
            print("|cff00ff00[EpicLootTracker] 物品已被加入白名单！|r") 
        else 
            print("|cffff0000[EpicLootTracker] 格式错误，请贴入物品链接或输入纯数字ID。|r") 
        end 
    end, 
    EditBoxOnEnterPressed = function(self) 
        local parent = self:GetParent() 
        StaticPopupDialogs["EPIC_LOOT_TRACKER_ADD_WHITELIST"].OnAccept(parent) 
        parent:Hide() 
    end, 
    timeout = 0, 
    whileDead = true, 
    hideOnEscape = true, 
    preferredIndex = 3, 
} 

-- ==========================================
-- 1.5 黑名单 UI 独立模块
-- ==========================================
local BlacklistFrame = nil 

local function UpdateBlacklistScroll(scrollChild) 
    for _, child in ipairs({scrollChild:GetChildren()}) do 
        child:Hide() 
        child:SetParent(nil) 
    end 

    local yOffset = -5 
    for itemID, _ in pairs(EpicLootTrackerConfig.blacklist or {}) do 
        local row = CreateFrame("Frame", nil, scrollChild) 
        row:SetSize(260, 25) 
        row:SetPoint("TOPLEFT", 10, yOffset) 

        local itemName, itemLink, itemRarity, _, _, _, _, _, _, itemIcon = GetItemInfo(itemID) 
        
        local icon = row:CreateTexture(nil, "ARTWORK") 
        icon:SetSize(20, 20) 
        icon:SetPoint("LEFT", 0, 0) 
        icon:SetTexture(itemIcon or "Interface\\Icons\\INV_Misc_QuestionMark") 

        local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
        nameText:SetPoint("LEFT", icon, "RIGHT", 8, 0) 
        nameText:SetText(itemLink or ("未知物品 (ID: " .. itemID .. ")")) 

        local removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate") 
        removeBtn:SetSize(50, 20) 
        removeBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0) 
        removeBtn:SetText("移除") 
        removeBtn:SetScript("OnClick", function() 
            EpicLootTrackerConfig.blacklist[itemID] = nil 
            print("|cff00ff00[EpicLootTracker]|r 已将 " .. (itemLink or itemID) .. " 移出黑名单。") 
            UpdateBlacklistScroll(scrollChild) 
        end) 
        yOffset = yOffset - 28 
    end 
    scrollChild:SetHeight(math.abs(yOffset) + 10) 
end 

local function CreateBlacklistManagerUI() 
    if BlacklistFrame then  
        BlacklistFrame:SetShown(not BlacklistFrame:IsShown()) 
        return  
    end 

    if not EpicLootTrackerConfig.blacklist then EpicLootTrackerConfig.blacklist = {} end 

    BlacklistFrame = CreateFrame("Frame", "EpicLootTrackerBlacklistUI", UIParent, "BasicFrameTemplateWithInset") 
    BlacklistFrame:SetSize(320, 400) 
    BlacklistFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0) 
    BlacklistFrame:SetMovable(true) 
    BlacklistFrame:EnableMouse(true) 
    BlacklistFrame:RegisterForDrag("LeftButton") 
    BlacklistFrame:SetScript("OnDragStart", BlacklistFrame.StartMoving) 
    BlacklistFrame:SetScript("OnDragStop", BlacklistFrame.StopMovingOrSizing) 
    BlacklistFrame:SetFrameStrata("DIALOG")  

    BlacklistFrame.title = BlacklistFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    BlacklistFrame.title:SetPoint("TOPLEFT", BlacklistFrame.TitleBg, "TOPLEFT", 5, -3) 
    BlacklistFrame.title:SetText("黑名单物品管理 (无视掉落)") 

    local inputBox = CreateFrame("EditBox", nil, BlacklistFrame, "InputBoxTemplate") 
    inputBox:SetSize(150, 20) 
    inputBox:SetPoint("TOPLEFT", BlacklistFrame, "TOPLEFT", 20, -35) 
    inputBox:SetAutoFocus(false) 
    inputBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end) 

    local scrollFrame = CreateFrame("ScrollFrame", nil, BlacklistFrame, "UIPanelScrollFrameTemplate") 
    scrollFrame:SetPoint("TOPLEFT", 10, -65) 
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10) 

    local scrollChild = CreateFrame("Frame", nil, scrollFrame) 
    scrollChild:SetSize(280, 100) 
    scrollFrame:SetScrollChild(scrollChild) 

    local addBtn = CreateFrame("Button", nil, BlacklistFrame, "UIPanelButtonTemplate") 
    addBtn:SetSize(60, 22) 
    addBtn:SetPoint("LEFT", inputBox, "RIGHT", 10, 0) 
    addBtn:SetText("添加") 
    addBtn:SetScript("OnClick", function() 
        local text = inputBox:GetText() 
        if not text or text == "" then return end 
        
        local itemID = tonumber(string.match(text, "item:(%d+)") or text) 
        if itemID then 
            C_Item.RequestLoadItemDataByID(itemID)  
            EpicLootTrackerConfig.blacklist[itemID] = true 
            inputBox:SetText("") 
            inputBox:ClearFocus() 
            
            C_Timer.After(0.2, function() 
                local _, link = GetItemInfo(itemID) 
                print("|cff00ff00[EpicLootTracker]|r 已将 " .. (link or itemID) .. " 加入黑名单。") 
                UpdateBlacklistScroll(scrollChild) 
            end) 
        else 
            print("|cffff0000[EpicLootTracker]|r 错误：请输入正确的物品 ID 或物品链接！") 
        end 
    end) 

    BlacklistFrame:SetScript("OnShow", function() 
        UpdateBlacklistScroll(scrollChild) 
    end) 
end 

-- ==========================================
-- 1.6 Boss 白名单 UI 独立模块
-- ==========================================
local BossWhitelistFrame = nil 

local function CreateBossWhitelistUI() 
    if BossWhitelistFrame then 
        BossWhitelistFrame:SetShown(not BossWhitelistFrame:IsShown()) 
        return 
    end 

    BossWhitelistFrame = CreateFrame("Frame", "EpicLootTrackerBossWLUI", UIParent, "BasicFrameTemplateWithInset") 
    BossWhitelistFrame:SetSize(320, 420) 
    BossWhitelistFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0) 
    BossWhitelistFrame:SetMovable(true) 
    BossWhitelistFrame:EnableMouse(true) 
    BossWhitelistFrame:RegisterForDrag("LeftButton") 
    BossWhitelistFrame:SetScript("OnDragStart", BossWhitelistFrame.StartMoving) 
    BossWhitelistFrame:SetScript("OnDragStop", BossWhitelistFrame.StopMovingOrSizing) 
    BossWhitelistFrame:SetFrameStrata("DIALOG") 

    BossWhitelistFrame.title = BossWhitelistFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    BossWhitelistFrame.title:SetPoint("TOPLEFT", BossWhitelistFrame.TitleBg, "TOPLEFT", 5, -3) 
    BossWhitelistFrame.title:SetText("Boss 白名单管理 (仅统计名单内)") 

    local enableChk = CreateFrame("CheckButton", nil, BossWhitelistFrame, "UICheckButtonTemplate") 
    enableChk:SetPoint("TOPLEFT", BossWhitelistFrame, "TOPLEFT", 15, -30) 
    enableChk.text = enableChk:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
    enableChk.text:SetPoint("LEFT", enableChk, "RIGHT", 2, 1) 
    enableChk.text:SetText("启用 Boss 白名单过滤") 
    enableChk:SetChecked(EpicLootTrackerConfig.enableBossWhitelist) 
    enableChk:SetScript("OnClick", function(self) 
        EpicLootTrackerConfig.enableBossWhitelist = self:GetChecked() 
    end) 

    local inputBox = CreateFrame("EditBox", nil, BossWhitelistFrame, "InputBoxTemplate") 
    inputBox:SetSize(150, 20) 
    inputBox:SetPoint("TOPLEFT", BossWhitelistFrame, "TOPLEFT", 20, -65) 
    inputBox:SetAutoFocus(false) 
    inputBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end) 

    local scrollFrame = CreateFrame("ScrollFrame", nil, BossWhitelistFrame, "UIPanelScrollFrameTemplate") 
    scrollFrame:SetPoint("TOPLEFT", 10, -95) 
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10) 

    local scrollChild = CreateFrame("Frame", nil, scrollFrame) 
    scrollChild:SetSize(280, 100) 
    scrollFrame:SetScrollChild(scrollChild) 

    local function UpdateBossWLScroll() 
        for _, child in ipairs({scrollChild:GetChildren()}) do 
            child:Hide() 
            child:SetParent(nil) 
        end 

        local yOffset = -5 
        for bName, _ in pairs(EpicLootTrackerConfig.bossWhitelist or {}) do 
            local row = CreateFrame("Frame", nil, scrollChild) 
            row:SetSize(260, 25) 
            row:SetPoint("TOPLEFT", 10, yOffset) 

            local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
            nameText:SetPoint("LEFT", 5, 0) 
            nameText:SetWidth(180) 
            nameText:SetJustifyH("LEFT") 
            nameText:SetText(bName) 

            local removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate") 
            removeBtn:SetSize(50, 20) 
            removeBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0) 
            removeBtn:SetText("移除") 
            removeBtn:SetScript("OnClick", function() 
                EpicLootTrackerConfig.bossWhitelist[bName] = nil 
                UpdateBossWLScroll() 
            end) 
            yOffset = yOffset - 28 
        end 
        scrollChild:SetHeight(math.abs(yOffset) + 10) 
    end 

    local addBtn = CreateFrame("Button", nil, BossWhitelistFrame, "UIPanelButtonTemplate") 
    addBtn:SetSize(60, 22) 
    addBtn:SetPoint("LEFT", inputBox, "RIGHT", 10, 0) 
    addBtn:SetText("添加") 
    addBtn:SetScript("OnClick", function() 
        local text = inputBox:GetText() 
        if not text or text == "" then return end 
        EpicLootTrackerConfig.bossWhitelist = EpicLootTrackerConfig.bossWhitelist or {} 
        EpicLootTrackerConfig.bossWhitelist[text] = true 
        inputBox:SetText("") 
        inputBox:ClearFocus() 
        UpdateBossWLScroll() 
    end) 

    BossWhitelistFrame:SetScript("OnShow", function() 
        enableChk:SetChecked(EpicLootTrackerConfig.enableBossWhitelist) 
        UpdateBossWLScroll() 
    end) 
    UpdateBossWLScroll() 
end 

-- ==========================================
-- 2. 装备属性汇总与变体统计模块 (提前到 Boss 统计之前定义)
-- ==========================================
local EquipStatFrame = nil 
local variantCache = {} 

local function GetItemVariantSignature(itemLink) 
    if not itemLink then return "未知", "-", "-" end 
    if variantCache[itemLink] then 
        return variantCache[itemLink].sig, variantCache[itemLink].socketStr, variantCache[itemLink].tertiaryStr 
    end 

    local socketStr, tertiaryStr = GetItemExtraDetails(itemLink) 
    
    local cleanSocket = string.gsub(socketStr, "|c%x%x%x%x%x%x%x%x", "") 
    cleanSocket = string.gsub(cleanSocket, "|r", "") 
    
    local cleanTertiary = string.gsub(tertiaryStr, "|c%x%x%x%x%x%x%x%x", "") 
    cleanTertiary = string.gsub(cleanTertiary, "|r", "") 
    
    local sig = "基础/无额外属性" 
    if cleanSocket ~= "-" or cleanTertiary ~= "-" then 
        local sigParts = {} 
        if cleanSocket ~= "-" then table.insert(sigParts, "插槽: " .. socketStr) end 
        if cleanTertiary ~= "-" then table.insert(sigParts, "第三属性: " .. tertiaryStr) end 
        sig = table.concat(sigParts, " + ") 
    end 

    variantCache[itemLink] = { sig = sig, socketStr = socketStr, tertiaryStr = tertiaryStr } 
    return sig, socketStr, tertiaryStr 
end 

local function BuildEquipStatData(onlyBossDrops, searchText, strictBossFilter) 
    local aggregatedData = {} 
    local filterText = searchText and searchText:lower():gsub("^%s*(.-)%s*$", "%1") or "" 
    local matchedBosses = {} 

    local function processItemRecord(itemLink, bossName) 
        if not itemLink then return end 
        
        if strictBossFilter and bossName ~= strictBossFilter then return end 
        
        local itemName = string.match(itemLink, "%[(.-)%]") or itemLink 
        local itemNameMatch = (filterText == "") or string.find(itemName:lower(), filterText, 1, true) 
        
        if strictBossFilter then 
            if filterText ~= "" and not itemNameMatch then return end 
        else 
            if filterText ~= "" and not itemNameMatch then 
                local isBossMatch = bossName and string.find(bossName:lower(), filterText, 1, true) 
                if not isBossMatch then return end 
            end 
        end 

        local itemID = tonumber(string.match(itemLink, "item:(%d+)")) 
        local _, _, _, _, _, _, _, _, itemEquipLoc = GetItemInfo(itemLink) 
        
        if itemID and (itemEquipLoc and itemEquipLoc ~= "") then 
            local sig, socketStr, tertiaryStr = GetItemVariantSignature(itemLink) 
            local key = itemName 
            
            if not aggregatedData[key] then 
                aggregatedData[key] = { 
                    key = key, 
                    itemLink = itemLink, 
                    totalCount = 0, 
                    bossSources = {}, 
                    variants = {} 
                } 
            end 
            
            local itemNode = aggregatedData[key] 
            itemNode.totalCount = itemNode.totalCount + 1 
            if bossName then 
                itemNode.bossSources[bossName] = (itemNode.bossSources[bossName] or 0) + 1 
            end 
            
            if not itemNode.variants[sig] then 
                itemNode.variants[sig] = { 
                    count = 0, 
                    sigName = sig, 
                    socketStr = socketStr, 
                    tertiaryStr = tertiaryStr 
                } 
            end 
            itemNode.variants[sig].count = itemNode.variants[sig].count + 1 
        end 
    end 

    if strictBossFilter then 
        matchedBosses[strictBossFilter] = true 
        if EpicLootBossDB[strictBossFilter] then 
            for _, loot in ipairs(EpicLootBossDB[strictBossFilter].loots or {}) do 
                processItemRecord(loot.itemLink, strictBossFilter) 
            end 
        end 
    elseif onlyBossDrops then 
        for bossName, bossData in pairs(EpicLootBossDB or {}) do 
            for _, loot in ipairs(bossData.loots or {}) do 
                processItemRecord(loot.itemLink, bossName) 
            end 
        end 
    else 
        for _, record in ipairs(EpicLootTrackerDB or {}) do 
            processItemRecord(record.itemLink, record.bossName) 
        end 
    end 
    
    local resultList = {} 
    for _, data in pairs(aggregatedData) do 
        table.insert(resultList, data) 
    end 
    table.sort(resultList, function(a, b) return a.totalCount > b.totalCount end) 
    
    return resultList, matchedBosses 
end 

local function CreateEquipStatUI() 
    if EquipStatFrame then 
        EquipStatFrame:SetShown(not EquipStatFrame:IsShown()) 
        if EquipStatFrame:IsShown() then 
            EquipStatFrame:Raise() 
            EquipStatFrame.RefreshUI() 
        end 
        return 
    end 

    EquipStatFrame = CreateFrame("Frame", "EpicLootEquipStatUI", UIParent, "BasicFrameTemplateWithInset") 
    EquipStatFrame:SetSize(620, 480) 
    EquipStatFrame:SetPoint("CENTER", UIParent, "CENTER", 40, -40) 
    EquipStatFrame:SetMovable(true) 
    EquipStatFrame:EnableMouse(true) 
    EquipStatFrame:RegisterForDrag("LeftButton") 
    EquipStatFrame:SetScript("OnDragStart", EquipStatFrame.StartMoving) 
    EquipStatFrame:SetScript("OnDragStop", EquipStatFrame.StopMovingOrSizing) 
    EquipStatFrame:SetFrameStrata("FULLSCREEN_DIALOG") 

    EquipStatFrame.title = EquipStatFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    EquipStatFrame.title:SetPoint("CENTER", EquipStatFrame.TitleBg, "CENTER", 0, 0) 
    EquipStatFrame.title:SetText("装备掉落及属性变体汇总统计") 
    
    local searchBox = CreateFrame("EditBox", nil, EquipStatFrame, "InputBoxTemplate") 
    searchBox:SetSize(170, 22) 
    searchBox:SetPoint("TOPLEFT", EquipStatFrame, "TOPLEFT", 25, -35) 
    searchBox:SetAutoFocus(false) 
    
    local searchLabel = searchBox:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
    searchLabel:SetPoint("BOTTOMLEFT", searchBox, "TOPLEFT", -5, 2) 
    searchLabel:SetText("搜索 (装备名/Boss名):") 
    
    EquipStatFrame.searchBox = searchBox

    local chkBossOnly = CreateFrame("CheckButton", nil, EquipStatFrame, "UICheckButtonTemplate") 
    chkBossOnly:SetPoint("LEFT", searchBox, "RIGHT", 15, 0) 
    chkBossOnly:SetChecked(true) 
    chkBossOnly.text = chkBossOnly:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    chkBossOnly.text:SetPoint("LEFT", chkBossOnly, "RIGHT", 2, 1) 
    chkBossOnly.text:SetText("仅统计 Boss 击杀掉落") 
    
    EquipStatFrame.chkBossOnly = chkBossOnly

    searchBox:SetScript("OnTextChanged", function() EquipStatFrame.RefreshUI() end) 
    chkBossOnly:SetScript("OnClick", function() EquipStatFrame.RefreshUI() end) 

    local scrollFrame = CreateFrame("ScrollFrame", nil, EquipStatFrame, "UIPanelScrollFrameTemplate") 
    scrollFrame:SetPoint("TOPLEFT", 10, -65) 
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10) 

    local scrollChild = CreateFrame("Frame", nil, scrollFrame) 
    scrollChild:SetSize(560, 100) 
    scrollFrame:SetScrollChild(scrollChild) 

    function EquipStatFrame.RefreshUI() 
        for _, child in ipairs({scrollChild:GetChildren()}) do 
            child:Hide() 
            child:SetParent(nil) 
        end 

        if EquipStatFrame.strictBossFilter then 
            EquipStatFrame.title:SetText("装备汇总 - 仅显示: " .. EquipStatFrame.strictBossFilter) 
        else 
            EquipStatFrame.title:SetText("装备掉落及属性变体汇总统计") 
        end 

        if not EquipStatFrame.clearFilterBtn then 
            local clearFilterBtn = CreateFrame("Button", nil, EquipStatFrame, "UIPanelButtonTemplate") 
            clearFilterBtn:SetSize(110, 22) 
            clearFilterBtn:SetPoint("LEFT", EquipStatFrame.chkBossOnly.text, "RIGHT", 15, 0) 
            clearFilterBtn:SetText("清除Boss过滤") 
            clearFilterBtn:SetScript("OnClick", function() 
                EquipStatFrame.strictBossFilter = nil 
                EquipStatFrame.RefreshUI() 
            end) 
            EquipStatFrame.clearFilterBtn = clearFilterBtn 
        end 

        if EquipStatFrame.strictBossFilter then 
            EquipStatFrame.clearFilterBtn:Show() 
        else 
            EquipStatFrame.clearFilterBtn:Hide() 
        end 

        local isBossOnly = EquipStatFrame.chkBossOnly:GetChecked() 
        local filterText = EquipStatFrame.searchBox:GetText() 
        
        local statList, matchedBosses = BuildEquipStatData(isBossOnly, filterText, EquipStatFrame.strictBossFilter) 
        local yOffset = -5 

        local bossBannerTextList = {} 
        for bName, _ in pairs(matchedBosses) do 
            local kills = (EpicLootBossDB[bName] and EpicLootBossDB[bName].kills) or 0 
            table.insert(bossBannerTextList, string.format("|cffffd100%s|r (击杀次数: |cff00ff00%d|r 次)", bName, kills)) 
        end 

        if #bossBannerTextList > 0 then 
            local banner = CreateFrame("Frame", nil, scrollChild, "BackdropTemplate") 
            banner:SetSize(550, 24) 
            banner:SetPoint("TOPLEFT", 5, yOffset) 
            banner:SetBackdrop({ 
                bgFile = "Interface\\ChatFrame\\ChatFrameBackground", 
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", 
                tile = true, tileSize = 16, edgeSize = 8, 
                insets = { left = 2, right = 2, top = 2, bottom = 2 } 
            }) 
            banner:SetBackdropColor(0.2, 0.15, 0.05, 0.7) 
            banner:SetBackdropBorderColor(1, 0.8, 0, 0.8) 

            local bText = banner:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
            bText:SetPoint("LEFT", 10, 0) 
            bText:SetText("Boss 统计汇总: " .. table.concat(bossBannerTextList, " | ")) 

            yOffset = yOffset - 28 
        end 

        for _, itemData in ipairs(statList) do 
            local card = CreateFrame("Frame", nil, scrollChild, "BackdropTemplate") 
            card:SetSize(550, 30) 
            card:SetPoint("TOPLEFT", 5, yOffset) 
            card:SetBackdrop({ 
                bgFile = "Interface\\ChatFrame\\ChatFrameBackground", 
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", 
                tile = true, tileSize = 16, edgeSize = 12, 
                insets = { left = 3, right = 3, top = 3, bottom = 3 } 
            }) 
            card:SetBackdropColor(0.1, 0.1, 0.1, 0.6) 
            card:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.8) 

            local itemText = card:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
            itemText:SetPoint("LEFT", 10, 0) 
            itemText:SetText(itemData.itemLink) 
            
            itemText:EnableMouse(true) 
            itemText:SetScript("OnEnter", function(self) 
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT") 
                GameTooltip:SetHyperlink(itemData.itemLink) 
                GameTooltip:Show() 
            end) 
            itemText:SetScript("OnLeave", function() GameTooltip:Hide() end) 

            local bossInfoStr = "" 
            local bList = {} 
            for bName, bCount in pairs(itemData.bossSources) do 
                local kills = (EpicLootBossDB[bName] and EpicLootBossDB[bName].kills) or 0 
                table.insert(bList, string.format("%s(%d件/击杀%d次)", bName, bCount, kills)) 
            end 
            if #bList > 0 then 
                bossInfoStr = " [来源: " .. table.concat(bList, ", ") .. "]" 
            end 

            local totalText = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
            totalText:SetPoint("RIGHT", -15, 0) 
            totalText:SetText(string.format("总掉落: |cff00ff00%d|r 件%s", itemData.totalCount, bossInfoStr)) 

            yOffset = yOffset - 32 

            for _, vData in pairs(itemData.variants) do 
                local subRow = CreateFrame("Frame", nil, scrollChild) 
                subRow:SetSize(530, 20) 
                subRow:SetPoint("TOPLEFT", 25, yOffset) 

                local bullet = subRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
                bullet:SetPoint("LEFT", 0, 0)           
                bullet:SetText("└─") 

                local attrText = subRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
                attrText:SetPoint("LEFT", 25, 0) 
                attrText:SetText(vData.sigName) 

                local countText = subRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall") 
                countText:SetPoint("RIGHT", -15, 0) 
                countText:SetText(string.format("数量: %d 件 (占比 %.1f%%)", vData.count, (vData.count / itemData.totalCount) * 100)) 

                yOffset = yOffset - 22 
            end 

            yOffset = yOffset - 6 
        end 
        scrollChild:SetHeight(math.abs(yOffset) + 10) 
    end 

    EquipStatFrame:SetScript("OnShow", function() EquipStatFrame.RefreshUI() end) 
end 

-- ==========================================
-- 3. Boss 击杀与掉落统计 UI 模块
-- ==========================================
local BossStatFrame = nil 
local selectedBossName = nil 

local function EpicLootTracker_UpdateBossUI() 
    if not BossStatFrame or not BossStatFrame:IsShown() then return end 

    local bossList = {} 
    for bName, bData in pairs(EpicLootBossDB or {}) do 
        table.insert(bossList, { name = bName, kills = bData.kills or 0, loots = bData.loots or {} }) 
    end 
    table.sort(bossList, function(a, b) return a.kills > b.kills end) 

    FauxScrollFrame_Update(BossStatFrame.bossScroll, #bossList, 12, 26) 
    local bossOffset = FauxScrollFrame_GetOffset(BossStatFrame.bossScroll) 

    for i = 1, 12 do 
        local idx = bossOffset + i 
        local row = BossStatFrame.bossRows[i] 
        if idx <= #bossList then 
            local data = bossList[idx] 
            row.bossName = data.name 
            row.nameText:SetText(data.name) 
            row.countText:SetText(data.kills .. " 次") 
            
            if selectedBossName == data.name then 
                row.bg:SetColorTexture(0.2, 0.6, 1.0, 0.3) 
            else 
                row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.03 or 0.08) 
            end 
            row:Show() 
        else 
            row.bossName = nil 
            row:Hide() 
        end 
    end 

    local lootList = {} 
    if selectedBossName and EpicLootBossDB[selectedBossName] then 
        lootList = EpicLootBossDB[selectedBossName].loots or {} 
    end 

    FauxScrollFrame_Update(BossStatFrame.lootScroll, #lootList, 12, 26) 
    local lootOffset = FauxScrollFrame_GetOffset(BossStatFrame.lootScroll) 

    for i = 1, 12 do 
        local idx = lootOffset + i 
        local row = BossStatFrame.lootRows[i] 
        if idx <= #lootList then 
            local data = lootList[idx] 
            row.itemLink = data.itemLink 
            row.itemFS:SetText(data.itemLink or "未知物品") 
            row.playerText:SetText(data.player or "-") 
            
            local formattedTime = data.time or "-" 
            if #formattedTime >= 16 then 
                formattedTime = string.sub(formattedTime, 6, 16) 
            end 
            row.timeText:SetText(formattedTime) 
            row:Show() 
        else 
            row.itemLink = nil 
            row:Hide() 
        end 
    end 
end 

local function CreateBossStatUI() 
    if BossStatFrame then 
        BossStatFrame:SetShown(not BossStatFrame:IsShown()) 
        if BossStatFrame:IsShown() then EpicLootTracker_UpdateBossUI() end 
        return 
    end 

    BossStatFrame = CreateFrame("Frame", "EpicLootTrackerBossStatUI", UIParent, "BasicFrameTemplateWithInset") 
    BossStatFrame:SetSize(620, 420) 
    BossStatFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0) 
    BossStatFrame:SetMovable(true) 
    BossStatFrame:EnableMouse(true) 
    BossStatFrame:RegisterForDrag("LeftButton") 
    BossStatFrame:SetScript("OnDragStart", BossStatFrame.StartMoving) 
    BossStatFrame:SetScript("OnDragStop", BossStatFrame.StopMovingOrSizing) 
    BossStatFrame:SetFrameStrata("DIALOG") 

    BossStatFrame.title = BossStatFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    BossStatFrame.title:SetPoint("CENTER", BossStatFrame.TitleBg, "CENTER", 0, 0) 
    BossStatFrame.title:SetText("Boss 击杀与掉落统计") 

    local leftLabel = BossStatFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
    leftLabel:SetPoint("TOPLEFT", 15, -35) 
    leftLabel:SetText("Boss 名称 (击杀次数)") 

    BossStatFrame.bossScroll = CreateFrame("ScrollFrame", "EpicLootBossScroll", BossStatFrame, "FauxScrollFrameTemplate") 
    BossStatFrame.bossScroll:SetPoint("TOPLEFT", 15, -55) 
    BossStatFrame.bossScroll:SetSize(220, 320) 

    BossStatFrame.bossRows = {} 
    for i = 1, 12 do 
        local row = CreateFrame("Button", nil, BossStatFrame) 
        row:SetSize(215, 25) 
        if i == 1 then row:SetPoint("TOPLEFT", BossStatFrame.bossScroll, "TOPLEFT", 0, 0) 
        else row:SetPoint("TOPLEFT", BossStatFrame.bossRows[i-1], "BOTTOMLEFT", 0, -1) end 

        row.bg = row:CreateTexture(nil, "BACKGROUND") 
        row.bg:SetAllPoints() 

        row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
        row.nameText:SetPoint("LEFT", 5, 0) 
        row.nameText:SetWidth(150) 
        row.nameText:SetJustifyH("LEFT") 
        row.nameText:SetWordWrap(false) 

        row.countText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall") 
        row.countText:SetPoint("RIGHT", -5, 0) 
        row.countText:SetWidth(50) 
        row.countText:SetJustifyH("RIGHT") 

        row:SetScript("OnClick", function(self) 
            selectedBossName = self.bossName 
            EpicLootTracker_UpdateBossUI() 
        end) 

        BossStatFrame.bossRows[i] = row 
    end 

    BossStatFrame.bossScroll:SetScript("OnVerticalScroll", function(self, offset) 
        FauxScrollFrame_OnVerticalScroll(self, offset, 26, EpicLootTracker_UpdateBossUI) 
    end) 

    local line = BossStatFrame:CreateTexture(nil, "ARTWORK") 
    line:SetSize(1, 340) 
    line:SetPoint("TOPLEFT", 250, -35) 
    line:SetColorTexture(0.3, 0.3, 0.3, 0.8) 

    local rightLabel = BossStatFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
    rightLabel:SetPoint("TOPLEFT", 260, -35) 
    rightLabel:SetText("关联掉落记录") 

    local summaryBtn = CreateFrame("Button", nil, BossStatFrame, "UIPanelButtonTemplate") 
    summaryBtn:SetSize(110, 22) 
    summaryBtn:SetPoint("LEFT", rightLabel, "RIGHT", 15, 0) 
    summaryBtn:SetText("查看属性汇总") 
    summaryBtn:SetScript("OnClick", function() 
        if not selectedBossName then 
            print("|cffff0000[EpicLootTracker]|r 请先在左侧选择一个 Boss！") 
            return 
        end 
        
        if not EquipStatFrame then CreateEquipStatUI() end 
        
        EquipStatFrame.strictBossFilter = selectedBossName  
        EquipStatFrame:Show() 
        EquipStatFrame:Raise() 
        EquipStatFrame.chkBossOnly:SetChecked(true) 
        EquipStatFrame.searchBox:SetText("") 
        EquipStatFrame.RefreshUI() 
    end) 

    local wlBossBtn = CreateFrame("Button", nil, BossStatFrame, "UIPanelButtonTemplate") 
    wlBossBtn:SetSize(100, 22) 
    wlBossBtn:SetPoint("LEFT", summaryBtn, "RIGHT", 10, 0) 
    wlBossBtn:SetText("Boss白名单") 
    wlBossBtn:SetScript("OnClick", function() 
        CreateBossWhitelistUI() 
    end) 

    BossStatFrame.lootScroll = CreateFrame("ScrollFrame", "EpicLootBossLootScroll", BossStatFrame, "FauxScrollFrameTemplate") 
    BossStatFrame.lootScroll:SetPoint("TOPLEFT", 260, -55) 
    BossStatFrame.lootScroll:SetSize(325, 320) 

    BossStatFrame.lootRows = {} 
    for i = 1, 12 do 
        local row = CreateFrame("Frame", nil, BossStatFrame) 
        row:SetSize(320, 25) 
        if i == 1 then row:SetPoint("TOPLEFT", BossStatFrame.lootScroll, "TOPLEFT", 0, 0) 
        else row:SetPoint("TOPLEFT", BossStatFrame.lootRows[i-1], "BOTTOMLEFT", 0, -1) end 

        row.bg = row:CreateTexture(nil, "BACKGROUND") 
        row.bg:SetAllPoints() 
        row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.03 or 0.08) 

        row.itemFS = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
        row.itemFS:SetPoint("LEFT", 5, 0) 
        row.itemFS:SetWidth(135) 
        row.itemFS:SetJustifyH("LEFT") 
        row.itemFS:SetWordWrap(false) 

        row.playerText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall") 
        row.playerText:SetPoint("LEFT", 142, 0) 
        row.playerText:SetWidth(95) 
        row.playerText:SetJustifyH("LEFT") 
        row.playerText:SetWordWrap(false) 

        row.timeText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
        row.timeText:SetPoint("RIGHT", -5, 0) 
        row.timeText:SetWidth(75) 
        row.timeText:SetJustifyH("RIGHT") 
        row.timeText:SetWordWrap(false) 

        row:EnableMouse(true) 
        row:SetScript("OnEnter", function(self) 
            if row.itemLink then 
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT") 
                GameTooltip:SetHyperlink(row.itemLink) 
                GameTooltip:Show() 
            end 
        end) 
        row:SetScript("OnLeave", function() GameTooltip:Hide() end) 

        BossStatFrame.lootRows[i] = row 
    end 

    BossStatFrame.lootScroll:SetScript("OnVerticalScroll", function(self, offset) 
        FauxScrollFrame_OnVerticalScroll(self, offset, 26, EpicLootTracker_UpdateBossUI) 
    end) 

    BossStatFrame:SetScript("OnShow", function() 
        EpicLootTracker_UpdateBossUI() 
    end) 
end 

-- ==========================================
-- 4. 主 UI 界面构建
-- ==========================================
mainFrame = CreateFrame("Frame", "EpicLootTrackerFrame", UIParent, "BasicFrameTemplateWithInset") 
mainFrame:SetSize(980, 520) 
mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0) 
mainFrame:Hide() 
mainFrame:SetMovable(true) 
mainFrame:EnableMouse(true) 
mainFrame:RegisterForDrag("LeftButton") 
mainFrame:SetScript("OnDragStart", mainFrame.StartMoving) 
mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing) 

mainFrame.title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.title:SetPoint("CENTER", mainFrame.TitleBg, "CENTER", 0, 0) 
mainFrame.title:SetText("高级战利品拾取记录") 

mainFrame.filteredData = {} 
mainFrame.currentTimeFilter = "ALL" 

mainFrame.searchBox = CreateFrame("EditBox", nil, mainFrame, "InputBoxTemplate") 
mainFrame.searchBox:SetSize(160, 22) 
mainFrame.searchBox:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 25, -35) 
mainFrame.searchBox:SetAutoFocus(false) 
mainFrame.searchBox.label = mainFrame.searchBox:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
mainFrame.searchBox.label:SetPoint("BOTTOMLEFT", mainFrame.searchBox, "TOPLEFT", -5, 2) 
mainFrame.searchBox.label:SetText("模糊搜索 (物品/地点/角色):") 
mainFrame.searchBox:SetScript("OnTextChanged", function(self) 
    EpicLootTracker_BuildData() 
    EpicLootTracker_UpdateUI() 
end) 

mainFrame.whitelistBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate") 
mainFrame.whitelistBtn:SetSize(90, 22) 
mainFrame.whitelistBtn:SetPoint("LEFT", mainFrame.searchBox, "RIGHT", 15, 0) 
mainFrame.whitelistBtn:SetText("白名单") 

mainFrame.blacklistBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate") 
mainFrame.blacklistBtn:SetSize(90, 22) 
mainFrame.blacklistBtn:SetPoint("LEFT", mainFrame.whitelistBtn, "RIGHT", 10, 0) 
mainFrame.blacklistBtn:SetText("黑名单") 
mainFrame.blacklistBtn:SetScript("OnClick", function() 
    CreateBlacklistManagerUI() 
end) 

mainFrame.bossStatBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate") 
mainFrame.bossStatBtn:SetSize(90, 22) 
mainFrame.bossStatBtn:SetPoint("LEFT", mainFrame.blacklistBtn, "RIGHT", 10, 0) 
mainFrame.bossStatBtn:SetText("击杀统计") 
mainFrame.bossStatBtn:SetScript("OnClick", function() 
    CreateBossStatUI() 
end) 

mainFrame.wlPanel = CreateFrame("Frame", nil, mainFrame, "BasicFrameTemplateWithInset") 
mainFrame.wlPanel:SetSize(280, 480) 
mainFrame.wlPanel:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 5, 0)  
mainFrame.wlPanel:Hide() 
mainFrame.wlPanel.title = mainFrame.wlPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.wlPanel.title:SetPoint("CENTER", mainFrame.wlPanel.TitleBg, "CENTER", 0, 0) 
mainFrame.wlPanel.title:SetText("蓝装白名单") 

mainFrame.whitelistBtn:SetScript("OnClick", function() 
    if mainFrame.wlPanel:IsShown() then 
        mainFrame.wlPanel:Hide() 
    else 
        mainFrame.wlPanel:Show() 
        EpicLootTracker_UpdateWhitelistUI() 
    end 
end) 

local wlAddBtn = CreateFrame("Button", nil, mainFrame.wlPanel, "UIPanelButtonTemplate") 
wlAddBtn:SetSize(120, 24) 
wlAddBtn:SetPoint("TOP", mainFrame.wlPanel, "TOP", 0, -35) 
wlAddBtn:SetText("添加新物品") 
wlAddBtn:SetScript("OnClick", function() 
    StaticPopup_Show("EPIC_LOOT_TRACKER_ADD_WHITELIST") 
end) 

local wlScroll = CreateFrame("ScrollFrame", "EpicLootTrackerWLScroll", mainFrame.wlPanel, "FauxScrollFrameTemplate") 
wlScroll:SetPoint("TOPLEFT", mainFrame.wlPanel, "TOPLEFT", 10, -70) 
wlScroll:SetPoint("BOTTOMRIGHT", mainFrame.wlPanel, "BOTTOMRIGHT", -30, 10) 

mainFrame.wlPanel.rows = {} 
local WL_ROW_COUNT = 18 
for i = 1, WL_ROW_COUNT do 
    local row = CreateFrame("Frame", nil, mainFrame.wlPanel) 
    row:SetSize(230, 22) 
    if i == 1 then row:SetPoint("TOPLEFT", wlScroll, "TOPLEFT", 0, 0) 
    else row:SetPoint("TOPLEFT", mainFrame.wlPanel.rows[i-1], "BOTTOMLEFT", 0, -2) end 

    row.itemFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
    row.itemFS:SetPoint("LEFT", row, "LEFT", 5, 0) 
    row.itemFS:SetWidth(170) 
    row.itemFS:SetJustifyH("LEFT") 
    row.itemFS:SetWordWrap(false) 
    
    row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate") 
    row.delBtn:SetSize(45, 20) 
    row.delBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0) 
    row.delBtn:SetText("移除") 
    row.delBtn:SetScript("OnClick", function() 
        if row.itemID and EpicLootTrackerConfig.whitelist then 
            EpicLootTrackerConfig.whitelist[row.itemID] = nil 
            EpicLootTracker_UpdateWhitelistUI() 
        end 
    end) 
    
    row:EnableMouse(true) 
    row:SetScript("OnEnter", function(self) 
        if row.itemID then 
            local _, link = GetItemInfo(row.itemID) 
            if link then 
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT") 
                GameTooltip:SetHyperlink(link) 
                GameTooltip:Show() 
            end 
        end 
    end) 
    row:SetScript("OnLeave", function() GameTooltip:Hide() end) 

    mainFrame.wlPanel.rows[i] = row 
end 

function EpicLootTracker_UpdateWhitelistUI() 
    if not mainFrame.wlPanel:IsShown() then return end 
    
    local wlData = {} 
    if EpicLootTrackerConfig and EpicLootTrackerConfig.whitelist then 
        for id, _ in pairs(EpicLootTrackerConfig.whitelist) do 
            table.insert(wlData, id) 
        end 
    end 
    
    FauxScrollFrame_Update(wlScroll, #wlData, WL_ROW_COUNT, 22) 
    local offset = FauxScrollFrame_GetOffset(wlScroll) 
    
    for i = 1, WL_ROW_COUNT do 
        local idx = offset + i 
        local row = mainFrame.wlPanel.rows[i] 
        if idx <= #wlData then 
            local itemID = wlData[idx] 
            row.itemID = itemID 
            local _, itemLink = GetItemInfo(itemID) 
            if itemLink then 
                row.itemFS:SetText(itemLink) 
            else 
                row.itemFS:SetText("物品ID: " .. itemID) 
            end 
            row:Show() 
        else 
            row.itemID = nil 
            row:Hide() 
        end 
    end 
end 

wlScroll:SetScript("OnVerticalScroll", function(self, offset) 
    FauxScrollFrame_OnVerticalScroll(self, offset, 22, EpicLootTracker_UpdateWhitelistUI) 
end) 

mainFrame.chkRecordBlue = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkRecordBlue:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -140, -35) 
mainFrame.chkRecordBlue.text = mainFrame.chkRecordBlue:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
mainFrame.chkRecordBlue.text:SetPoint("LEFT", mainFrame.chkRecordBlue, "RIGHT", 2, 1) 
mainFrame.chkRecordBlue.text:SetText("记录精良(蓝装)") 
mainFrame.chkRecordBlue:SetScript("OnClick", function(self) 
    EpicLootTrackerConfig.recordBlue = self:GetChecked() 
end) 

mainFrame.chkRecordSolo = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkRecordSolo:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -290, -35) 
mainFrame.chkRecordSolo.text = mainFrame.chkRecordSolo:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
mainFrame.chkRecordSolo.text:SetPoint("LEFT", mainFrame.chkRecordSolo, "RIGHT", 2, 1) 
mainFrame.chkRecordSolo.text:SetText("记录单人拾取") 
mainFrame.chkRecordSolo:SetScript("OnClick", function(self) 
    EpicLootTrackerConfig.recordSolo = self:GetChecked() 
end) 

mainFrame.chkShowPurple = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkShowPurple:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -70) 
mainFrame.chkShowPurple:SetChecked(true) 
mainFrame.chkShowPurple.text = mainFrame.chkShowPurple:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.chkShowPurple.text:SetPoint("LEFT", mainFrame.chkShowPurple, "RIGHT", 2, 1) 
mainFrame.chkShowPurple.text:SetText("紫装") 
mainFrame.chkShowPurple:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end) 

mainFrame.chkShowBlue = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkShowBlue:SetPoint("LEFT", mainFrame.chkShowPurple.text, "RIGHT", 10, -1) 
mainFrame.chkShowBlue:SetChecked(true) 
mainFrame.chkShowBlue.text = mainFrame.chkShowBlue:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.chkShowBlue.text:SetPoint("LEFT", mainFrame.chkShowBlue, "RIGHT", 2, 1) 
mainFrame.chkShowBlue.text:SetText("蓝装") 
mainFrame.chkShowBlue:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end) 

mainFrame.chkShowEquip = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkShowEquip:SetPoint("LEFT", mainFrame.chkShowBlue.text, "RIGHT", 15, 0) 
mainFrame.chkShowEquip:SetChecked(true) 
mainFrame.chkShowEquip.text = mainFrame.chkShowEquip:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.chkShowEquip.text:SetPoint("LEFT", mainFrame.chkShowEquip, "RIGHT", 2, 1) 
mainFrame.chkShowEquip.text:SetText("装备") 
mainFrame.chkShowEquip:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end) 

mainFrame.chkShowRecipe = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkShowRecipe:SetPoint("LEFT", mainFrame.chkShowEquip.text, "RIGHT", 10, 0) 
mainFrame.chkShowRecipe:SetChecked(true) 
mainFrame.chkShowRecipe.text = mainFrame.chkShowRecipe:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.chkShowRecipe.text:SetPoint("LEFT", mainFrame.chkShowRecipe, "RIGHT", 2, 1) 
mainFrame.chkShowRecipe.text:SetText("图纸") 
mainFrame.chkShowRecipe:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end) 

mainFrame.chkShowMisc = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate") 
mainFrame.chkShowMisc:SetPoint("LEFT", mainFrame.chkShowRecipe.text, "RIGHT", 10, 0) 
mainFrame.chkShowMisc:SetChecked(true) 
mainFrame.chkShowMisc.text = mainFrame.chkShowMisc:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
mainFrame.chkShowMisc.text:SetPoint("LEFT", mainFrame.chkShowMisc, "RIGHT", 2, 1) 
mainFrame.chkShowMisc.text:SetText("杂项") 
mainFrame.chkShowMisc:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end) 

local timeFilters = { 
    { key = "ALL", label = "全部" }, 
    { key = "TODAY", label = "今天" }, 
    { key = "3DAYS", label = "近3天" }, 
    { key = "1WEEK", label = "一周" }, 
    { key = "HALFMONTH", label = "半个月" }, 
    { key = "1MONTH", label = "一个月" } 
} 
local filterBtns = {} 
for i, filter in ipairs(timeFilters) do 
    local btn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate") 
    btn:SetSize(65, 22) 
    if i == 1 then 
        btn:SetPoint("LEFT", mainFrame.chkShowMisc.text, "RIGHT", 15, 0) 
    else 
        btn:SetPoint("LEFT", filterBtns[i-1], "RIGHT", 5, 0) 
    end 
    btn:SetText(filter.label) 
    btn:SetScript("OnClick", function() 
        mainFrame.currentTimeFilter = filter.key 
        for _, b in ipairs(filterBtns) do b:Enable() end 
        btn:Disable() 
        EpicLootTracker_BuildData() 
        EpicLootTracker_UpdateUI() 
    end) 
    filterBtns[i] = btn 
end 
filterBtns[1]:Disable() 

local headers = { 
    { title = "物品名", width = 140, xOffset = 50, align = "LEFT" }, 
    { title = "装等", width = 40, xOffset = 172, align = "CENTER" }, 
    { title = "需求", width = 40, xOffset = 217, align = "CENTER" }, 
    { title = "插槽", width = 55, xOffset = 262, align = "CENTER" }, 
    { title = "三属性", width = 65, xOffset = 323, align = "CENTER" }, 
    { title = "时间", width = 135, xOffset = 425, align = "LEFT" }, 
    { title = "地点", width = 145, xOffset = 535, align = "LEFT" }, 
    { title = "角色-服务器", width = 205, xOffset = 683, align = "LEFT" }, 
    { title = "操作", width = 45, xOffset = 890, align = "CENTER" }, 
} 

for _, h in ipairs(headers) do 
    local font = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
    font:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", h.xOffset, -105) 
    font:SetWidth(h.width) 
    font:SetJustifyH(h.align or "LEFT") 
    font:SetText(h.title) 
end 

local scrollFrame = CreateFrame("ScrollFrame", "EpicLootTrackerScroll", mainFrame, "FauxScrollFrameTemplate") 
scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -125) 
scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -35, 45) 

local ROW_COUNT = 14 
mainFrame.rows = {} 
for i = 1, ROW_COUNT do 
    local row = CreateFrame("Frame", nil, mainFrame) 
    row:SetSize(930, 24) 
    if i == 1 then row:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0) 
    else row:SetPoint("TOPLEFT", mainFrame.rows[i-1], "BOTTOMLEFT", 0, -1) end 

    row.bg = row:CreateTexture(nil, "BACKGROUND") 
    row.bg:SetAllPoints() 
    row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.03 or 0.08) 

    row.itemText = CreateFrame("Frame", nil, row) 
    row.itemText:SetSize(140, 20) 
    row.itemText:SetPoint("LEFT", row, "LEFT", 20, 0) 
    row.itemFS = row.itemText:CreateFontString(nil, "OVERLAY", "GameFontNormal") 
    row.itemFS:SetAllPoints() 
    row.itemFS:SetJustifyH("LEFT") 
    row.itemFS:SetWordWrap(false) 

    row.itemText:EnableMouse(true) 
    row.itemText:SetScript("OnEnter", function(self) 
        if row.itemLink then 
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT") 
            GameTooltip:SetHyperlink(row.itemLink) 
            GameTooltip:Show() 
        end 
    end) 
    row.itemText:SetScript("OnLeave", function() GameTooltip:Hide() end) 
    row.itemText:SetScript("OnMouseDown", function(self, button) 
        if button == "LeftButton" and IsShiftKeyDown() and row.itemLink then 
            ChatEdit_InsertLink(row.itemLink) 
        end 
    end) 

    row.ilvlText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    row.ilvlText:SetPoint("LEFT", row, "LEFT", 162, 0) 
    row.ilvlText:SetWidth(40) 
    row.ilvlText:SetJustifyH("CENTER") 

    row.reqLevelText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    row.reqLevelText:SetPoint("LEFT", row, "LEFT", 205, 0) 
    row.reqLevelText:SetWidth(40) 
    row.reqLevelText:SetJustifyH("CENTER") 

    row.socketText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight") 
    row.socketText:SetPoint("LEFT", row, "LEFT", 248, 0) 
    row.socketText:SetWidth(55) 
    row.socketText:SetJustifyH("CENTER") 

    row.tertiaryText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
    row.tertiaryText:SetPoint("LEFT", row, "LEFT", 308, 0) 
    row.tertiaryText:SetWidth(65) 
    row.tertiaryText:SetJustifyH("CENTER") 

    row.timeText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
    row.timeText:SetPoint("LEFT", row, "LEFT", 378, 0) 
    row.timeText:SetWidth(135) 
    row.timeText:SetJustifyH("LEFT") 
    row.timeText:SetWordWrap(false) 

    row.locationText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall") 
    row.locationText:SetPoint("LEFT", row, "LEFT", 518, 0) 
    row.locationText:SetWidth(145) 
    row.locationText:SetJustifyH("LEFT") 
    row.locationText:SetWordWrap(false) 

    row.playerText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") 
    row.playerText:SetPoint("LEFT", row, "LEFT", 668, 0) 
    row.playerText:SetWidth(205)  
    row.playerText:SetJustifyH("LEFT") 
    row.playerText:SetWordWrap(false) 

    row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate") 
    row.delBtn:SetSize(45, 20) 
    row.delBtn:SetPoint("LEFT", row, "LEFT", 880, 0) 
    row.delBtn:SetText("删除") 
    row.delBtn:SetScript("OnClick", function() 
        if row.dbIndex then 
            local dialog = StaticPopup_Show("EPIC_LOOT_TRACKER_CONFIRM_DELETE", row.itemNameOnly or "该物品") 
            if dialog then dialog.data = { dbIndex = row.dbIndex } end 
        end 
    end) 

    mainFrame.rows[i] = row 
end 

local clearAllBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate") 
clearAllBtn:SetSize(110, 24) 
clearAllBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 12) 
clearAllBtn:SetText("清空当前列表") 
clearAllBtn:SetScript("OnClick", function() 
    if #mainFrame.filteredData > 0 then 
        StaticPopup_Show("EPIC_LOOT_TRACKER_CONFIRM_CLEAR") 
    end 
end) 

-- ==========================================
-- 5. 数据过滤与排序引擎
-- ==========================================
function EpicLootTracker_BuildData() 
    table.sort(EpicLootTrackerDB, function(a, b) 
        return (a.timestamp or 0) > (b.timestamp or 0) 
    end) 

    table.wipe(mainFrame.filteredData) 
    local searchText = mainFrame.searchBox:GetText():lower() 
    local currentTimestamp = time() 
    
    local t_date = date("*t") 
    local todayMidnight = time({year=t_date.year, month=t_date.month, day=t_date.day, hour=0, min=0, sec=0}) 
    
    local showPurple = mainFrame.chkShowPurple:GetChecked() 
    local showBlue = mainFrame.chkShowBlue:GetChecked() 
    local showEquip = mainFrame.chkShowEquip:GetChecked() 
    local showRecipe = mainFrame.chkShowRecipe:GetChecked() 
    local showMisc = mainFrame.chkShowMisc:GetChecked() 

    for i, data in ipairs(EpicLootTrackerDB) do 
        local match = true 
        
        local rarity = data.rarity or 4 
        if not ((showPurple and rarity >= 4) or (showBlue and rarity == 3)) then 
            match = false 
        end 

        if match then 
            local isRecipe = false 
            local isEquip = false 
            local isMisc = false 
            
            local _, _, _, _, _, _, _, _, itemEquipLoc, _, _, classID = GetItemInfo(data.itemLink) 
            
            if classID then 
                if classID == 9 then  
                    isRecipe = true  
                elseif classID == 2 or classID == 4 or (itemEquipLoc and itemEquipLoc ~= "") then 
                    isEquip = true 
                else 
                    isMisc = true  
                end 
            else 
                local itemName = string.match(data.itemLink or "", "%[(.-)%]") or "" 
                if string.find(itemName, "设计图：") or string.find(itemName, "图样：") or  
                   string.find(itemName, "公式：") or string.find(itemName, "结构图：") or  
                   string.find(itemName, "指南：") or string.find(itemName, "图纸：") then 
                    isRecipe = true 
                else 
                    isEquip = true  
                end 
            end 
            
            if isMisc and not showMisc then 
                match = false  
            elseif isRecipe and not showRecipe then 
                match = false 
            elseif isEquip and not showEquip then 
                match = false 
            end 
        end 

        if match and searchText ~= "" then 
            local searchStr = string.lower((data.itemLink or "") .. (data.location or "") .. (data.player or "") .. (data.recorder or "")) 
            if not string.find(searchStr, searchText, 1, true) then 
                match = false 
            end 
        end 

        if match and mainFrame.currentTimeFilter ~= "ALL" then 
            local recTime = data.timestamp or 0  
            if recTime > 0 then 
                local diff = currentTimestamp - recTime 
                local filter = mainFrame.currentTimeFilter 
                if filter == "TODAY" and recTime < todayMidnight then match = false 
                elseif filter == "3DAYS" and diff > 3*24*3600 then match = false 
                elseif filter == "1WEEK" and diff > 7*24*3600 then match = false 
                elseif filter == "HALFMONTH" and diff > 15*24*3600 then match = false 
                elseif filter == "1MONTH" and diff > 30*24*3600 then match = false 
                end 
            else 
                match = false  
            end 
        end 

        if match then 
            table.insert(mainFrame.filteredData, { dbIndex = i, record = data }) 
        end 
    end 
end 

function EpicLootTracker_UpdateUI() 
    if not mainFrame:IsShown() then return end 
    local totalItems = #mainFrame.filteredData 
    FauxScrollFrame_Update(scrollFrame, totalItems, ROW_COUNT, 24) 

    local offset = FauxScrollFrame_GetOffset(scrollFrame) 
    for i = 1, ROW_COUNT do 
        local idx = offset + i 
        local row = mainFrame.rows[i] 

        if idx <= totalItems then 
            local dbWrapper = mainFrame.filteredData[idx] 
            local data = dbWrapper.record 
            row.dbIndex = dbWrapper.dbIndex 
            row.itemLink = data.itemLink 
            row.itemNameOnly = string.match(data.itemLink, "%[(.-)%]") or "未知装备" 

            row.itemFS:SetText(data.itemLink) 
            
            local _, _, _, itemLevel, itemMinLevel = GetItemInfo(data.itemLink) 
            
            local displayIlvl = itemLevel or data.itemLevel or 0 
            local displayReqLvl = itemMinLevel or data.reqLevel or 0 
            
            if displayIlvl > 1 then row.ilvlText:SetText(displayIlvl) else row.ilvlText:SetText("-") end 
            if displayReqLvl > 1 then row.reqLevelText:SetText(displayReqLvl) else row.reqLevelText:SetText("-") end 
            
            local socketStr, tertiaryStr = GetItemExtraDetails(data.itemLink) 
            row.socketText:SetText(socketStr) 
            row.tertiaryText:SetText(tertiaryStr) 

            row.timeText:SetText(data.time) 
            row.locationText:SetText(data.location) 
            
            local classColor = "ffffffff" 
            if data.className and RAID_CLASS_COLORS[data.className] then 
                classColor = RAID_CLASS_COLORS[data.className].colorStr 
            end 
            row.playerText:SetText(string.format("|c%s%s|r", classColor, data.player)) 

            row:Show() 
        else 
            row.dbIndex = nil 
            row:Hide() 
        end 
    end 
end 

scrollFrame:SetScript("OnVerticalScroll", function(self, offset) 
    FauxScrollFrame_OnVerticalScroll(self, offset, 24, EpicLootTracker_UpdateUI) 
end) 

-- ==========================================
-- 6. 事件监听与 Boss 数据记录
-- ==========================================
local eventHandler = CreateFrame("Frame") 
eventHandler:RegisterEvent("ADDON_LOADED") 
eventHandler:RegisterEvent("ENCOUNTER_LOOT_RECEIVED") 
eventHandler:RegisterEvent("CHAT_MSG_LOOT") 
eventHandler:RegisterEvent("ENCOUNTER_END") 

local function FormatPlayerName(rawName) 
    if not rawName or rawName == "" then return UnitName("player") .. "-" .. GetRealmName() end 
    if not string.find(rawName, "-") then return rawName .. "-" .. GetRealmName() end 
    return rawName 
end 

local function RecordLoot(itemLink, playerName, className) 
    if not itemLink then return end 
    
    local _, _, itemRarity, itemLevel, itemMinLevel = GetItemInfo(itemLink) 
    if not itemRarity or itemRarity < 3 then return end 
    
    local itemID = tonumber(string.match(itemLink, "item:(%d+)")) 
    
    if not EpicLootTrackerConfig.blacklist then EpicLootTrackerConfig.blacklist = {} end 
    if itemID and EpicLootTrackerConfig.blacklist[itemID] then return end  

    if itemRarity == 3 and not EpicLootTrackerConfig.recordBlue then  
        if not (itemID and EpicLootTrackerConfig.whitelist and EpicLootTrackerConfig.whitelist[itemID]) then 
            return   
        end 
    end 

    local formattedPlayer = FormatPlayerName(playerName) 
    local curTimeStr = date("%Y-%m-%d %H:%M:%S") 

    local linkedBossName = (currentBossName and (time() - currentBossTime <= 180)) and currentBossName or nil 

    local record = { 
        itemLink = itemLink, 
        rarity = itemRarity, 
        itemLevel = itemLevel or 0,  
        reqLevel = itemMinLevel or 0,  
        timestamp = time(), 
        time = curTimeStr, 
        location = GetRealZoneText() or "未知区域", 
        player = formattedPlayer, 
        className = className, 
        recorder = UnitName("player"), 
        bossName = linkedBossName 
    } 

    table.insert(EpicLootTrackerDB, 1, record) 

    if linkedBossName then 
        EpicLootBossDB[linkedBossName] = EpicLootBossDB[linkedBossName] or { kills = 0, loots = {} } 
        table.insert(EpicLootBossDB[linkedBossName].loots, 1, { 
            itemLink = itemLink, 
            player = formattedPlayer, 
            time = curTimeStr 
        }) 
        if BossStatFrame and BossStatFrame:IsShown() then EpicLootTracker_UpdateBossUI() end 
    end 

    if mainFrame:IsShown() then  
        EpicLootTracker_BuildData() 
        EpicLootTracker_UpdateUI()  
    end 
end 

eventHandler:SetScript("OnEvent", function(self, event, ...) 
    if event == "ADDON_LOADED" then 
        local addon = ... 
        if addon == addonName then 
            EpicLootTrackerDB = EpicLootTrackerDB or {} 
            EpicLootBossDB = EpicLootBossDB or {} 
            
            local currentYear = tonumber(date("%Y")) 
            for _, data in ipairs(EpicLootTrackerDB) do 
                if not data.rarity then data.rarity = 4 end 
                if not data.timestamp then 
                    if data.time then 
                        local mo, d, h, m, s = string.match(data.time, "^(%d%d)%-(%d%d) (%d%d):(%d%d):(%d%d)$") 
                        if mo then 
                            data.timestamp = time({year=currentYear, month=tonumber(mo), day=tonumber(d), hour=tonumber(h), min=tonumber(m), sec=tonumber(s)}) 
                            data.time = string.format("%04d-%02d-%02d %02d:%02d:%02d", currentYear, tonumber(mo), tonumber(d), tonumber(h), tonumber(m), tonumber(s)) 
                        else 
                            data.timestamp = time() 
                        end 
                    else 
                        data.timestamp = time() 
                        data.time = date("%Y-%m-%d %H:%M:%S", data.timestamp) 
                    end 
                end 
            end 
            
            EpicLootTrackerConfig = EpicLootTrackerConfig or {} 
            if EpicLootTrackerConfig.recordBlue == nil then EpicLootTrackerConfig.recordBlue = false end 
            if EpicLootTrackerConfig.recordSolo == nil then EpicLootTrackerConfig.recordSolo = false end 
            
            if EpicLootTrackerConfig.enableBossWhitelist == nil then  
                EpicLootTrackerConfig.enableBossWhitelist = true  
            end 
            if not EpicLootTrackerConfig.bossWhitelist then 
                EpicLootTrackerConfig.bossWhitelist = { 
                    ["海姆达尔"] = true, 
                    ["芬雷尔"] = true, 
                    ["斯特拉达玛侯爵"] = true, 
                    ["伊库斯博士"] = true, 
                    ["酤团"] = true, 
                    ["多米娜·毒刃"] = true, 
                } 
            end 
            
            if not EpicLootTrackerConfig.blacklist then EpicLootTrackerConfig.blacklist = {} end 
            if not EpicLootTrackerConfig.whitelist then 
                EpicLootTrackerConfig.whitelist = { 
                    [9425] = true, [9423] = true, [9431] = true, [9429] = true, 
                } 
            end 
            
            mainFrame.chkRecordBlue:SetChecked(EpicLootTrackerConfig.recordBlue) 
            mainFrame.chkRecordSolo:SetChecked(EpicLootTrackerConfig.recordSolo) 
        end 

    elseif event == "ENCOUNTER_END" then 
        local encounterID, encounterName, difficultyID, groupSize, success = ... 
        if success == 1 and encounterName then 
            
            if EpicLootTrackerConfig.enableBossWhitelist then 
                if not EpicLootTrackerConfig.bossWhitelist or not EpicLootTrackerConfig.bossWhitelist[encounterName] then 
                    return  
                end 
            end 

            currentBossName = encounterName 
            currentBossTime = time() 

            EpicLootBossDB[encounterName] = EpicLootBossDB[encounterName] or { kills = 0, loots = {} } 
            EpicLootBossDB[encounterName].kills = EpicLootBossDB[encounterName].kills + 1 
            EpicLootBossDB[encounterName].lastKillTime = date("%Y-%m-%d %H:%M:%S") 

            print(string.format("|cff00ff00[EpicLootTracker]|r 成功击杀 Boss: |cffffd100%s|r (累计击杀: %d 次)", encounterName, EpicLootBossDB[encounterName].kills)) 
            if BossStatFrame and BossStatFrame:IsShown() then EpicLootTracker_UpdateBossUI() end 
        end 

    elseif event == "ENCOUNTER_LOOT_RECEIVED" then 
        if not IsInGroup() and not EpicLootTrackerConfig.recordSolo then return end 
        local encounterID, itemID, itemLink, quantity, playerName, className = ... 
        RecordLoot(itemLink, playerName, className) 

    elseif event == "CHAT_MSG_LOOT" then 
        if not IsInGroup() and not EpicLootTrackerConfig.recordSolo then return end 
        local text, rawPlayer = ... 
        local itemLink = string.match(text, "(|c%x+|Hitem:.-|h%[.-%] |h|r)") 
        if itemLink then 
            if string.find(itemLink:lower(), "|cff0070dd") or string.find(itemLink:lower(), "|cffa335ee") then 
                RecordLoot(itemLink, rawPlayer, nil) 
            end 
        end 
    end 
end) 

-- ==========================================
-- 7. Slash 指令绑定与装备统计按钮附加
-- ==========================================
SLASH_EPICLOOTTRACKER1 = "/elt" 
SLASH_EPICLOOTTRACKER2 = "/epicloot" 
SlashCmdList["EPICLOOTTRACKER"] = function() 
    if mainFrame:IsShown() then 
        mainFrame:Hide() 
    else 
        mainFrame:Show() 
        EpicLootTracker_BuildData() 
        EpicLootTracker_UpdateUI() 
    end 
end 

if mainFrame and not mainFrame.equipStatBtn then 
    mainFrame.equipStatBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate") 
    mainFrame.equipStatBtn:SetSize(90, 22) 
    mainFrame.equipStatBtn:SetPoint("LEFT", mainFrame.bossStatBtn, "RIGHT", 10, 0) 
    mainFrame.equipStatBtn:SetText("装备统计") 
    mainFrame.equipStatBtn:SetScript("OnClick", function() 
        if not EquipStatFrame then CreateEquipStatUI() end 
        EquipStatFrame.strictBossFilter = nil  
        EquipStatFrame:Show() 
        EquipStatFrame.RefreshUI() 
    end) 
end