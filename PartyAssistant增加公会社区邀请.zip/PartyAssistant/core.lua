local addonName, addonTable = ...

-- 初始化数据库与默认值配置
PartyAssistantDB = PartyAssistantDB or {}
PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
PartyAssistantDB.groupCollapsed = PartyAssistantDB.groupCollapsed or {}
PartyAssistantDB.autoLeader = PartyAssistantDB.autoLeader or nil
if PartyAssistantDB.hideNames == nil then PartyAssistantDB.hideNames = false end
if PartyAssistantDB.autoReset == nil then PartyAssistantDB.autoReset = false end
if PartyAssistantDB.enableRecord == nil then PartyAssistantDB.enableRecord = true end
if PartyAssistantDB.isCDAccount == nil then PartyAssistantDB.isCDAccount = false end
if PartyAssistantDB.subAccountName == nil then PartyAssistantDB.subAccountName = "" end
PartyAssistantDB.subAccountMap = PartyAssistantDB.subAccountMap or {}
PartyAssistantDB.currentInstanceLock = PartyAssistantDB.currentInstanceLock or {}

-- 【新增】社区名保存列表与当前选中项
PartyAssistantDB.savedCommunities = PartyAssistantDB.savedCommunities or {}
PartyAssistantDB.selectedCommunity = PartyAssistantDB.selectedCommunity or ""

-- 兼容旧版非 table 结构的 currentInstanceLock
if type(PartyAssistantDB.currentInstanceLock) ~= "table" or PartyAssistantDB.currentInstanceLock.id ~= nil then
    PartyAssistantDB.currentInstanceLock = {}
end

local MAX_RECENT_PLAYERS = 100
local INSTANCE_LIMIT = 10     -- 1小时进本上限次数
local ONE_HOUR = 3600         -- 1小时（秒）
local addonLoadTime = GetTime()

-- API 本地化与兼容防护
local UnitName = UnitName
local GetRealmName = GetRealmName
local UnitClass = UnitClass
local UnitLevel = UnitLevel
local UnitIsGroupLeader = UnitIsGroupLeader
local UnitIsConnected = UnitIsConnected
local UnitExists = UnitExists
local IsInGroup = IsInGroup
local IsInRaid = IsInRaid
local GetNumGroupMembers = GetNumGroupMembers
local PromoteToLeader = PromoteToLeader
local InviteUnit = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
local UninviteUnit = UninviteUnit
local IsInInstance = IsInInstance
local GetInstanceInfo = GetInstanceInfo
local SendChatMessage = SendChatMessage
local IsLegacyLootMode = IsLegacyLootMode
local GetLootMethod = GetLootMethod

-- 单位名称运行时缓存
local activeGroupNames = {}
local wasInInstance = false
local isFirstWorldEnter = true

-- 记录系统黄字提示的经典拾取状态
local isLegacyLootModeActive = false

-- ==========================================
-- 拾取模式与副本难度逻辑处理
-- ==========================================
local function GetLootModeText()
    local isLegacy = isLegacyLootModeActive
                  or (C_Loot and C_Loot.IsLegacyLootMode and C_Loot.IsLegacyLootMode()) 
                  or (IsLegacyLootMode and IsLegacyLootMode())
    
    if isLegacy then return "|cffffcc00经典|r" end

    local method = GetLootMethod and GetLootMethod()
    if method == "master" then return "|cffffaa00队长分配|r"
    elseif method == "group" then return "|cff00ccff队伍分配|r"
    elseif method == "freeforall" then return "|cffff5555自由拾取|r" end

    return "|cff00ff00个人|r"
end

local function GetCurrentDifficultyText()
    local inInstance = IsInInstance()
    if inInstance then
        local _, _, _, difficultyName = GetInstanceInfo()
        return difficultyName or "未知"
    else
        local diffID = GetDungeonDifficultyID and GetDungeonDifficultyID() or 1
        if diffID == 1 then return "|cff00ff00普通|r"
        elseif diffID == 2 then return "|cffff9900英雄|r"
        elseif diffID == 23 then return "|cffff0000史诗|r"
        else
            local diffName = GetDifficultyInfo and GetDifficultyInfo(diffID)
            return diffName or ("难度 " .. tostring(diffID))
        end
    end
end

local function SetDifficulty(diffID)
    if IsInGroup() and not UnitIsGroupLeader("player") then
        print("|cffff0000[组队助手]|r 只有队长才能切换副本难度！")
        return
    end
    if InCombatLockdown() then
        print("|cffff0000[组队助手]|r 战斗中无法切换副本难度！")
        return
    end
    if SetDungeonDifficultyID then
        SetDungeonDifficultyID(diffID)
        local names = { [1] = "普通", [2] = "英雄", [23] = "史诗" }
        print(string.format("|cff00ff00[组队助手]|r 队伍副本难度已切换为: |cffffcc00%s|r", names[diffID] or diffID))
    end
    C_Timer.After(0.2, function()
        if PartyAssistant_UpdateDifficultyDisplay then
            PartyAssistant_UpdateDifficultyDisplay()
        end
    end)
end

-- ==========================================
-- 子账号与分组同步通信逻辑
-- ==========================================
local SYNC_PREFIX = "PA_SUB_SYNC"
local GRP_SYNC_PREFIX = "PA_GRP_SYNC" 
local INST_SYNC_PREFIX = "PA_INST_SYNC"

local syncRecvCache = {} 
local grpSyncRecvCache = {} 
local syncSendCache = { lastMsg = nil, lastTime = 0, lastGroupCount = 0, lastLeader = nil }

local function BroadcastAddonMessage(prefix, payload)
    if not IsInGroup() then return end
    
    local channel = "PARTY"
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then channel = "INSTANCE_CHAT"
    elseif IsInRaid() then channel = "RAID" end

    if C_ChatInfo and C_ChatInfo.SendAddonMessage then C_ChatInfo.SendAddonMessage(prefix, payload, channel)
    elseif SendAddonMessage then SendAddonMessage(prefix, payload, channel) end
end

local function SendSubAccountSync(force)
    if not IsInGroup() then
        syncSendCache.lastGroupCount = 0 
        return
    end
    if not PartyAssistantDB.subAccountName or PartyAssistantDB.subAccountName == "" then return end

    local msg = PartyAssistantDB.subAccountName
    local now = GetTime()
    local currentGroupCount = GetNumGroupMembers()
    local currentLeader = nil
    local isRaid = IsInRaid()
    local prefixStr = isRaid and "raid" or "party"
    for i = 1, currentGroupCount do
        local unit = isRaid and (prefixStr..i) or (i == currentGroupCount and "player" or prefixStr..i)
        if UnitExists(unit) and UnitIsGroupLeader(unit) then
            local name, realm = UnitName(unit)
            currentLeader = (name or "Unknown") .. "-" .. (realm or GetRealmName())
            break
        end
    end

    if not force then
        if currentGroupCount == syncSendCache.lastGroupCount
           and currentLeader == syncSendCache.lastLeader
           and msg == syncSendCache.lastMsg
           and (now - syncSendCache.lastTime) < 60 then
            return
        end
    end

    BroadcastAddonMessage(SYNC_PREFIX, msg)

    syncSendCache.lastMsg = msg
    syncSendCache.lastTime = now
    syncSendCache.lastGroupCount = currentGroupCount
    syncSendCache.lastLeader = currentLeader
end

local function SendGroupSync(groupName, members)
    if not IsInGroup() then return end
    if not members or #members == 0 then return end

    local senderName = UnitName("player") or "Unknown"
    local baseTimestampMs = math.floor(GetTime() * 1000)
    local currentPacket = {}
    local currentLen = 0
    local packetCount = 0

    for _, member in ipairs(members) do
        local classStr = member.class or ""
        local levelStr = member.level or 0
        local memberData = member.fullName .. ":" .. classStr .. ":" .. levelStr
        
        if currentLen + #memberData > 200 then
            packetCount = packetCount + 1
            local syncID = string.format("%s_%d_%d", senderName, baseTimestampMs, packetCount)
            BroadcastAddonMessage(GRP_SYNC_PREFIX, syncID .. "|" .. groupName .. "|" .. table.concat(currentPacket, ","))
            currentPacket = {}
            currentLen = 0
        end
        table.insert(currentPacket, memberData)
        currentLen = currentLen + #memberData + 1
    end

    if #currentPacket > 0 then
        packetCount = packetCount + 1
        local syncID = string.format("%s_%d_%d", senderName, baseTimestampMs, packetCount)
        BroadcastAddonMessage(GRP_SYNC_PREFIX, syncID .. "|" .. groupName .. "|" .. table.concat(currentPacket, ","))
    end
end

-- ==========================================
-- 自动移交指定队长逻辑
-- ==========================================
local lastLeaderFullName = nil
local lastIsRaidState = nil
local groupTransitionLockTime = 0 

local function CheckAndPromoteDesignatedLeader()
    if not IsInGroup() then lastIsRaidState = nil return end
    
    local isRaid = IsInRaid()
    if lastIsRaidState ~= nil and lastIsRaidState ~= isRaid then groupTransitionLockTime = GetTime() + 5 end
    lastIsRaidState = isRaid

    if GetTime() < groupTransitionLockTime then return end

    local numMembers = GetNumGroupMembers()
    local prefix = isRaid and "raid" or "party"
    local currentLeaderFullName = nil

    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        if UnitExists(unit) and UnitIsGroupLeader(unit) then
            local name, realm = UnitName(unit)
            currentLeaderFullName = (name or "") .. "-" .. (realm or GetRealmName())
            break
        end
    end

    local isPlayerLeader = UnitIsGroupLeader("player")
    if isPlayerLeader and lastLeaderFullName and PartyAssistantDB.autoLeader 
       and lastLeaderFullName == PartyAssistantDB.autoLeader 
       and currentLeaderFullName and currentLeaderFullName ~= PartyAssistantDB.autoLeader then
        PartyAssistantDB.altLoggingOutLock = time() + 30
    end

    if currentLeaderFullName then lastLeaderFullName = currentLeaderFullName end
    if PartyAssistantDB.altLoggingOutLock and time() < PartyAssistantDB.altLoggingOutLock then return end

    if not isPlayerLeader then return end
    if not PartyAssistantDB.autoLeader or PartyAssistantDB.autoLeader == "" then return end

    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        if not UnitIsUnit(unit, "player") and UnitIsConnected(unit) then
            local name, realm = UnitName(unit)
            local fullName = (name or "") .. "-" .. (realm or GetRealmName())
            if fullName == PartyAssistantDB.autoLeader and not UnitIsGroupLeader(unit) then
                PromoteToLeader(unit)
                print(string.format("|cff00ff00[组队助手]|r 检测到核心角色上线，已自动将队长移交至: |cffffcc00%s|r", fullName))
                break
            end
        end
    end
end

-- ==========================================
-- 爆本监控与报警核心逻辑
-- ==========================================
local function GetSubAccountKey()
    local realm = GetRealmName() or "UnknownRealm"
    if PartyAssistantDB.subAccountName and PartyAssistantDB.subAccountName ~= "" then
        return PartyAssistantDB.subAccountName .. "-" .. realm
    end
    return "DEFAULT-" .. realm
end

local function CleanAndGetInstanceHistory()
    PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
    local key = GetSubAccountKey()
    
    if PartyAssistantDB.instanceRuns[1] then
        local oldRuns = PartyAssistantDB.instanceRuns
        PartyAssistantDB.instanceRuns = {}
        PartyAssistantDB.instanceRuns[key] = oldRuns
    end

    PartyAssistantDB.instanceRuns[key] = PartyAssistantDB.instanceRuns[key] or {}
    local now = time()
    local validRuns = {}
    for _, entry in ipairs(PartyAssistantDB.instanceRuns[key]) do
        local entryTime = (type(entry) == "table") and entry.time or entry
        if (now - entryTime) < ONE_HOUR then
            table.insert(validRuns, entry)
        end
    end
    PartyAssistantDB.instanceRuns[key] = validRuns
    return validRuns
end

local lastInstSyncTime = 0
local function SyncInstanceHistory()
    if PartyAssistantDB.isCDAccount then return end -- 【拦截】CD号不向外广播进度
    if not IsInGroup() then return end
    local now = GetTime()
    if (now - lastInstSyncTime) < 5 then return end
    lastInstSyncTime = now

    local runs = CleanAndGetInstanceHistory()
    local payload = {}
    for _, run in ipairs(runs) do
        local rTime = (type(run) == "table") and run.time or run
        local rId = (type(run) == "table") and (run.id or 0) or 0
        local rGuid = (type(run) == "table") and (run.guid or rTime) or rTime
        table.insert(payload, string.format("%s-%s-%s", rId, rTime, rGuid))
    end
    if #payload > 0 then
        BroadcastAddonMessage(INST_SYNC_PREFIX, table.concat(payload, ","))
    end
end

local function MergeInstanceHistory(payload)
    if not payload or payload == "" then return end
    local key = GetSubAccountKey()
    local localRuns = CleanAndGetInstanceHistory()
    local updated = false

    for pair in payload:gmatch("[^,]+") do
        local rId, rTime, rGuid = pair:match("^(%d+)%-(%d+)%-(%d+)$")
        if not rId then
            rId, rTime = pair:match("^(%d+)%-(%d+)$")
            rGuid = rTime
        end
        
        if rId and rTime then
            rId = tonumber(rId)
            rTime = tonumber(rTime)
            rGuid = tonumber(rGuid) or rTime
            
            local found = false
            for _, lRun in ipairs(localRuns) do
                local lTime = (type(lRun) == "table") and lRun.time or lRun
                local lId = (type(lRun) == "table") and (lRun.id or 0) or 0
                local lGuid = (type(lRun) == "table") and (lGuid or lTime) or lTime
                
                if lGuid == rGuid or (lId == rId and math.abs(lTime - rTime) < 180) then
                    found = true
                    break
                end
            end
            
            if not found and (time() - rTime) < ONE_HOUR then
                table.insert(localRuns, { id = rId, time = rTime, guid = rGuid })
                updated = true
            end
        end
    end
    
    if updated then
        table.sort(localRuns, function(a, b)
            local tA = (type(a) == "table") and a.time or a
            local tB = (type(b) == "table") and b.time or b
            return tA < tB
        end)
        PartyAssistantDB.instanceRuns[key] = localRuns
        if PartyAssistantFrame and PartyAssistantFrame:IsShown() then 
            PartyAssistant_UpdateTrackerDisplay() 
        end
    end
end

local function CheckAndPlayLockoutWarning(count)
    C_Timer.After(2, function()
        if count >= INSTANCE_LIMIT then
            PlaySound(8959, "Master")
            print(string.format("|cffff0000[组队助手警报]|r 【已爆本】当前1小时内已进本 |cffffcc00%d/%d|r 次！已被系统锁定，请暂停刷本！", count, INSTANCE_LIMIT))
            if RaidNotice_AddMessage and RaidWarningFrame then
                RaidNotice_AddMessage(RaidWarningFrame, " 已达爆本上限(10次), 请暂停刷本！", ChatTypeInfo["RAID_WARNING"])
            elseif UIErrorsFrame then
                UIErrorsFrame:AddMessage(" 已达爆本上限(10次), 请暂停刷本！", 1.0, 0.1, 0.1, 1.0)
            end
        elseif count >= 8 then
            if not PlaySound(56740, "Master") then
                PlaySound(8959, "Master")
            end
            print(string.format("|cffff9900[组队助手提示]|r 【即将爆本】当前1小时内已进本 |cffffcc00%d/%d|r 次，请注意控制节奏！", count, INSTANCE_LIMIT))
            if RaidNotice_AddMessage and RaidWarningFrame then
                RaidNotice_AddMessage(RaidWarningFrame, string.format(" 即将爆本警告：已进本 %d/10 次", count), ChatTypeInfo["RAID_WARNING"])
            elseif UIErrorsFrame then
                UIErrorsFrame:AddMessage(string.format(" 即将爆本警告：已进本 %d/10 次", count), 1.0, 0.5, 0.0, 1.0)
            end
        end
    end)
end

local function RecordInstanceRun(instanceID)
    local key = GetSubAccountKey()
    local runs = CleanAndGetInstanceHistory()
    local now = time()
    
    PartyAssistantDB.currentInstanceLock = PartyAssistantDB.currentInstanceLock or {}
    local lock = PartyAssistantDB.currentInstanceLock[key] or { id = nil, lockTime = 0, guid = nil }
    
    if lock and lock.id == instanceID and (now - lock.lockTime) < 900 then
        lock.lockTime = now
        PartyAssistantDB.currentInstanceLock[key] = lock
        return
    end

    if #runs > 0 then
        local lastEntry = runs[#runs]
        local lastTime = (type(lastEntry) == "table") and lastEntry.time or lastEntry
        local lastID = (type(lastEntry) == "table") and lastEntry.id or nil
        
        if lastID and instanceID and lastID == instanceID and (now - lastTime) < 180 then
            PartyAssistantDB.currentInstanceLock[key] = { id = instanceID, lockTime = now, guid = (type(lastEntry) == "table" and lastEntry.guid or lastTime) }
            return
        end
    end

    local runGUID = now
    table.insert(runs, { time = now, id = instanceID, guid = runGUID })
    PartyAssistantDB.instanceRuns[key] = runs
    
    PartyAssistantDB.currentInstanceLock[key] = { id = instanceID, lockTime = now, guid = runGUID }
    
    CheckAndPlayLockoutWarning(#runs)
    SyncInstanceHistory()
end

local function GetInstanceTimerInfo()
    local runs = CleanAndGetInstanceHistory()
    local count = #runs
    local timeRemaining = 0
    if count > 0 then
        local oldest = runs[1]
        local oldestTime = (type(oldest) == "table") and oldest.time or oldest
        timeRemaining = ONE_HOUR - (time() - oldestTime)
        if timeRemaining < 0 then timeRemaining = 0 end
    end
    return count, timeRemaining
end

local function FormatTimer(seconds)
    if seconds <= 0 then return "无" end
    local m = math.floor(seconds / 60)
    local s = math.floor(seconds % 60)
    return string.format("%02d分%02d秒", m, s)
end

local lastResetTime = 0

local function SafeResetInstances()
    if IsInGroup() and not UnitIsGroupLeader("player") then
        print("|cffff0000[组队助手]|r 只有队长才能重置副本！")
        return
    end

    local now = GetTime()
    if (now - lastResetTime) < 5 then return end
    lastResetTime = now

    if C_PartyInfo and C_PartyInfo.ResetInstances then
        C_PartyInfo.ResetInstances()
    elseif ResetInstances then
        ResetInstances()
    end
    
    local key = GetSubAccountKey()
    PartyAssistantDB.currentInstanceLock = PartyAssistantDB.currentInstanceLock or {}
    PartyAssistantDB.currentInstanceLock[key] = { id = nil, lockTime = 0, guid = nil }
    BroadcastAddonMessage(INST_SYNC_PREFIX, "RESET")
    
    print("|cff00ff00[组队助手]|r 已尝试重置副本。")

    if IsInGroup() then
        local chatType = IsInRaid() and "RAID" or "PARTY"
        if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
            chatType = "INSTANCE_CHAT"
        end
        SendChatMessage("【组队助手】副本已重置成功！", chatType)
    end
end

local function CheckAllOfflineAutoReset()
    if not PartyAssistantDB.autoReset then return end
    if (GetTime() - addonLoadTime) < 8 then return end
    if not IsInGroup() then return end
    if not UnitIsGroupLeader("player") then return end
    if GetTime() < groupTransitionLockTime then return end
    
    local numMembers = GetNumGroupMembers()
    if numMembers <= 1 then return end 

    local isRaid = IsInRaid()
    local prefix = isRaid and "raid" or "party"
    local otherCount = 0
    local offlineCount = 0

    for i = 1, numMembers do
        local unit = isRaid and (prefix .. i) or (i == numMembers and "player" or (prefix .. i))
        if UnitExists(unit) and not UnitIsUnit(unit, "player") then
            otherCount = otherCount + 1
            if not UnitIsConnected(unit) then
                offlineCount = offlineCount + 1
            end
        end
    end

    if otherCount > 0 and offlineCount == otherCount then
        SafeResetInstances()
        print("|cff00ff00[组队助手]|r 检测到队友全员离线，已触发自动重置副本。")
    end
end

local function CheckInstanceEntry()
    local inInstance, instanceType = IsInInstance()
    local _, _, _, _, _, _, _, instanceID = GetInstanceInfo()
    
    if inInstance and (instanceType == "party" or instanceType == "raid") then
        if not wasInInstance then
            wasInInstance = true
            if isFirstWorldEnter then
                isFirstWorldEnter = false
                return
            end
            RecordInstanceRun(instanceID)
            CheckAllOfflineAutoReset()
            if PartyAssistantFrame and PartyAssistantFrame:IsShown() then
                PartyAssistant_UpdateTrackerDisplay()
            end
        end
    else
        wasInInstance = false
        isLegacyLootModeActive = false -- 出副本时重置经典拾取状态
    end
    isFirstWorldEnter = false
end

local function GetUnitLocation(unit)
    if not unit or not UnitExists(unit) then return "未知位置" end
    if UnitIsUnit(unit, "player") then
        return (GetRealZoneText and GetRealZoneText()) or (GetZoneText and GetZoneText()) or "未知位置"
    end
    if C_Map and C_Map.GetBestMapForUnit then
        local mapID = C_Map.GetBestMapForUnit(unit)
        if mapID then
            local mapInfo = C_Map.GetMapInfo(mapID)
            if mapInfo and mapInfo.name then return mapInfo.name end
        end
    end
    return "未知位置"
end

local function UpdateSnowballMacroSingle(data)
    if InCombatLockdown() then
        print("|cffff0000[组队助手]|r 战斗中无法修改宏，请脱战后重试！")
        return
    end
    local macroName = "雪球宏"
    local playerRealm = GetRealmName()
    local targetName = (data.realm and data.realm ~= "" and data.realm ~= playerRealm) and data.fullName or data.shortName
    local macroBody = string.format("#showtooltip 静滞砂砾\n/promote %s\n/use 静滞砂砾\n/logout", targetName)
    local macroIndex = GetMacroIndexByName(macroName)
    if macroIndex > 0 then
        EditMacro(macroIndex, macroName, "INV_Misc_QuestionMark", macroBody)
        print(string.format("|cff00ff00[组队助手]|r 【雪球宏】已成功更新！转移目标设为：|cff00ffff%s|r", data.fullName))
    else
        CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, false)
        print(string.format("|cff00ff00[组队助手]|r 已创建【雪球宏】！转移目标：|cff00ffff%s|r", data.fullName))
    end
end

local function UpdateFollowMacroSingle(data)
    if InCombatLockdown() then
        print("|cffff0000[组队助手]|r 战斗中无法修改宏，请脱战后重试！")
        return
    end
    
    local macroName = "跟随宏"
    local playerRealm = GetRealmName()
    local targetName = (data.realm and data.realm ~= "" and data.realm ~= playerRealm) and data.fullName or data.shortName
    local macroBody = string.format("/follow %s", targetName)
    
    local macroIndex = GetMacroIndexByName(macroName)
    if macroIndex > 0 then
        EditMacro(macroIndex, macroName, "Ability_Hunter_Pet_Goto", macroBody)
        print(string.format("|cff00ff00[组队助手]|r 【跟随宏】已成功更新！当前跟随目标：|cff00ffff%s|r", data.fullName))
    else
        CreateMacro(macroName, "Ability_Hunter_Pet_Goto", macroBody, false)
        print(string.format("|cff00ff00[组队助手]|r 已创建【跟随宏】！当前跟随目标：|cff00ffff%s|r", data.fullName))
    end
end

-- ==========================================
-- 数据处理与近期往来分组逻辑
-- ==========================================
local systemKeys = {
    instanceRuns = true, groups = true, groupCollapsed = true, hideNames = true, 
    autoLeader = true, autoReset = true, enableRecord = true, isCDAccount = true,
    subAccountName = true, subAccountMap = true, currentInstanceLock = true, altLoggingOutLock = true,
    savedCommunities = true, selectedCommunity = true -- 【新增】
}

local function CleanupRecentDB()
    PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
    PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
    PartyAssistantDB.groupCollapsed = PartyAssistantDB.groupCollapsed or {}
    PartyAssistantDB.subAccountMap = PartyAssistantDB.subAccountMap or {}

    for k, v in pairs(PartyAssistantDB) do
        if not systemKeys[k] then
            if type(v) ~= "table" or not v.time or not v.shortName or v.shortName == "未知" or k:find("未知") then
                PartyAssistantDB[k] = nil
            else
                if not v.groups or type(v.groups) ~= "table" then
                    local oldGroup = v.group or "无分组"
                    v.groups = { [oldGroup] = true }
                    v.group = nil
                end
            end
        end
    end

    local count = 0
    for k in pairs(PartyAssistantDB) do
        if not systemKeys[k] then count = count + 1 end
    end
    
    if count > MAX_RECENT_PLAYERS then
        local temp = {}
        for name, data in pairs(PartyAssistantDB) do
            if not systemKeys[name] and type(data) == "table" and data.time then
                table.insert(temp, {name = name, time = data.time, data = data})
            end
        end
        table.sort(temp, function(a, b) return a.time > b.time end)
        
        local savedData = {}
        for sysKey in pairs(systemKeys) do
            savedData[sysKey] = PartyAssistantDB[sysKey]
        end
        
        table.wipe(PartyAssistantDB)
        for sysKey, val in pairs(savedData) do
            PartyAssistantDB[sysKey] = val
        end
        
        for i = 1, MAX_RECENT_PLAYERS do
            local t = temp[i]
            if t then PartyAssistantDB[t.name] = t.data end
        end
    end
end

local function RecordGroupMembers()
    if not IsInGroup() then
        table.wipe(activeGroupNames)
        return
    end
    
    if not PartyAssistantDB.enableRecord then return end
    
    local isRaid = IsInRaid()
    local numMembers = GetNumGroupMembers()
    local prefix = isRaid and "raid" or "party"
    local addedNew = false
    
    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        if UnitExists(unit) then
            local name, realm = UnitName(unit)
            local isHex = name and name:match("^%x+$") and #name >= 6
            if name and name ~= "" and name ~= "未知" and not isHex then
                realm = realm or GetRealmName()
                activeGroupNames[unit] = { name = name, realm = realm }
                
                local fullName = name .. "-" .. realm
                local _, classToken = UnitClass(unit)
                local level = UnitLevel(unit)
                
                if not PartyAssistantDB[fullName] then
                    PartyAssistantDB[fullName] = {
                        time = time(),
                        class = classToken,
                        level = level,
                        realm = realm,
                        shortName = name,
                        groups = { ["无分组"] = true }
                    }
                else
                    PartyAssistantDB[fullName].time = time()
                    PartyAssistantDB[fullName].class = classToken or PartyAssistantDB[fullName].class
                    if level and level > 0 then
                        PartyAssistantDB[fullName].level = level
                    end
                    if not PartyAssistantDB[fullName].groups or type(PartyAssistantDB[fullName].groups) ~= "table" then
                        PartyAssistantDB[fullName].groups = { ["无分组"] = true }
                    end
                end
                addedNew = true
            end
        end
    end
    
    CheckAllOfflineAutoReset()

    if addedNew then
        CleanupRecentDB()
        if PartyAssistantFrame and PartyAssistantFrame:IsShown() and PartyAssistantFrame.currentTab == 2 then
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
        end
    end
end

-- ==========================================
-- UI 界面构建
-- ==========================================
local mainFrame = CreateFrame("Frame", "PartyAssistantFrame", UIParent, "BasicFrameTemplateWithInset")
mainFrame:SetSize(530, 580)
mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
mainFrame:Hide()
mainFrame:SetMovable(true)
mainFrame:EnableMouse(true)
mainFrame:RegisterForDrag("LeftButton")
mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing)
mainFrame:SetScript("OnShow", function()
    if mainFrame.hideNameCb then mainFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames) end
    if mainFrame.autoResetCb then mainFrame.autoResetCb:SetChecked(PartyAssistantDB.autoReset) end
    if mainFrame.recordCb then mainFrame.recordCb:SetChecked(PartyAssistantDB.enableRecord) end
    if PartyAssistant_UpdateZoneAndLootDisplay then PartyAssistant_UpdateZoneAndLootDisplay() end
    if PartyAssistant_UpdateDifficultyDisplay then PartyAssistant_UpdateDifficultyDisplay() end
end)

mainFrame.title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.title:SetPoint("CENTER", mainFrame.TitleBg, "CENTER", 0, 0)
mainFrame.title:SetText("多开组队助手")

-- 顶部位置、拾取模式与难度设置
mainFrame.zoneText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.zoneText:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -28)
mainFrame.zoneText:SetText("位置: " .. GetUnitLocation("player"))

mainFrame.lootText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.lootText:SetPoint("LEFT", mainFrame.zoneText, "RIGHT", 10, 0)
mainFrame.lootText:SetText("拾取: " .. GetLootModeText())

mainFrame.diffText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.diffText:SetPoint("TOPLEFT", mainFrame.zoneText, "BOTTOMLEFT", 0, -6)
mainFrame.diffText:SetText("难度: " .. GetCurrentDifficultyText())

-- 难度切换按钮 (普通 英雄 史诗)
local diffNormalBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
diffNormalBtn:SetSize(40, 18)
diffNormalBtn:SetPoint("LEFT", mainFrame.diffText, "RIGHT", 6, 0)
diffNormalBtn:SetText("N")
diffNormalBtn:SetScript("OnClick", function() SetDifficulty(1) end)
mainFrame.diffNormalBtn = diffNormalBtn

local diffHeroicBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
diffHeroicBtn:SetSize(40, 18)
diffHeroicBtn:SetPoint("LEFT", diffNormalBtn, "RIGHT", 4, 0)
diffHeroicBtn:SetText("H")
diffHeroicBtn:SetScript("OnClick", function() SetDifficulty(2) end)
mainFrame.diffHeroicBtn = diffHeroicBtn

local diffMythicBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
diffMythicBtn:SetSize(40, 18)
diffMythicBtn:SetPoint("LEFT", diffHeroicBtn, "RIGHT", 4, 0)
diffMythicBtn:SetText("M")
diffMythicBtn:SetScript("OnClick", function() SetDifficulty(23) end)
mainFrame.diffMythicBtn = diffMythicBtn

-- 右侧刷新监控控件
mainFrame.trackerText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
mainFrame.trackerText:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -15, -28)

mainFrame.timerText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
mainFrame.timerText:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -15, -42)

mainFrame.recentTimerText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
mainFrame.recentTimerText:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -15, -56)

mainFrame.currentTab = 1
mainFrame.listData = {}

local function SwitchTab(tabId)
    mainFrame.currentTab = tabId
    if tabId == 1 then
        mainFrame.tab1.selected:Show()
        mainFrame.tab2.selected:Hide()
        mainFrame.inviteAllBtn:Hide()
        mainFrame.addGroupBtn:Hide()
        mainFrame.exportBtn:Hide()
        mainFrame.importBtn:Hide()
        mainFrame.hideNameCb:Show()
        mainFrame.autoResetCb:Show()
        mainFrame.recordCb:Show()
        mainFrame.subAccountBtn:Show()
    else
        mainFrame.tab1.selected:Hide()
        mainFrame.tab2.selected:Show()
        mainFrame.inviteAllBtn:Show()
        mainFrame.addGroupBtn:Show()
        mainFrame.exportBtn:Show()
        mainFrame.importBtn:Show()
        mainFrame.hideNameCb:Hide()
        mainFrame.autoResetCb:Hide()
        mainFrame.recordCb:Hide()
        mainFrame.subAccountBtn:Hide()
    end
    PartyAssistant_BuildData()
    PartyAssistant_UpdateUI()
end

local function CreateTab(id, text, posX)
    local btn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
    btn:SetSize(110, 24)
    btn:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", posX, -76)
    btn:SetText(text)
    
    btn.selected = btn:CreateTexture(nil, "OVERLAY")
    btn.selected:SetAllPoints()
    btn.selected:SetColorTexture(1, 0.8, 0, 0.2)
    btn.selected:Hide()

    btn:SetScript("OnClick", function() SwitchTab(id) end)
    return btn
end

mainFrame.tab1 = CreateTab(1, "当前队伍", 15)
mainFrame.tab2 = CreateTab(2, "近期往来", 130)

mainFrame.hideNameCb = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.hideNameCb:SetSize(24, 24)
mainFrame.hideNameCb:SetPoint("TOPLEFT", mainFrame.tab1, "BOTTOMLEFT", 0, -8)
mainFrame.hideNameCb.text = mainFrame.hideNameCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.hideNameCb.text:SetPoint("LEFT", mainFrame.hideNameCb, "RIGHT", 2, 1)
mainFrame.hideNameCb.text:SetText("匿名")
mainFrame.hideNameCb:SetScript("OnClick", function(self)
    PartyAssistantDB.hideNames = self:GetChecked()
    PartyAssistant_UpdateUI()
    if PartyAssistantInfoFrame and PartyAssistantInfoFrame.UpdateInfo then
        PartyAssistantInfoFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
        PartyAssistantInfoFrame.UpdateInfo()
    end
end)

mainFrame.autoResetCb = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.autoResetCb:SetSize(24, 24)
mainFrame.autoResetCb:SetPoint("LEFT", mainFrame.hideNameCb.text, "RIGHT", 10, 0)
mainFrame.autoResetCb.text = mainFrame.autoResetCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.autoResetCb.text:SetPoint("LEFT", mainFrame.autoResetCb, "RIGHT", 2, 1)
mainFrame.autoResetCb.text:SetText("全员离线重置")
mainFrame.autoResetCb:SetScript("OnClick", function(self)
    PartyAssistantDB.autoReset = self:GetChecked()
    if PartyAssistantDB.autoReset then
        print("|cff00ff00[组队助手]|r 已开启【全员离线自动重置副本】功能。")
    else
        print("|cffff9900[组队助手]|r 已关闭【全员离线自动重置副本】功能。")
    end
end)

mainFrame.recordCb = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.recordCb:SetSize(24, 24)
mainFrame.recordCb:SetPoint("LEFT", mainFrame.autoResetCb.text, "RIGHT", 10, 0)
mainFrame.recordCb.text = mainFrame.recordCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.recordCb.text:SetPoint("LEFT", mainFrame.recordCb, "RIGHT", 2, 1)
mainFrame.recordCb.text:SetText("近期记录")
mainFrame.recordCb:SetScript("OnClick", function(self)
    PartyAssistantDB.enableRecord = self:GetChecked()
    if PartyAssistantDB.enableRecord then
        print("|cff00ff00[组队助手]|r 已【开启】近期往来记录功能。")
    else
        print("|cffff9900[组队助手]|r 已【关闭】近期往来记录功能（停止写入新数据）。")
    end
end)

local subAccountBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
subAccountBtn:SetSize(65, 22)
subAccountBtn:SetPoint("LEFT", mainFrame.recordCb.text, "RIGHT", 12, 0)
subAccountBtn:SetText("子账号")
subAccountBtn:SetScript("OnClick", function()
    StaticPopupDialogs["PARTY_ASSISTANT_SUB_ACCOUNT"] = {
        text = string.format("当前子账号标签: |cff00ffff%s|r\n请输入新的子账号分组/多开标识（如：号A、账号1）：", PartyAssistantDB.subAccountName ~= "" and PartyAssistantDB.subAccountName or "无"),
        button1 = "保存",
        button2 = "取消",
        hasEditBox = true,
        OnShow = function(self)
            self.EditBox:SetText(PartyAssistantDB.subAccountName or "")
            self.EditBox:HighlightText()
        end,
        OnAccept = function(self)
            local text = self.EditBox:GetText()
            PartyAssistantDB.subAccountName = text
            local myFullName = UnitName("player") .. "-" .. GetRealmName()
            PartyAssistantDB.subAccountMap[myFullName] = text
            print(string.format("|cff00ff00[组队助手]|r 子账号标识已更新为: |cffffcc00%s|r", text))
            SendSubAccountSync(true)
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
        end,
        timeout = 0, whileDead = true, hideOnEscape = true,
    }
    StaticPopup_Show("PARTY_ASSISTANT_SUB_ACCOUNT")
end)
mainFrame.subAccountBtn = subAccountBtn

local scrollFrame = CreateFrame("ScrollFrame", "PartyAssistantScroll", mainFrame, "FauxScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -136)
scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -35, 75)

local ROW_COUNT = 8
local ROW_HEIGHT = 40
mainFrame.rows = {}

for i = 1, ROW_COUNT do
    local row = CreateFrame("Frame", nil, mainFrame)
    row:SetSize(475, ROW_HEIGHT)
    if i == 1 then 
        row:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0)
    else 
        row:SetPoint("TOPLEFT", mainFrame.rows[i-1], "BOTTOMLEFT", 0, -2) 
    end

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.02 or 0.06)

    row.classIcon = row:CreateTexture(nil, "ARTWORK")
    row.classIcon:SetSize(28, 28)
    row.classIcon:SetPoint("LEFT", row, "LEFT", 6, 0)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.nameText:SetPoint("TOPLEFT", row.classIcon, "TOPRIGHT", 8, -2)
    row.nameText:SetHeight(16)
    row.nameText:SetWidth(230)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)

    row.subText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.subText:SetPoint("TOPLEFT", row.nameText, "BOTTOMLEFT", 0, -2)
    row.subText:SetHeight(14)
    row.subText:SetWidth(230)
    row.subText:SetJustifyH("LEFT")
    row.subText:SetWordWrap(false)

    row.removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.removeBtn:SetSize(38, 22)
    row.macroBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.macroBtn:SetSize(38, 22)
    row.extraBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.extraBtn:SetSize(38, 22)
    row.actionBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.actionBtn:SetSize(38, 22)
    row.followBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.followBtn:SetSize(38, 22)

    mainFrame.rows[i] = row
end

local resetBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
resetBtn:SetSize(90, 24)
resetBtn:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 15, 12)
resetBtn:SetText("重置副本")
resetBtn:SetScript("OnClick", SafeResetInstances)

local leaveBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
leaveBtn:SetSize(90, 24)
leaveBtn:SetPoint("LEFT", resetBtn, "RIGHT", 10, 0)
leaveBtn:SetText("离开队伍")
leaveBtn:SetScript("OnClick", function()
    if C_PartyInfo and C_PartyInfo.LeaveParty then C_PartyInfo.LeaveParty()
    elseif LeaveParty then LeaveParty() end
end)

local specMacroBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
specMacroBtn:SetSize(90, 24)
specMacroBtn:SetPoint("LEFT", leaveBtn, "RIGHT", 10, 0)
specMacroBtn:SetText("切换专精")
specMacroBtn:SetScript("OnClick", function()
    if InCombatLockdown() then print("|cffff0000[组队助手]|r 战斗中无法创建宏！") return end
    local macroName = "切换专精"
    local macroBody = "/specindex 2"
    local idx = GetMacroIndexByName(macroName)
    if idx > 0 then EditMacro(idx, macroName, "INV_Misc_QuestionMark", macroBody)
    else CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, true) end
    print("|cff00ff00[组队助手]|r 角色专用宏【切换专精】已生成/更新。")
end)

local addGroupBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
addGroupBtn:SetSize(85, 24)
addGroupBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -125, 12)
addGroupBtn:SetText("新建分组")
addGroupBtn:Hide()
addGroupBtn:SetScript("OnClick", function()
    StaticPopupDialogs["PARTY_ASSISTANT_ADD_GROUP"] = {
        text = "请输入新分组名称：",
        button1 = "确定",
        button2 = "取消",
        hasEditBox = true,
        OnAccept = function(self)
            local text = self.EditBox:GetText()
            if text and text ~= "" then
                PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
                for _, g in ipairs(PartyAssistantDB.groups) do
                    if g == text then print("|cffff0000[组队助手]|r 分组已存在！") return end
                end
                table.insert(PartyAssistantDB.groups, text)
                PartyAssistant_BuildData()
                PartyAssistant_UpdateUI()
                print("|cff00ff00[组队助手]|r 已创建分组: " .. text)
            end
        end,
        EditBoxOnEnterPressed = function(self) self:GetParent():Hide() end,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
    }
    StaticPopup_Show("PARTY_ASSISTANT_ADD_GROUP")
end)
mainFrame.addGroupBtn = addGroupBtn

local inviteAllBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
inviteAllBtn:SetSize(100, 24)
inviteAllBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 12)
inviteAllBtn:SetText("一键组全员")
inviteAllBtn:Hide()
inviteAllBtn:SetScript("OnClick", function()
    local count = 0
    local myFullName = UnitName("player") .. "-" .. GetRealmName()
    for fullName, data in pairs(PartyAssistantDB) do
        if not systemKeys[fullName] and type(data) == "table" then
            if fullName ~= myFullName then
                InviteUnit(fullName)
                count = count + 1
            end
        end
    end
    print("|cff00ff00[组队助手]|r 已向历史列表中的 " .. count .. " 位成员发送邀请。")
end)
mainFrame.inviteAllBtn = inviteAllBtn

local exportBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
exportBtn:SetSize(100, 24)
exportBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 42)
exportBtn:SetText("导出分组配置")
exportBtn:Hide()
exportBtn:SetScript("OnClick", function()
    local exportData = {}
    for fn, data in pairs(PartyAssistantDB) do
        if not systemKeys[fn] and type(data) == "table" and data.groups then
            local grpList = {}
            for gName, isIn in pairs(data.groups) do
                if isIn and gName ~= "无分组" then
                    table.insert(grpList, gName)
                end
            end
            if #grpList > 0 then
                local classStr = data.class or ""
                local levelStr = data.level or 0
                table.insert(exportData, fn .. "=" .. table.concat(grpList, ",") .. "=" .. classStr .. "=" .. levelStr)
            end
        end
    end
    local str = table.concat(exportData, ";")
    if str == "" then print("|cffff0000[组队助手]|r 暂无有效分组数据可导出！") return end
    
    StaticPopupDialogs["PA_EXPORT"] = {
        text = "请 Ctrl+C 复制以下导出数据：",
        button1 = "关闭",
        hasEditBox = true,
        OnShow = function(self)
            self.EditBox:SetText(str)
            self.EditBox:HighlightText()
            self.EditBox:SetFocus()
        end,
        timeout = 0, whileDead = true, hideOnEscape = true,
    }
    StaticPopup_Show("PA_EXPORT")
end)
mainFrame.exportBtn = exportBtn

local importBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
importBtn:SetSize(85, 24)
importBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -125, 42)
importBtn:SetText("导入分组")
importBtn:Hide()
importBtn:SetScript("OnClick", function()
    StaticPopupDialogs["PA_IMPORT"] = {
        text = "请 Ctrl+V 粘贴分组数据进行导入：",
        button1 = "导入",
        button2 = "取消",
        hasEditBox = true,
        OnAccept = function(self)
            local str = self.EditBox:GetText()
            if not str or str == "" then return end
            
            local importCount = 0
            for pair in str:gmatch("[^;]+") do
                local fn, grpStr, classToken, levelStr = pair:match("([^=]+)=([^=]+)=?([^=]*)=?([^=]*)")
                
                if fn and grpStr then
                    local level = tonumber(levelStr) or 0
                    if classToken == "" then classToken = nil end

                    if not PartyAssistantDB[fn] then
                        local name, realm = fn:match("^(.-)%-(.+)$")
                        PartyAssistantDB[fn] = {
                            time = time(),
                            shortName = name or fn,
                            realm = realm or GetRealmName(),
                            groups = {},
                            class = classToken,
                            level = level
                        }
                    end
                    
                    PartyAssistantDB[fn].groups = PartyAssistantDB[fn].groups or {}
                    for grp in grpStr:gmatch("[^,]+") do
                        PartyAssistantDB[fn].groups[grp] = true
                        PartyAssistantDB[fn].groups["无分组"] = nil
                        
                        local groupExists = false
                        for _, g in ipairs(PartyAssistantDB.groups) do
                            if g == grp then groupExists = true; break end
                        end
                        if not groupExists then table.insert(PartyAssistantDB.groups, grp) end
                    end

                    if classToken then PartyAssistantDB[fn].class = classToken end
                    if level > 0 then PartyAssistantDB[fn].level = level end
                    importCount = importCount + 1
                end
            end
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
            print(string.format("|cff00ff00[组队助手]|r 成功导入了 %d 条角色分组配置！", importCount))
        end,
        timeout = 0, whileDead = true, hideOnEscape = true,
    }
    StaticPopup_Show("PA_IMPORT")
end)
mainFrame.importBtn = importBtn

local roleMacroBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
roleMacroBtn:SetSize(90, 24)
roleMacroBtn:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 15, 42)
roleMacroBtn:SetText("职责确认宏")
roleMacroBtn:SetScript("OnClick", function()
    if InCombatLockdown() then print("|cffff0000[组队助手]|r 战斗中无法创建宏！") return end
    local macroName = "职责确认"
    local macroBody = "/click LFDRoleCheckPopupAcceptButton"
    local idx = GetMacroIndexByName(macroName)
    if idx > 0 then EditMacro(idx, macroName, "INV_Misc_QuestionMark", macroBody)
    else CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, true) end
    print("|cff00ff00[组队助手]|r 角色专用宏【职责确认】已生成/更新。")
end)

local enterMacroBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
enterMacroBtn:SetSize(90, 24)
enterMacroBtn:SetPoint("LEFT", roleMacroBtn, "RIGHT", 10, 0)
enterMacroBtn:SetText("进入副本宏")
enterMacroBtn:SetScript("OnClick", function()
    if InCombatLockdown() then print("|cffff0000[组队助手]|r 战斗中无法创建宏！") return end
    local macroName = "进入副本"
    local macroBody = "/click LFGDungeonReadyDialogEnterDungeonButton"
    local idx = GetMacroIndexByName(macroName)
    if idx > 0 then EditMacro(idx, macroName, "INV_Misc_QuestionMark", macroBody)
    else CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, true) end
    print("|cff00ff00[组队助手]|r 角色专用宏【进入副本】已生成/更新。")
end)

local infoBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
infoBtn:SetSize(90, 24)
infoBtn:SetPoint("LEFT", enterMacroBtn, "RIGHT", 10, 0)
infoBtn:SetText("队伍信息")
infoBtn:SetScript("OnClick", function()
    if PartyAssistantInfoFrame:IsShown() then PartyAssistantInfoFrame:Hide()
    else PartyAssistantInfoFrame:Show() end
end)

local infoFrame = CreateFrame("Frame", "PartyAssistantInfoFrame", UIParent, "BasicFrameTemplateWithInset")
infoFrame:SetSize(220, 150)
infoFrame:SetPoint("CENTER", UIParent, "CENTER", 300, 0)
infoFrame:Hide()
infoFrame:SetMovable(true)
infoFrame:EnableMouse(true)
infoFrame:RegisterForDrag("LeftButton")
infoFrame:SetScript("OnDragStart", infoFrame.StartMoving)
infoFrame:SetScript("OnDragStop", infoFrame.StopMovingOrSizing)

infoFrame.title = infoFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
infoFrame.title:SetPoint("CENTER", infoFrame.TitleBg, "CENTER", 0, 0)
infoFrame.title:SetText("队伍等级信息")

infoFrame.hideNameCb = CreateFrame("CheckButton", nil, infoFrame, "UICheckButtonTemplate")
infoFrame.hideNameCb:SetPoint("BOTTOMLEFT", infoFrame, "BOTTOMLEFT", 12, 8)
infoFrame.hideNameCb:SetSize(24, 24)
infoFrame.hideNameCb.text = infoFrame.hideNameCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
infoFrame.hideNameCb.text:SetPoint("LEFT", infoFrame.hideNameCb, "RIGHT", 2, 1)
infoFrame.hideNameCb.text:SetText("匿名模式(隐藏角色名)")
infoFrame.hideNameCb:SetScript("OnClick", function(self)
    PartyAssistantDB.hideNames = self:GetChecked()
    if infoFrame.UpdateInfo then infoFrame.UpdateInfo() end
    if PartyAssistantFrame and PartyAssistantFrame:IsShown() then
        PartyAssistantFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
        PartyAssistant_UpdateUI()
    end
end)

infoFrame:SetScript("OnShow", function()
    infoFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
    if infoFrame.UpdateInfo then infoFrame.UpdateInfo() end
end)

infoFrame.rows = {}
local MAX_INFO_ROWS = 40
for i = 1, MAX_INFO_ROWS do
    local row = CreateFrame("Frame", nil, infoFrame)
    row:SetSize(190, 20)
    if i == 1 then row:SetPoint("TOPLEFT", infoFrame, "TOPLEFT", 15, -30)
    else row:SetPoint("TOPLEFT", infoFrame.rows[i-1], "BOTTOMLEFT", 0, 0) end

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.nameText:SetPoint("LEFT", row, "LEFT", 0, 0)
    row.nameText:SetJustifyH("LEFT")

    row.levelText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.levelText:SetPoint("RIGHT", row, "RIGHT", -5, 0)
    row.levelText:SetJustifyH("RIGHT")
    row:Hide()
    infoFrame.rows[i] = row
end

infoFrame.UpdateInfo = function()
    if not infoFrame:IsShown() then return end
    
    local num = IsInGroup() and GetNumGroupMembers() or 0
    local hideNames = PartyAssistantDB.hideNames
    
    if num == 0 then
        infoFrame.rows[1].nameText:SetText("|cff888888当前不在队伍中。|r")
        infoFrame.rows[1].levelText:SetText("")
        infoFrame.rows[1]:Show()
        for i = 2, MAX_INFO_ROWS do infoFrame.rows[i]:Hide() end
        infoFrame:SetHeight(85)
        return
    end

    local isRaid = IsInRaid()
    local prefix = isRaid and "raid" or "party"
    local displayCount = 0

    for i = 1, MAX_INFO_ROWS do
        if i <= num then
            local unit = isRaid and (prefix..i) or (i == num and "player" or prefix..i)
            if UnitExists(unit) then
                displayCount = displayCount + 1
                local name = UnitName(unit)
                local level = UnitLevel(unit)
                local classColor = "ffffffff"
                
                if not UnitIsConnected(unit) then
                    classColor = "ff888888"
                else
                    local _, classToken = UnitClass(unit)
                    if classToken and RAID_CLASS_COLORS[classToken] then
                        classColor = RAID_CLASS_COLORS[classToken].colorStr
                    end
                end
                
                local displayName = hideNames and string.format("队友 %d", displayCount) or name
                infoFrame.rows[i].nameText:SetText(string.format("|c%s%s|r", classColor, displayName or "未知"))
                if level and level > 0 then infoFrame.rows[i].levelText:SetText(string.format("|cffffff00%d级|r", level))
                else infoFrame.rows[i].levelText:SetText("|cff888888未知|r") end
                infoFrame.rows[i]:Show()
            else
                infoFrame.rows[i]:Hide()
            end
        else
            infoFrame.rows[i]:Hide()
        end
    end
    infoFrame:SetHeight(30 + (displayCount * 20) + 40)
end

function PartyAssistant_UpdateZoneAndLootDisplay()
    if not mainFrame:IsShown() then return end
    mainFrame.zoneText:SetText("位置: " .. GetUnitLocation("player"))
    mainFrame.lootText:SetText("拾取: " .. GetLootModeText())
end

function PartyAssistant_UpdateDifficultyDisplay()
    if not mainFrame:IsShown() then return end
    mainFrame.diffText:SetText("难度: " .. GetCurrentDifficultyText())
end

function PartyAssistant_UpdateTrackerDisplay()
    local count, timeRemaining = GetInstanceTimerInfo()
    local countColor = (count >= INSTANCE_LIMIT) and "|cffff0000" or ((count >= 8) and "|cffff9900" or "|cff00ff00")
    mainFrame.trackerText:SetText(string.format("1小时副本: %s%d/%d|r 次", countColor, count, INSTANCE_LIMIT))
    
    if count >= INSTANCE_LIMIT then
        mainFrame.timerText:SetText(string.format("|cffff0000[爆本中] 首刷解锁: %s|r", FormatTimer(timeRemaining)))
    elseif timeRemaining > 0 then
        mainFrame.timerText:SetText(string.format("首刷解锁倒计时: %s", FormatTimer(timeRemaining)))
    else
        mainFrame.timerText:SetText("首刷解锁倒计时: 无")
    end

    local runs = CleanAndGetInstanceHistory()
    if #runs > 0 then
        local latest = runs[#runs]
        local latestTime = (type(latest) == "table") and latest.time or latest
        local elapsed = time() - latestTime
        local recentRemaining = 360 - elapsed
        
        if elapsed >= 0 and recentRemaining > 0 then
            mainFrame.recentTimerText:SetText(string.format("最新进本倒计时: %s", FormatTimer(recentRemaining)))
            mainFrame.recentTimerText:Show()
        else
            mainFrame.recentTimerText:SetText("")
            mainFrame.recentTimerText:Hide()
        end
    else
        mainFrame.recentTimerText:SetText("")
        mainFrame.recentTimerText:Hide()
    end
end

local lastUpdateTimer = 0
mainFrame:SetScript("OnUpdate", function(self, elapsed)
    lastUpdateTimer = lastUpdateTimer + elapsed
    if lastUpdateTimer >= 1 then
        lastUpdateTimer = 0
        if mainFrame:IsShown() then PartyAssistant_UpdateTrackerDisplay() end
    end
end)

-- ==========================================
-- 数据渲染逻辑
-- ==========================================
function PartyAssistant_BuildData()
    table.wipe(mainFrame.listData)
    
    if mainFrame.currentTab == 1 then
        if IsInGroup() then
            local isRaid = IsInRaid()
            local numMembers = GetNumGroupMembers()
            local prefix = isRaid and "raid" or "party"
            local displayCount = 0
            
            for i = 1, numMembers do
                local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
                local name, realm = UnitName(unit)
                local isHex = name and name:match("^%x+$") and #name >= 6
                if isHex and activeGroupNames[unit] then
                    name = activeGroupNames[unit].name
                    realm = activeGroupNames[unit].realm
                end
                
                if name and name ~= "未知" and not name:match("^%x+$") then
                    displayCount = displayCount + 1
                    realm = realm or GetRealmName()
                    local fullName = name .. "-" .. realm
                    local _, classToken = UnitClass(unit)
                    local level = UnitLevel(unit)
                    
                    if not classToken and PartyAssistantDB[fullName] then classToken = PartyAssistantDB[fullName].class end
                    if (not level or level == 0) and PartyAssistantDB[fullName] then level = PartyAssistantDB[fullName].level end
                    
                    local subAccount = PartyAssistantDB.subAccountMap and PartyAssistantDB.subAccountMap[fullName] or ""
                    if UnitIsUnit(unit, "player") and PartyAssistantDB.subAccountName and PartyAssistantDB.subAccountName ~= "" then
                        subAccount = PartyAssistantDB.subAccountName
                    end

                    table.insert(mainFrame.listData, {
                        type = "CURRENT",
                        unit = unit,
                        fullName = fullName,
                        shortName = name,
                        anonName = "队友 " .. displayCount,
                        realm = realm,
                        class = classToken,
                        level = level,
                        zone = GetUnitLocation(unit),
                        isLeader = UnitIsGroupLeader(unit),
                        isOnline = UnitIsConnected(unit),
                        subAccount = subAccount
                    })
                end
            end
        end
    elseif mainFrame.currentTab == 2 then
        PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
        PartyAssistantDB.groupCollapsed = PartyAssistantDB.groupCollapsed or {}
        
        local groupMap = {}
        for _, gName in ipairs(PartyAssistantDB.groups) do
            groupMap[gName] = { name = gName, members = {} }
        end
        
        for fullName, data in pairs(PartyAssistantDB) do
            if not systemKeys[fullName] and type(data) == "table" and data.time and data.shortName and data.shortName ~= "未知" then
                
                local memberGroups = data.groups
                if not memberGroups or type(memberGroups) ~= "table" then
                    memberGroups = { [data.group or "无分组"] = true }
                end

                local subAccount = PartyAssistantDB.subAccountMap and PartyAssistantDB.subAccountMap[fullName] or ""
                local myFullName = UnitName("player") .. "-" .. GetRealmName()
                if fullName == myFullName and PartyAssistantDB.subAccountName and PartyAssistantDB.subAccountName ~= "" then
                    subAccount = PartyAssistantDB.subAccountName
                end

                for gName, isInGroup in pairs(memberGroups) do
                    if isInGroup then
                        if not groupMap[gName] then
                            groupMap[gName] = { name = gName, members = {} }
                            table.insert(PartyAssistantDB.groups, gName)
                        end
                        
                        table.insert(groupMap[gName].members, {
                            type = "RECENT",
                            fullName = fullName,
                            shortName = data.shortName,
                            realm = data.realm,
                            class = data.class,
                            level = data.level,
                            time = data.time or 0,
                            group = gName,
                            subAccount = subAccount
                        })
                    end
                end
            end
        end
        
        for _, gData in pairs(groupMap) do table.sort(gData.members, function(a, b) return a.time > b.time end) end
        
        for _, gName in ipairs(PartyAssistantDB.groups) do
            local gData = groupMap[gName]
            if gData then
                local total = #gData.members
                local isCollapsed = PartyAssistantDB.groupCollapsed[gName]
                if isCollapsed == nil then isCollapsed = true end

                table.insert(mainFrame.listData, { type = "HEADER", groupName = gName, count = total, members = gData.members, isCollapsed = isCollapsed })
                if not isCollapsed then
                    for _, member in ipairs(gData.members) do table.insert(mainFrame.listData, member) end
                end
            end
        end
    end
end

local function BuildManageMenu(owner, rootDescription, data)
    rootDescription:CreateTitle("角色管理操作")
    
    local groupSub = rootDescription:CreateButton("分组管理 (勾选/取消)")
    local pData = PartyAssistantDB[data.fullName]
    if pData then
        pData.groups = pData.groups or {}
        if type(pData.groups) ~= "table" then pData.groups = { [pData.group or "无分组"] = true } end
        
        for _, gName in ipairs(PartyAssistantDB.groups) do
            if gName ~= "无分组" then
                local hasGroup = pData.groups[gName]
                local label = (hasGroup and "|cff00ff00[√]|r " or "|cff888888[  ]|r ") .. gName
                groupSub:CreateButton(label, function()
                    if hasGroup then
                        pData.groups[gName] = nil
                        local count = 0
                        for _ in pairs(pData.groups) do count = count + 1 end
                        if count == 0 then pData.groups["无分组"] = true end
                        print(string.format("|cff00ff00[组队助手]|r 已将 |cffffcc00%s|r 从分组 |cff00ffff[%s]|r 移除。", data.shortName, gName))
                    else
                        pData.groups[gName] = true
                        pData.groups["无分组"] = nil
                        print(string.format("|cff00ff00[组队助手]|r 已将 |cffffcc00%s|r 加入分组: |cff00ffff[%s]|r", data.shortName, gName))
                    end
                    PartyAssistant_BuildData()
                    PartyAssistant_UpdateUI()
                end)
            end
        end
    end
    
    if PartyAssistantDB.autoLeader == data.fullName then
        rootDescription:CreateButton("取消自动转移队长", function()
            PartyAssistantDB.autoLeader = nil
            print(string.format("|cff00ff00[组队助手]|r 已取消 |cffffcc00%s|r 的自动队长状态。", data.shortName))
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
        end)
    else
        rootDescription:CreateButton("设为自动转移队长", function()
            PartyAssistantDB.autoLeader = data.fullName
            print(string.format("|cff00ff00[组队助手]|r 已将 |cffffcc00%s|r 设为核心自动队长，上线或进组时自动交接！", data.shortName))
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
            CheckAndPromoteDesignatedLeader()
        end)
    end

    rootDescription:CreateButton("复制角色名字", function()
        StaticPopupDialogs["PA_COPY_NAME"] = {
            text = "请按 Ctrl+C 复制名字：",
            button1 = "关闭",
            hasEditBox = true,
            OnShow = function(self)
                self.EditBox:SetText(data.fullName)
                self.EditBox:HighlightText()
                self.EditBox:SetFocus()
            end,
            timeout = 0, whileDead = true, hideOnEscape = true,
        }
        StaticPopup_Show("PA_COPY_NAME")
    end)
end

function PartyAssistant_UpdateUI()
    if not mainFrame:IsShown() then return end
    PartyAssistant_UpdateZoneAndLootDisplay()
    PartyAssistant_UpdateDifficultyDisplay()
    PartyAssistant_UpdateTrackerDisplay()
    
    local totalItems = #mainFrame.listData
    FauxScrollFrame_Update(scrollFrame, totalItems, ROW_COUNT, ROW_HEIGHT)
    local offset = FauxScrollFrame_GetOffset(scrollFrame)
    local isPlayerLeader = UnitIsGroupLeader("player")

    for i = 1, ROW_COUNT do
        local idx = offset + i
        local row = mainFrame.rows[i]
        row:SetScript("OnMouseDown", nil)

        if idx <= totalItems then
            local data = mainFrame.listData[idx]
            
            if data.type == "HEADER" then
                row.bg:SetColorTexture(0.15, 0.15, 0.15, 0.8)
                if data.isCollapsed then row.classIcon:SetTexture("Interface\\Buttons\\UI-PlusButton-UP")
                else row.classIcon:SetTexture("Interface\\Buttons\\UI-MinusButton-UP") end
                row.classIcon:SetTexCoord(0, 1, 0, 1)
                row.classIcon:SetDesaturated(false)

                row.nameText:SetText(string.format("|cffffcc00[%s]|r  |cffaaaaaa(%d)|r", data.groupName, data.count))
                row.subText:SetText("")
                
                row.actionBtn:Show()
                row.extraBtn:Show()
                row.macroBtn:Show()
                row.removeBtn:Show()
                row.followBtn:Hide()

                row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -5, 0)
                row.extraBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -2, 0)
                row.actionBtn:SetPoint("RIGHT", row.extraBtn, "LEFT", -2, 0)
                row.macroBtn:SetPoint("RIGHT", row.actionBtn, "LEFT", -2, 0)

                row.actionBtn:SetText("命名")
                row.actionBtn:Enable()
                row.actionBtn:SetScript("OnClick", function()
                    StaticPopupDialogs["PARTY_ASSISTANT_RENAME_GROUP"] = {
                        text = string.format("请输入 [%s] 的新分组名称：", data.groupName),
                        button1 = "确定",
                        button2 = "取消",
                        hasEditBox = true,
                        OnAccept = function(self)
                            local newName = self.EditBox:GetText()
                            if newName and newName ~= "" and newName ~= data.groupName then
                                PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
                                for _, g in ipairs(PartyAssistantDB.groups) do
                                    if g == newName then print("|cffff0000[组队助手]|r 分组名已存在！") return end
                                end
                                for j, g in ipairs(PartyAssistantDB.groups) do
                                    if g == data.groupName then PartyAssistantDB.groups[j] = newName break end
                                end
                                for fn, pData in pairs(PartyAssistantDB) do
                                    if not systemKeys[fn] and type(pData) == "table" then
                                        if pData.groups and pData.groups[data.groupName] then
                                            pData.groups[data.groupName] = nil
                                            pData.groups[newName] = true
                                        end
                                    end
                                end
                                PartyAssistant_BuildData()
                                PartyAssistant_UpdateUI()
                            end
                        end,
                        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
                    }
                    StaticPopup_Show("PARTY_ASSISTANT_RENAME_GROUP")
                end)

                row.macroBtn:SetText("同步")
                if data.count > 0 then
                    row.macroBtn:Enable()
                    row.macroBtn:SetScript("OnClick", function()
                        SendGroupSync(data.groupName, data.members)
                    end)
                else
                    row.macroBtn:Disable()
                    row.macroBtn:SetScript("OnClick", nil)
                end

                row.extraBtn:SetText("邀")
                if data.count > 0 then
                    row.extraBtn:Enable()
                    row.extraBtn:SetScript("OnClick", function()
                        local count = 0
                        local myFullName = UnitName("player") .. "-" .. GetRealmName()
                        for fullName, pData in pairs(PartyAssistantDB) do
                            if not systemKeys[fullName] and type(pData) == "table" then
                                if pData.groups and pData.groups[data.groupName] and fullName ~= myFullName then
                                    InviteUnit(fullName)
                                    count = count + 1
                                end
                            end
                        end
                        print(string.format("|cff00ff00[组队助手]|r 已向分组 |cffffcc00[%s]|r 中的 %d 位成员发送邀请。", data.groupName, count))
                    end)
                else
                    row.extraBtn:Disable()
                    row.extraBtn:SetScript("OnClick", nil)
                end

                if data.groupName == "无分组" then
                    row.removeBtn:SetText("删")
                    row.removeBtn:Disable()
                    row.removeBtn:SetScript("OnClick", nil)
                else
                    row.removeBtn:SetText("删")
                    row.removeBtn:Enable()
                    row.removeBtn:SetScript("OnClick", function()
                        for fn, pData in pairs(PartyAssistantDB) do
                            if not systemKeys[fn] and type(pData) == "table" then
                                if pData.groups and pData.groups[data.groupName] then
                                    pData.groups[data.groupName] = nil
                                    local c = 0
                                    for _ in pairs(pData.groups) do c = c + 1 end
                                    if c == 0 then pData.groups["无分组"] = true end
                                end
                            end
                        end
                        for j, g in ipairs(PartyAssistantDB.groups) do
                            if g == data.groupName then table.remove(PartyAssistantDB.groups, j) break end
                        end
                        PartyAssistantDB.groupCollapsed[data.groupName] = nil
                        PartyAssistant_BuildData()
                        PartyAssistant_UpdateUI()
                        print("|cff00ff00[组队助手]|r 已删除分组: " .. data.groupName)
                    end)
                end

                row:SetScript("OnMouseDown", function()
                    PartyAssistantDB.groupCollapsed[data.groupName] = not data.isCollapsed
                    PartyAssistant_BuildData()
                    PartyAssistant_UpdateUI()
                end)

            else
                row.bg:SetColorTexture(1, 1, 1, (idx % 2 == 0) and 0.02 or 0.06)

                if data.class and CLASS_ICON_TCOORDS[data.class] then
                    row.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
                    row.classIcon:SetTexCoord(unpack(CLASS_ICON_TCOORDS[data.class]))
                else
                    row.classIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
                    row.classIcon:SetTexCoord(0, 1, 0, 1)
                end

                local classColor = (data.class and RAID_CLASS_COLORS[data.class]) and RAID_CLASS_COLORS[data.class].colorStr or "ffffffff"
                if data.type == "CURRENT" and not data.isOnline then classColor = "ff888888" end

                local leaderIcon = (data.type == "CURRENT" and data.isLeader) and "|TInterface\\GroupFrame\\UI-Group-LeaderIcon:14:14|t " or ""
                local levelStr = (data.level and data.level > 0) and string.format("|cffffff00%d级|r ", data.level) or ""

                if data.type == "CURRENT" then
                    local fullTitle
                    if PartyAssistantDB.hideNames then 
                        fullTitle = data.anonName or "队友"
                    else 
                        fullTitle = string.format("%s - %s", data.shortName or "未知", data.realm or GetRealmName()) 
                    end
                    
                    if PartyAssistantDB.autoLeader == data.fullName then
                        fullTitle = fullTitle .. " |cff00ff00[自动队长]|r"
                    end

                    row.classIcon:SetDesaturated(not data.isOnline)
                    row.nameText:SetText(leaderIcon .. levelStr .. string.format("|c%s%s|r", classColor, fullTitle))
                    
                    local subTextStr = "位置: " .. (data.zone or "未知位置")
                    if data.subAccount and data.subAccount ~= "" then
                        subTextStr = string.format("%s (%s)", subTextStr, data.subAccount)
                    end
                    row.subText:SetText(subTextStr)
                    
                    row.actionBtn:Show()
                    row.extraBtn:Show()
                    row.macroBtn:Show()
                    row.removeBtn:Show()
                    row.followBtn:Show()

                    row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -5, 0)
                    row.macroBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -2, 0)
                    row.extraBtn:SetPoint("RIGHT", row.macroBtn, "LEFT", -2, 0)
                    row.actionBtn:SetPoint("RIGHT", row.extraBtn, "LEFT", -2, 0)
                    row.followBtn:SetPoint("RIGHT", row.actionBtn, "LEFT", -2, 0) 

                    row.actionBtn:SetText("队长")
                    if isPlayerLeader and not UnitIsUnit(data.unit, "player") and data.isOnline then
                        row.actionBtn:Enable()
                        row.actionBtn:SetScript("OnClick", function() PromoteToLeader(data.unit) end)
                    else
                        row.actionBtn:Disable()
                    end

                    row.extraBtn:SetText("管理")
                    row.extraBtn:Enable()
                    row.extraBtn:SetScript("OnClick", function()
                        PartyAssistantDB[data.fullName] = PartyAssistantDB[data.fullName] or {
                            time = time(), class = data.class, level = data.level,
                            realm = data.realm, shortName = data.shortName, groups = { ["无分组"] = true }
                        }
                        if MenuUtil and MenuUtil.CreateContextMenu then
                            MenuUtil.CreateContextMenu(row.extraBtn, function(owner, rootDesc) BuildManageMenu(owner, rootDesc, data) end)
                        end
                    end)

                    row.macroBtn:SetText("雪球")
                    row.macroBtn:Enable()
                    row.macroBtn:SetScript("OnClick", function() UpdateSnowballMacroSingle(data) end)
                    
                    row.followBtn:SetText("跟随")
                    row.followBtn:Enable()
                    row.followBtn:SetScript("OnClick", function() UpdateFollowMacroSingle(data) end)

                    if isPlayerLeader and not UnitIsUnit(data.unit, "player") then
                        row.removeBtn:SetText("移")
                        row.removeBtn:Enable()
                        row.removeBtn:SetScript("OnClick", function() UninviteUnit(data.unit) end)
                    else
                        row.removeBtn:SetText("移")
                        row.removeBtn:Disable()
                    end
                    
                    if UnitIsUnit(data.unit, "player") then
                        row.actionBtn:Hide()
                        row.macroBtn:Hide()
                        row.removeBtn:Hide()
                        row.followBtn:Hide()
                    end
                    
                elseif data.type == "RECENT" then
                    local fullTitle = string.format("%s - %s", data.shortName or "未知", data.realm or GetRealmName())
                    if PartyAssistantDB.autoLeader == data.fullName then
                        fullTitle = fullTitle .. " |cff00ff00[自动队长]|r"
                    end
                    
                    row.classIcon:SetDesaturated(false)
                    row.nameText:SetText(levelStr .. string.format("|c%s%s|r", classColor, fullTitle))
                    
                    local timeDiff = time() - (data.time or time())
                    local timeStr = "刚刚"
                    if timeDiff >= 86400 then timeStr = math.floor(timeDiff/86400) .. "天前"
                    elseif timeDiff >= 3600 then timeStr = math.floor(timeDiff/3600) .. "小时前"
                    elseif timeDiff >= 60 then timeStr = math.floor(timeDiff/60) .. "分钟前" end
                    
                    local subTextStr = string.format("[%s] %s", data.group or "无分组", timeStr)
                    if data.subAccount and data.subAccount ~= "" then
                        subTextStr = string.format("%s (%s)", subTextStr, data.subAccount)
                    end
                    row.subText:SetText(subTextStr)
                    
                    row.actionBtn:Show()
                    row.extraBtn:Show()
                    row.macroBtn:Show() 
                    row.removeBtn:Show()
                    row.followBtn:Hide()

                    row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -5, 0)
                    row.macroBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -2, 0)
                    row.extraBtn:SetPoint("RIGHT", row.macroBtn, "LEFT", -2, 0)
                    row.actionBtn:SetPoint("RIGHT", row.extraBtn, "LEFT", -2, 0)

                    row.actionBtn:SetText("邀")
                    row.actionBtn:Enable()
                    row.actionBtn:SetScript("OnClick", function()
                        InviteUnit(data.fullName)
                        print("|cff00ff00[组队助手]|r 已向 " .. data.fullName .. " 发送邀请。")
                    end)

                    row.macroBtn:SetText("密")
                    row.macroBtn:Enable()
                    row.macroBtn:SetScript("OnClick", function() ChatFrame_OpenChat(string.format("/w %s ", data.fullName)) end)

                    row.extraBtn:SetText("管理")
                    row.extraBtn:Enable()
                    row.extraBtn:SetScript("OnClick", function()
                        if MenuUtil and MenuUtil.CreateContextMenu then
                            MenuUtil.CreateContextMenu(row.extraBtn, function(owner, rootDesc) BuildManageMenu(owner, rootDesc, data) end)
                        end
                    end)

                    row.removeBtn:SetText("删")
                    row.removeBtn:Enable()
                    row.removeBtn:SetScript("OnClick", function()
                        PartyAssistantDB[data.fullName] = nil
                        if PartyAssistantDB.autoLeader == data.fullName then PartyAssistantDB.autoLeader = nil end
                        PartyAssistant_BuildData()
                        PartyAssistant_UpdateUI()
                        print(string.format("|cff00ff00[组队助手]|r 已从近期往来中删除: |cffffcc00%s|r", data.shortName))
                    end)
                end
            end
            row:Show()
        else
            row:Hide()
        end
    end
end

scrollFrame:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, ROW_HEIGHT, PartyAssistant_UpdateUI)
end)

-- ==========================================
-- 事件监听与指令注册
-- ==========================================
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("ZONE_CHANGED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("PLAYER_DIFFICULTY_CHANGED")
eventFrame:RegisterEvent("PARTY_LOOT_METHOD_CHANGED")
eventFrame:RegisterEvent("CHAT_MSG_SYSTEM")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == addonName then
            PartyAssistantDB = PartyAssistantDB or {}
            PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
            if PartyAssistantDB.hideNames == nil then PartyAssistantDB.hideNames = false end
            if PartyAssistantDB.autoReset == nil then PartyAssistantDB.autoReset = false end
            if PartyAssistantDB.enableRecord == nil then PartyAssistantDB.enableRecord = true end
            if PartyAssistantDB.isCDAccount == nil then PartyAssistantDB.isCDAccount = false end
            if PartyAssistantDB.subAccountName == nil then PartyAssistantDB.subAccountName = "" end
            PartyAssistantDB.subAccountMap = PartyAssistantDB.subAccountMap or {}
            
            if type(PartyAssistantDB.currentInstanceLock) ~= "table" or PartyAssistantDB.currentInstanceLock.id ~= nil then
                PartyAssistantDB.currentInstanceLock = {}
            end
            
            if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
                C_ChatInfo.RegisterAddonMessagePrefix(SYNC_PREFIX)
                C_ChatInfo.RegisterAddonMessagePrefix(GRP_SYNC_PREFIX)
                C_ChatInfo.RegisterAddonMessagePrefix(INST_SYNC_PREFIX)
            elseif RegisterAddonMessagePrefix then
                RegisterAddonMessagePrefix(SYNC_PREFIX)
                RegisterAddonMessagePrefix(GRP_SYNC_PREFIX)
                RegisterAddonMessagePrefix(INST_SYNC_PREFIX)
            end
            
            CleanupRecentDB()
            SwitchTab(1)
        end
    elseif event == "CHAT_MSG_SYSTEM" then
        local text = ...
        if text and text:find("经典分配规则已经启用") then
            isLegacyLootModeActive = true
            if PartyAssistant_UpdateZoneAndLootDisplay then
                PartyAssistant_UpdateZoneAndLootDisplay()
            end
        else
            if PartyAssistant_UpdateZoneAndLootDisplay then
                PartyAssistant_UpdateZoneAndLootDisplay()
            end
        end
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if prefix == INST_SYNC_PREFIX then
            local senderNameStr, senderRealmStr = sender:match("^(.-)%-(.+)$")
            senderNameStr = senderNameStr or sender
            senderRealmStr = senderRealmStr or GetRealmName()
            
            if message == "RESET" then
                local key = GetSubAccountKey()
                PartyAssistantDB.currentInstanceLock = PartyAssistantDB.currentInstanceLock or {}
                PartyAssistantDB.currentInstanceLock[key] = { id = nil, lockTime = 0, guid = nil }
                if senderNameStr ~= UnitName("player") or senderRealmStr ~= GetRealmName() then
                    print(string.format("|cff00ff00[组队助手]|r 收到队友 |cffffcc00%s|r 副本重置信号，当前副本锁定已解除！", senderNameStr))
                end
            else
                if senderNameStr ~= UnitName("player") or senderRealmStr ~= GetRealmName() then
                    MergeInstanceHistory(message)
                end
            end
        elseif prefix == SYNC_PREFIX then
            local senderFullName = sender
            if not senderFullName:find("-") then
                senderFullName = senderFullName .. "-" .. GetRealmName()
            end

            local now = GetTime()
            local cache = syncRecvCache[senderFullName]

            if cache and cache.msg == message and (now - cache.time) < 60 then
                cache.time = now 
                return
            end

            syncRecvCache[senderFullName] = { msg = message, time = now }
            PartyAssistantDB.subAccountMap[senderFullName] = message
            
            local senderName = sender:match("^(.-)%-") or sender
            print(string.format("|cff00ff00[组队助手同步]|r 收到队友 |cffffcc00%s|r 的子账号标识: |cff00ffff%s|r", senderName, message))
            
            if mainFrame:IsShown() then
                PartyAssistant_BuildData()
                PartyAssistant_UpdateUI()
            end

        elseif prefix == GRP_SYNC_PREFIX then
            local senderNameStr, senderRealmStr = sender:match("^(.-)%-(.+)$")
            senderNameStr = senderNameStr or sender
            senderRealmStr = senderRealmStr or GetRealmName()
            if senderNameStr == UnitName("player") and senderRealmStr == GetRealmName() then
                return
            end

            local syncID, groupName, nameListStr = message:match("^([^|]+)|([^|]+)|(.+)$")
            
            if syncID and groupName and nameListStr then
                local now = GetTime()

                for id, expireTime in pairs(grpSyncRecvCache) do
                    if type(expireTime) == "number" and (now - expireTime > 60) then
                        grpSyncRecvCache[id] = nil
                    end
                end

                if grpSyncRecvCache[syncID] then return end
                grpSyncRecvCache[syncID] = now 

                PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
                local groupExists = false
                for _, g in ipairs(PartyAssistantDB.groups) do
                    if g == groupName then groupExists = true; break end
                end
                if not groupExists then
                    table.insert(PartyAssistantDB.groups, groupName)
                end

                local syncCount = 0
                for memberData in nameListStr:gmatch("[^,]+") do
                    if memberData and memberData ~= "" then
                        local fn, classToken, levelStr = memberData:match("^([^:]+):?([^:]*):?([^:]*)$")
                        if fn then
                            local level = tonumber(levelStr) or 0
                            if classToken == "" then classToken = nil end

                            if PartyAssistantDB[fn] then
                                PartyAssistantDB[fn].groups = PartyAssistantDB[fn].groups or {}
                                PartyAssistantDB[fn].groups[groupName] = true
                                PartyAssistantDB[fn].groups["无分组"] = nil
                                if classToken then PartyAssistantDB[fn].class = classToken end
                                if level > 0 then PartyAssistantDB[fn].level = level end
                            else
                                local name, realm = fn:match("^(.-)%-(.+)$")
                                PartyAssistantDB[fn] = {
                                    time = time(),
                                    shortName = name or fn,
                                    realm = realm or GetRealmName(),
                                    groups = { [groupName] = true },
                                    class = classToken,
                                    level = level
                                }
                            end
                            syncCount = syncCount + 1
                        end
                    end
                end

                grpSyncRecvCache.pendingMsg = grpSyncRecvCache.pendingMsg or {}
                if not grpSyncRecvCache.pendingMsg[groupName] then
                    grpSyncRecvCache.pendingMsg[groupName] = { count = 0, sender = senderNameStr }
                    C_Timer.After(0.5, function()
                        local data = grpSyncRecvCache.pendingMsg[groupName]
                        if data then
                            print(string.format("|cff00ff00[组队助手同步]|r 来自 |cffffcc00%s|r 的分组 |cff00ffff[%s]|r 同步完成 (共更新 %d 人)！", data.sender, groupName, data.count))
                            grpSyncRecvCache.pendingMsg[groupName] = nil
                        end
                    end)
                end
                grpSyncRecvCache.pendingMsg[groupName].count = grpSyncRecvCache.pendingMsg[groupName].count + syncCount

                if mainFrame:IsShown() then
                    PartyAssistant_BuildData()
                    PartyAssistant_UpdateUI()
                end
            end
        end

    elseif event == "PARTY_LOOT_METHOD_CHANGED" then
        if PartyAssistant_UpdateZoneAndLootDisplay then PartyAssistant_UpdateZoneAndLootDisplay() end
    elseif event == "PLAYER_DIFFICULTY_CHANGED" then
        if PartyAssistant_UpdateDifficultyDisplay then PartyAssistant_UpdateDifficultyDisplay() end
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        CheckInstanceEntry()
        RecordGroupMembers()
        CheckAndPromoteDesignatedLeader()
        CheckAllOfflineAutoReset()
        SendSubAccountSync()
        SyncInstanceHistory()
        if mainFrame:IsShown() then PartyAssistant_BuildData(); PartyAssistant_UpdateUI() end
        if PartyAssistantInfoFrame and PartyAssistantInfoFrame:IsShown() and PartyAssistantInfoFrame.UpdateInfo then PartyAssistantInfoFrame.UpdateInfo() end
    elseif event == "GROUP_ROSTER_UPDATE" or event == "ZONE_CHANGED" then
        RecordGroupMembers()
        CheckAndPromoteDesignatedLeader()
        CheckAllOfflineAutoReset()
        SendSubAccountSync()
        SyncInstanceHistory()
        if mainFrame:IsShown() then PartyAssistant_BuildData(); PartyAssistant_UpdateUI() end
        if PartyAssistantInfoFrame and PartyAssistantInfoFrame:IsShown() and PartyAssistantInfoFrame.UpdateInfo then PartyAssistantInfoFrame.UpdateInfo() end
    end
end)

SLASH_PARTYASSISTANT1 = "/pa"
SLASH_PARTYASSISTANT2 = "/partyassist"
SlashCmdList["PARTYASSISTANT"] = function()
    if mainFrame:IsShown() then mainFrame:Hide()
    else mainFrame:Show(); PartyAssistant_BuildData(); PartyAssistant_UpdateUI() end
end

local addonName, ns = ...

SLASH_BINVITE1 = "/binvite"
SlashCmdList["BINVITE"] = function(msg)
    msg = strtrim(msg or "")
    
    if msg == "" then
        if IsInGuild() then
            print("未输入名称，默认邀请当前公会在线成员...")
            InviteGuildOnlineMembers()
        else
            print("用法: /binvite <公会名或社区名>")
        end
        return
    end
    
    local currentGuildName = GetGuildInfo("player")
    if currentGuildName and currentGuildName == msg then
        InviteGuildOnlineMembers()
    else
        InviteCommunityOnlineMembers(msg)
    end
end

-- ==========================================
-- 公会与社区批量邀请 UI 控件
-- ==========================================

-- 1. 邀请公会成员按钮
local inviteGuildBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
inviteGuildBtn:SetSize(90, 24)
inviteGuildBtn:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 15, 70)
inviteGuildBtn:SetText("邀请公会")
inviteGuildBtn:SetScript("OnClick", function()
    InviteGuildOnlineMembers()
end)

-- 2. 社区下拉菜单定义
local communityDropdown = CreateFrame("Frame", "PartyAssistantCommunityDropdown", mainFrame, "UIDropDownMenuTemplate")
communityDropdown:SetPoint("LEFT", inviteGuildBtn, "RIGHT", -10, -2)
UIDropDownMenu_SetWidth(communityDropdown, 120)

local function UpdateCommunityDropdownText()
    local selected = PartyAssistantDB.selectedCommunity
    if not selected or selected == "" then
        UIDropDownMenu_SetText(communityDropdown, "选择/添加社区")
    else
        UIDropDownMenu_SetText(communityDropdown, selected)
    end
end

UIDropDownMenu_Initialize(communityDropdown, function(self, level)
    -- 【新增保底】如果数据库或列表未初始化，强制赋予默认空表
    if not PartyAssistantDB then PartyAssistantDB = {} end
    PartyAssistantDB.savedCommunities = PartyAssistantDB.savedCommunities or {}

    local info = UIDropDownMenu_CreateInfo()
    
    -- 菜单标题/提示
    info.text = "---- 选中社区 ----"
    info.isTitle = true
    info.notCheckable = true
    UIDropDownMenu_AddButton(info, level)

    -- 渲染已保存的社区列表
    for _, commName in ipairs(PartyAssistantDB.savedCommunities) do
        info = UIDropDownMenu_CreateInfo()
        info.text = commName
        info.checked = (PartyAssistantDB.selectedCommunity == commName)
        info.func = function()
            PartyAssistantDB.selectedCommunity = commName
            UpdateCommunityDropdownText()
        end
        UIDropDownMenu_AddButton(info, level)
    end

    -- 添加新社区选项
    info = UIDropDownMenu_CreateInfo()
    info.text = "|cff00ff00+ 输入新社区名|r"
    info.notCheckable = true
    info.func = function()
        StaticPopupDialogs["PARTY_ASSISTANT_ADD_COMMUNITY"] = {
            text = "请输入要保存的社区完整名称：",
            button1 = "保存",
            button2 = "取消",
            hasEditBox = true,
            OnAccept = function(popup)
                local text = strtrim(popup.EditBox:GetText() or "")
                if text ~= "" then
                    PartyAssistantDB.savedCommunities = PartyAssistantDB.savedCommunities or {}
                    -- 检查重复
                    local exists = false
                    for _, name in ipairs(PartyAssistantDB.savedCommunities) do
                        if name == text then exists = true; break end
                    end
                    if not exists then
                        table.insert(PartyAssistantDB.savedCommunities, text)
                    end
                    PartyAssistantDB.selectedCommunity = text
                    UpdateCommunityDropdownText()
                    print(string.format("|cff00ff00[组队助手]|r 已保存社区：|cffffcc00%s|r", text))
                end
            end,
            EditBoxOnEnterPressed = function(popup) popup:GetParent():Hide() end,
            timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        }
        StaticPopup_Show("PARTY_ASSISTANT_ADD_COMMUNITY")
    end
    UIDropDownMenu_AddButton(info, level)

    -- 清空当前选择选项
    if PartyAssistantDB.savedCommunities and #PartyAssistantDB.savedCommunities > 0 then
        info = UIDropDownMenu_CreateInfo()
        info.text = "|cffff5555- 清空已存社区|r"
        info.notCheckable = true
        info.func = function()
            table.wipe(PartyAssistantDB.savedCommunities)
            PartyAssistantDB.selectedCommunity = ""
            UpdateCommunityDropdownText()
            print("|cff00ff00[组队助手]|r 已清空保存的社区列表。")
        end
        UIDropDownMenu_AddButton(info, level)
    end
end)

-- 界面显示时同步下拉菜单选中的文本
mainFrame:HookScript("OnShow", function()
    UpdateCommunityDropdownText()
end)

-- 3. 邀请社区成员按钮
local inviteCommunityBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
inviteCommunityBtn:SetSize(90, 24)
inviteCommunityBtn:SetPoint("LEFT", communityDropdown, "RIGHT", -5, 2)
inviteCommunityBtn:SetText("邀请社区")
inviteCommunityBtn:SetScript("OnClick", function()
    local targetCommunity = PartyAssistantDB.selectedCommunity
    if not targetCommunity or targetCommunity == "" then
        print("|cffff0000[组队助手]|r 请先通过下拉菜单选择或添加一个社区！")
        return
    end
    InviteCommunityOnlineMembers(targetCommunity)
end)

function InviteGuildOnlineMembers()
    if not IsInGuild() then
        print("错误：你当前不在任何公会中。")
        return
    end
    
    C_GuildInfo.GuildRoster()
    
    C_Timer.After(1.5, function()
        local total = GetNumGuildMembers()
        local count = 0
        local playerGUID = UnitGUID("player")
        
        for i = 1, total do
            local name, _, _, _, _, _, _, _, online, _, _, _, _, _, _, _, guid = GetGuildRosterInfo(i)
            if online and guid ~= playerGUID and name then
                C_PartyInfo.InviteUnit(name)
                count = count + 1
            end
        end
        print(string.format("已向当前公会在线成员发出邀请，共计发送 %d 个邀请。", count))
    end)
end

function InviteCommunityOnlineMembers(targetName)
    local clubs = C_Club.GetSubscribedClubs()
    local found = false
    
    for _, club in ipairs(clubs) do
        if club.name == targetName then
            found = true
            local count = 0
            local invitedNames = {}
            
            -- 正确的 API 链条：C_Club.GetClubMembers 返回的是一组 memberId（数字）
            local memberIds = C_Club.GetClubMembers(club.clubId)
            if memberIds then
                for _, memberId in ipairs(memberIds) do
                    -- 必须通过 C_Club.GetMemberInfo(clubId, memberId) 获取详细结构
                    local memberInfo = C_Club.GetMemberInfo(club.clubId, memberId)
                    if memberInfo and memberInfo.name then
                        local isSelf = memberInfo.isSelf
                        local isOnline = memberInfo.presence and memberInfo.presence ~= Enum.ClubMemberPresence.Offline
                        
                        if not isSelf and isOnline and not invitedNames[memberInfo.name] then
                            invitedNames[memberInfo.name] = true
                            C_PartyInfo.InviteUnit(memberInfo.name)
                            count = count + 1
                        end
                    end
                end
            end
            
            print(string.format("已向社区 [%s] 在线成员发出邀请，共计发送 %d 个邀请。", targetName, count))
            break
        end
    end
    
    if not found then
        print(string.format("未找到名为 [%s] 的有效社区，请检查名称或确认你已加入该社区。", targetName))
    end
end