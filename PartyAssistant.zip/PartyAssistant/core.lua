local addonName, addonTable = ...

-- 初始化数据库
PartyAssistantDB = PartyAssistantDB or {}
PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
PartyAssistantDB.groupCollapsed = PartyAssistantDB.groupCollapsed or {}
PartyAssistantDB.autoLeader = PartyAssistantDB.autoLeader or nil -- 新增：存储自动移交队长的目标
if PartyAssistantDB.hideNames == nil then PartyAssistantDB.hideNames = false end
if PartyAssistantDB.autoReset == nil then PartyAssistantDB.autoReset = false end -- 新增：全员离线自动重置副本开关

local MAX_RECENT_PLAYERS = 100
local INSTANCE_LIMIT = 10     -- 1小时上限次数
local ONE_HOUR = 3600         -- 1小时（秒）
-- 在文件顶部（或其他本地变量区域）记录插件加载时间
local addonLoadTime = GetTime()

-- API 本地化与兼容防护
local UnitName = UnitName
local GetRealmName = GetRealmName
local UnitClass = UnitClass
local UnitLevel = UnitLevel
local UnitIsGroupLeader = UnitIsGroupLeader
local UnitIsConnected = UnitIsConnected
local UnitExists = UnitExists
local IsInGroup = IsInGroup
local IsInRaid = IsInRaid
local GetNumGroupMembers = GetNumGroupMembers
local PromoteToLeader = PromoteToLeader
local InviteUnit = C_PartyInfo and C_PartyInfo.InviteUnit or InviteUnit
local UninviteUnit = UninviteUnit
local IsInInstance = IsInInstance
local SendChatMessage = SendChatMessage

-- 单位名称运行时缓存
local activeGroupNames = {}
local wasInInstance = false

-- ==========================================
-- 新增：自动移交指定队长逻辑
-- ==========================================
local lastLeaderFullName = nil

local function CheckAndPromoteDesignatedLeader()
    if not IsInGroup() then return end
    
    local isRaid = IsInRaid()
    local numMembers = GetNumGroupMembers()
    local prefix = isRaid and "raid" or "party"
    local currentLeaderFullName = nil

    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        if UnitExists(unit) and UnitIsGroupLeader(unit) then
            local name, realm = UnitName(unit)
            realm = realm or GetRealmName()
            currentLeaderFullName = name .. "-" .. realm
            break
        end
    end

    local isPlayerLeader = UnitIsGroupLeader("player")

    if isPlayerLeader and lastLeaderFullName and PartyAssistantDB.autoLeader 
       and lastLeaderFullName == PartyAssistantDB.autoLeader 
       and currentLeaderFullName and currentLeaderFullName ~= PartyAssistantDB.autoLeader then
        PartyAssistantDB.altLoggingOutLock = time() + 30
    end

    if currentLeaderFullName then
        lastLeaderFullName = currentLeaderFullName
    end

    if PartyAssistantDB.altLoggingOutLock and time() < PartyAssistantDB.altLoggingOutLock then
        return
    end

    if not isPlayerLeader then return end
    if not PartyAssistantDB.autoLeader or PartyAssistantDB.autoLeader == "" then return end

    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        
        if not UnitIsUnit(unit, "player") and UnitIsConnected(unit) then
            local name, realm = UnitName(unit)
            realm = realm or GetRealmName()
            local fullName = name .. "-" .. realm

            if fullName == PartyAssistantDB.autoLeader and not UnitIsGroupLeader(unit) then
                PromoteToLeader(unit)
                print(string.format("|cff00ff00[组队助手]|r 检测到核心角色上线，已自动将队长移交至: |cffffcc00%s|r", fullName))
                break
            end
        end
    end
end

-- ==========================================
-- 0. 爆本监控与报警核心逻辑
-- ==========================================
local function CleanAndGetInstanceHistory()
    PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
    local now = time()
    local validRuns = {}
    for _, t in ipairs(PartyAssistantDB.instanceRuns) do
        if (now - t) < ONE_HOUR then
            table.insert(validRuns, t)
        end
    end
    PartyAssistantDB.instanceRuns = validRuns
    return validRuns
end

local function CheckAndPlayLockoutWarning(count)
    if count >= INSTANCE_LIMIT then
        PlaySound(8959, "Master")
        print(string.format("|cffff0000[组队助手警报]|r 🚨 【已爆本】当前1小时内已进本 |cffffcc00%d/%d|r 次！已被系统锁定，请暂停刷本！", count, INSTANCE_LIMIT))
        if UIErrorsFrame then
            UIErrorsFrame:AddMessage("🚨 已达爆本上限(10次), 请暂停刷本！", 1.0, 0.1, 0.1, 1.0)
        end
    elseif count >= 8 then
        if not PlaySound(56740, "Master") then
            PlaySound(8959, "Master")
        end
        print(string.format("|cffff9900[组队助手提示]|r ⚡ 【即将爆本】当前1小时内已进本 |cffffcc00%d/%d|r 次，请注意控制节奏！", count, INSTANCE_LIMIT))
        if UIErrorsFrame then
            UIErrorsFrame:AddMessage(string.format("⚡ 即将爆本警告：已进本 %d/10 次", count), 1.0, 0.5, 0.0, 1.0)
        end
    end
end

local function RecordInstanceRun()
    local runs = CleanAndGetInstanceHistory()
    table.insert(runs, time())
    PartyAssistantDB.instanceRuns = runs
    CheckAndPlayLockoutWarning(#runs)
end

local function GetInstanceTimerInfo()
    local runs = CleanAndGetInstanceHistory()
    local count = #runs
    local timeRemaining = 0
    if count > 0 then
        local oldest = runs[1]
        timeRemaining = ONE_HOUR - (time() - oldest)
        if timeRemaining < 0 then timeRemaining = 0 end
    end
    return count, timeRemaining
end

local function FormatTimer(seconds)
    if seconds <= 0 then return "无" end
    local m = math.floor(seconds / 60)
    local s = math.floor(seconds % 60)
    return string.format("%02d分%02d秒", m, s)
end

-- 使用高精度游戏运行时间戳（带毫秒）
local lastResetTime = 0

local function SafeResetInstances()
    local now = GetTime()
    if (now - lastResetTime) < 5 then
        return
    end
    lastResetTime = now

    if C_PartyInfo and C_PartyInfo.ResetInstances then
        C_PartyInfo.ResetInstances()
    elseif ResetInstances then
        ResetInstances()
    end
    print("|cff00ff00[组队助手]|r 已尝试重置副本。")

    if IsInGroup() then
        local chatType = "PARTY"
        if IsInRaid() then
            chatType = "RAID"
        end
        local inInstance, instanceType = IsInInstance()
        if inInstance and (instanceType == "party" or instanceType == "raid") then
            chatType = "INSTANCE_CHAT"
        end
        SendChatMessage("【组队助手】副本已重置成功！", chatType)
    end
end

local function CheckAllOfflineAutoReset()
    if not PartyAssistantDB.autoReset then return end
    if (GetTime() - addonLoadTime) < 8 then return end
    if not IsInGroup() then return end
    
    local isRaid = IsInRaid()
    local numMembers = GetNumGroupMembers()
    local prefix = isRaid and "raid" or "party"
    local hasOnlineOther = false

    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        if UnitExists(unit) and not UnitIsUnit(unit, "player") then
            if UnitIsConnected(unit) then
                hasOnlineOther = true
                break
            end
        end
    end

    if not hasOnlineOther then
        SafeResetInstances()
        print("|cff00ff00[组队助手]|r 检测到队友全员离线，已触发自动重置副本。")
    end
end

local function CheckInstanceEntry()
    local inInstance, instanceType = IsInInstance()
    if inInstance and (instanceType == "party" or instanceType == "raid") then
        if not wasInInstance then
            RecordInstanceRun()
            wasInInstance = true
            CheckAllOfflineAutoReset()
            if PartyAssistantFrame and PartyAssistantFrame:IsShown() then
                PartyAssistant_UpdateTrackerDisplay()
            end
        end
    else
        wasInInstance = false
    end
end

local function GetUnitLocation(unit)
    if not unit or not UnitExists(unit) then return "未知位置" end
    if UnitIsUnit(unit, "player") then
        return (GetRealZoneText and GetRealZoneText()) or (GetZoneText and GetZoneText()) or "未知位置"
    end
    if C_Map and C_Map.GetBestMapForUnit then
        local mapID = C_Map.GetBestMapForUnit(unit)
        if mapID then
            local mapInfo = C_Map.GetMapInfo(mapID)
            if mapInfo and mapInfo.name then return mapInfo.name end
        end
    end
    return "未知位置"
end

local function UpdateSnowballMacroSingle(data)
    if InCombatLockdown() then
        print("|cffff0000[组队助手]|r 战斗中无法修改宏，请脱战后重试！")
        return
    end
    local macroName = "雪球宏"
    local playerRealm = GetRealmName()
    local targetName = (data.realm and data.realm ~= "" and data.realm ~= playerRealm) and data.fullName or data.shortName
    local macroBody = string.format("#showtooltip 静滞砂砾\n/promote %s\n/use 静滞砂砾\n/logout", targetName)
    local macroIndex = GetMacroIndexByName(macroName)
    if macroIndex > 0 then
        EditMacro(macroIndex, macroName, "INV_Misc_QuestionMark", macroBody)
        print(string.format("|cff00ff00[组队助手]|r 【雪球宏】已成功更新！转移目标设为：|cff00ffff%s|r", data.fullName))
    else
        CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, false)
        print(string.format("|cff00ff00[组队助手]|r 已创建【雪球宏】！转移目标：|cff00ffff%s|r", data.fullName))
    end
end

-- ==========================================
-- 1. 数据处理与近期往来分组逻辑
-- ==========================================
local function CleanupRecentDB()
    PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
    PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
    PartyAssistantDB.groupCollapsed = PartyAssistantDB.groupCollapsed or {}

    for k, v in pairs(PartyAssistantDB) do
        if k ~= "instanceRuns" and k ~= "groups" and k ~= "groupCollapsed" and k ~= "hideNames" and k ~= "autoLeader" and k ~= "autoReset" then
            if type(v) ~= "table" or not v.time or not v.shortName or v.shortName == "未知" or k:find("未知") then
                PartyAssistantDB[k] = nil
            else
                v.group = v.group or "无分组"
            end
        end
    end

    local count = 0
    for k, _ in pairs(PartyAssistantDB) do
        if k ~= "instanceRuns" and k ~= "groups" and k ~= "groupCollapsed" and k ~= "hideNames" and k ~= "autoLeader" and k ~= "autoReset" then count = count + 1 end
    end
    
    if count > MAX_RECENT_PLAYERS then
        local temp = {}
        for name, data in pairs(PartyAssistantDB) do
            if name ~= "instanceRuns" and name ~= "groups" and name ~= "groupCollapsed" and name ~= "hideNames" and name ~= "autoLeader" and name ~= "autoReset" and type(data) == "table" and data.time then
                table.insert(temp, {name = name, time = data.time, data = data})
            end
        end
        table.sort(temp, function(a, b) return a.time > b.time end)
        
        local runs = PartyAssistantDB.instanceRuns
        local groups = PartyAssistantDB.groups
        local collapsed = PartyAssistantDB.groupCollapsed
        local hideNames = PartyAssistantDB.hideNames
        local autoLeader = PartyAssistantDB.autoLeader
        local autoReset = PartyAssistantDB.autoReset
        table.wipe(PartyAssistantDB)
        PartyAssistantDB.instanceRuns = runs
        PartyAssistantDB.groups = groups
        PartyAssistantDB.groupCollapsed = collapsed
        PartyAssistantDB.hideNames = hideNames
        PartyAssistantDB.autoLeader = autoLeader
        PartyAssistantDB.autoReset = autoReset
        
        for i = 1, MAX_RECENT_PLAYERS do
            local t = temp[i]
            if t then PartyAssistantDB[t.name] = t.data end
        end
    end
end

local function RecordGroupMembers()
    if not IsInGroup() then
        table.wipe(activeGroupNames)
        return
    end
    
    local isRaid = IsInRaid()
    local numMembers = GetNumGroupMembers()
    local prefix = isRaid and "raid" or "party"
    local addedNew = false
    
    for i = 1, numMembers do
        local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
        if UnitExists(unit) then
            local name, realm = UnitName(unit)
            local isHex = name and name:match("^%x+$") and #name >= 6
            if name and name ~= "" and name ~= "未知" and not isHex then
                realm = realm or GetRealmName()
                activeGroupNames[unit] = { name = name, realm = realm }
                
                local fullName = name .. "-" .. realm
                local _, classToken = UnitClass(unit)
                local level = UnitLevel(unit)
                
                if not PartyAssistantDB[fullName] then
                    PartyAssistantDB[fullName] = {
                        time = time(),
                        class = classToken,
                        level = level,
                        realm = realm,
                        shortName = name,
                        group = "无分组"
                    }
                else
                    PartyAssistantDB[fullName].time = time()
                    PartyAssistantDB[fullName].class = classToken or PartyAssistantDB[fullName].class
                    if level and level > 0 then
                        PartyAssistantDB[fullName].level = level
                    end
                    PartyAssistantDB[fullName].group = PartyAssistantDB[fullName].group or "无分组"
                end
                addedNew = true
            end
        end
    end
    
    CheckAllOfflineAutoReset()

    if addedNew then
        CleanupRecentDB()
        if PartyAssistantFrame and PartyAssistantFrame:IsShown() and PartyAssistantFrame.currentTab == 2 then
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
        end
    end
end

-- ==========================================
-- 2. UI 界面构建
-- ==========================================
local mainFrame = CreateFrame("Frame", "PartyAssistantFrame", UIParent, "BasicFrameTemplateWithInset")
mainFrame:SetSize(530, 550) 
mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
mainFrame:Hide()
mainFrame:SetMovable(true)
mainFrame:EnableMouse(true)
mainFrame:RegisterForDrag("LeftButton")
mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing)
mainFrame:SetScript("OnShow", function()
    if mainFrame.hideNameCb then
        mainFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
    end
    if mainFrame.autoResetCb then
        mainFrame.autoResetCb:SetChecked(PartyAssistantDB.autoReset)
    end
end)

mainFrame.title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.title:SetPoint("CENTER", mainFrame.TitleBg, "CENTER", 0, 0)
mainFrame.title:SetText("多开组队助手")

mainFrame.zoneText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.zoneText:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -28)
mainFrame.zoneText:SetText("当前地图: " .. GetUnitLocation("player"))

mainFrame.trackerText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
mainFrame.trackerText:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -15, -28)

mainFrame.timerText = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
mainFrame.timerText:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -15, -42)

mainFrame.currentTab = 1
mainFrame.listData = {}

local function SwitchTab(tabId)
    mainFrame.currentTab = tabId
    if tabId == 1 then
        mainFrame.tab1.selected:Show()
        mainFrame.tab2.selected:Hide()
        mainFrame.inviteAllBtn:Hide()
        mainFrame.addGroupBtn:Hide()
        mainFrame.exportBtn:Hide()
        mainFrame.importBtn:Hide()
        mainFrame.hideNameCb:Show()
        mainFrame.autoResetCb:Show()
    else
        mainFrame.tab1.selected:Hide()
        mainFrame.tab2.selected:Show()
        mainFrame.inviteAllBtn:Show()
        mainFrame.addGroupBtn:Show()
        mainFrame.exportBtn:Show()
        mainFrame.importBtn:Show()
        mainFrame.hideNameCb:Hide()
        mainFrame.autoResetCb:Hide()
    end
    PartyAssistant_BuildData()
    PartyAssistant_UpdateUI()
end

local function CreateTab(id, text, posX)
    local btn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
    btn:SetSize(110, 24)
    btn:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", posX, -60)
    btn:SetText(text)
    
    btn.selected = btn:CreateTexture(nil, "OVERLAY")
    btn.selected:SetAllPoints()
    btn.selected:SetColorTexture(1, 0.8, 0, 0.2)
    btn.selected:Hide()

    btn:SetScript("OnClick", function() SwitchTab(id) end)
    return btn
end

mainFrame.tab1 = CreateTab(1, "当前队伍", 15)
mainFrame.tab2 = CreateTab(2, "近期往来", 130)

mainFrame.hideNameCb = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.hideNameCb:SetSize(24, 24)
mainFrame.hideNameCb:SetPoint("LEFT", mainFrame.tab2, "RIGHT", 15, -2)
mainFrame.hideNameCb.text = mainFrame.hideNameCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.hideNameCb.text:SetPoint("LEFT", mainFrame.hideNameCb, "RIGHT", 2, 1)
mainFrame.hideNameCb.text:SetText("队伍匿名")
mainFrame.hideNameCb:SetScript("OnClick", function(self)
    PartyAssistantDB.hideNames = self:GetChecked()
    PartyAssistant_UpdateUI()
    if PartyAssistantInfoFrame and PartyAssistantInfoFrame.UpdateInfo then
        PartyAssistantInfoFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
        PartyAssistantInfoFrame.UpdateInfo()
    end
end)

mainFrame.autoResetCb = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.autoResetCb:SetSize(24, 24)
mainFrame.autoResetCb:SetPoint("LEFT", mainFrame.hideNameCb.text, "RIGHT", 15, 0)
mainFrame.autoResetCb.text = mainFrame.autoResetCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainFrame.autoResetCb.text:SetPoint("LEFT", mainFrame.autoResetCb, "RIGHT", 2, 1)
mainFrame.autoResetCb.text:SetText("全员离线自动重置")
mainFrame.autoResetCb:SetScript("OnClick", function(self)
    PartyAssistantDB.autoReset = self:GetChecked()
    if PartyAssistantDB.autoReset then
        print("|cff00ff00[组队助手]|r 已开启【全员离线自动重置副本】功能。")
    else
        print("|cffff9900[组队助手]|r 已关闭【全员离线自动重置副本】功能。")
    end
end)

local scrollFrame = CreateFrame("ScrollFrame", "PartyAssistantScroll", mainFrame, "FauxScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -90)
scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -35, 75)

local ROW_COUNT = 9
local ROW_HEIGHT = 40
mainFrame.rows = {}

for i = 1, ROW_COUNT do
    local row = CreateFrame("Frame", nil, mainFrame)
    row:SetSize(475, ROW_HEIGHT)
    if i == 1 then 
        row:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0)
    else 
        row:SetPoint("TOPLEFT", mainFrame.rows[i-1], "BOTTOMLEFT", 0, -2) 
    end

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.02 or 0.06)

    row.classIcon = row:CreateTexture(nil, "ARTWORK")
    row.classIcon:SetSize(28, 28)
    row.classIcon:SetPoint("LEFT", row, "LEFT", 6, 0)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.nameText:SetPoint("TOPLEFT", row.classIcon, "TOPRIGHT", 8, -2)
    row.nameText:SetHeight(16)
    row.nameText:SetWidth(270)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)

    row.subText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.subText:SetPoint("TOPLEFT", row.nameText, "BOTTOMLEFT", 0, -2)
    row.subText:SetHeight(14)
    row.subText:SetWidth(270)
    row.subText:SetJustifyH("LEFT")
    row.subText:SetWordWrap(false)

    row.removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.removeBtn:SetSize(38, 22)
    row.macroBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.macroBtn:SetSize(38, 22)
    row.extraBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.extraBtn:SetSize(38, 22)
    row.actionBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.actionBtn:SetSize(38, 22)

    mainFrame.rows[i] = row
end

-- 底部快捷功能 (第一排)
local resetBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
resetBtn:SetSize(90, 24)
resetBtn:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 15, 12)
resetBtn:SetText("重置副本")
resetBtn:SetScript("OnClick", SafeResetInstances)

local leaveBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
leaveBtn:SetSize(90, 24)
leaveBtn:SetPoint("LEFT", resetBtn, "RIGHT", 10, 0)
leaveBtn:SetText("离开队伍")
leaveBtn:SetScript("OnClick", function()
    if C_PartyInfo and C_PartyInfo.LeaveParty then C_PartyInfo.LeaveParty()
    elseif LeaveParty then LeaveParty() end
end)

-- 切换专精宏按钮
local specMacroBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
specMacroBtn:SetSize(90, 24)
specMacroBtn:SetPoint("LEFT", leaveBtn, "RIGHT", 10, 0)
specMacroBtn:SetText("切换专精")
specMacroBtn:SetScript("OnClick", function()
    if InCombatLockdown() then print("|cffff0000[组队助手]|r 战斗中无法创建宏！") return end
    local macroName = "切换专精"
    local macroBody = "/specindex 2"
    local idx = GetMacroIndexByName(macroName)
    if idx > 0 then 
        EditMacro(idx, macroName, "INV_Misc_QuestionMark", macroBody)
    else 
        CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, true) 
    end
    print("|cff00ff00[组队助手]|r 角色专用宏【切换专精】已生成/更新。")
end)

local addGroupBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
addGroupBtn:SetSize(85, 24)
addGroupBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -125, 12)
addGroupBtn:SetText("新建分组")
addGroupBtn:Hide()
addGroupBtn:SetScript("OnClick", function()
    StaticPopupDialogs["PARTY_ASSISTANT_ADD_GROUP"] = {
        text = "请输入新分组名称：",
        button1 = "确定",
        button2 = "取消",
        hasEditBox = true,
        OnAccept = function(self)
            local text = self.EditBox:GetText()
            if text and text ~= "" then
                PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
                for _, g in ipairs(PartyAssistantDB.groups) do
                    if g == text then print("|cffff0000[组队助手]|r 分组已存在！") return end
                end
                table.insert(PartyAssistantDB.groups, text)
                PartyAssistant_BuildData()
                PartyAssistant_UpdateUI()
                print("|cff00ff00[组队助手]|r 已创建分组: " .. text)
            end
        end,
        EditBoxOnEnterPressed = function(self) self:GetParent():Hide() end,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
    }
    StaticPopup_Show("PARTY_ASSISTANT_ADD_GROUP")
end)
mainFrame.addGroupBtn = addGroupBtn

local inviteAllBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
inviteAllBtn:SetSize(100, 24)
inviteAllBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 12)
inviteAllBtn:SetText("一键组全员")
inviteAllBtn:Hide()
inviteAllBtn:SetScript("OnClick", function()
    local count = 0
    local myFullName = UnitName("player") .. "-" .. GetRealmName()
    for fullName, data in pairs(PartyAssistantDB) do
        if fullName ~= "instanceRuns" and fullName ~= "groups" and fullName ~= "groupCollapsed" and fullName ~= "hideNames" and fullName ~= "autoLeader" and fullName ~= "autoReset" and type(data) == "table" then
            if fullName ~= myFullName then
                InviteUnit(fullName)
                count = count + 1
            end
        end
    end
    print("|cff00ff00[组队助手]|r 已向历史列表中的 " .. count .. " 位成员发送邀请。")
end)
mainFrame.inviteAllBtn = inviteAllBtn

local exportBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
exportBtn:SetSize(100, 24)
exportBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 42)
exportBtn:SetText("导出分组配置")
exportBtn:Hide()
exportBtn:SetScript("OnClick", function()
    local exportData = {}
    for fn, data in pairs(PartyAssistantDB) do
        if type(data) == "table" and data.group and data.group ~= "无分组" then
            table.insert(exportData, fn .. "=" .. data.group)
        end
    end
    local str = table.concat(exportData, ";")
    if str == "" then print("|cffff0000[组队助手]|r 暂无有效分组数据可导出！") return end
    
    StaticPopupDialogs["PA_EXPORT"] = {
        text = "请 Ctrl+C 复制以下导出数据：",
        button1 = "关闭",
        hasEditBox = true,
        OnShow = function(self)
            self.EditBox:SetText(str)
            self.EditBox:HighlightText()
            self.EditBox:SetFocus()
        end,
        timeout = 0, whileDead = true, hideOnEscape = true,
    }
    StaticPopup_Show("PA_EXPORT")
end)
mainFrame.exportBtn = exportBtn

local importBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
importBtn:SetSize(85, 24)
importBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -125, 42)
importBtn:SetText("导入分组")
importBtn:Hide()
importBtn:SetScript("OnClick", function()
    StaticPopupDialogs["PA_IMPORT"] = {
        text = "请 Ctrl+V 粘贴分组数据进行导入：",
        button1 = "导入",
        button2 = "取消",
        hasEditBox = true,
        OnAccept = function(self)
            local str = self.EditBox:GetText()
            if not str or str == "" then return end
            
            local importCount = 0
            for pair in str:gmatch("[^;]+") do
                local fn, grp = pair:match("([^=]+)=([^=]+)")
                if fn and grp then
                    if PartyAssistantDB[fn] then
                        PartyAssistantDB[fn].group = grp
                    else
                        local name, realm = fn:match("^(.-)%-(.+)$")
                        PartyAssistantDB[fn] = {
                            time = time(),
                            shortName = name or fn,
                            realm = realm or GetRealmName(),
                            group = grp
                        }
                    end
                    local groupExists = false
                    for _, g in ipairs(PartyAssistantDB.groups) do
                        if g == grp then groupExists = true; break end
                    end
                    if not groupExists then table.insert(PartyAssistantDB.groups, grp) end
                    importCount = importCount + 1
                end
            end
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
            print(string.format("|cff00ff00[组队助手]|r 成功导入了 %d 条分组数据！", importCount))
        end,
        timeout = 0, whileDead = true, hideOnEscape = true,
    }
    StaticPopup_Show("PA_IMPORT")
end)
mainFrame.importBtn = importBtn

local roleMacroBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
roleMacroBtn:SetSize(90, 24)
roleMacroBtn:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 15, 42)
roleMacroBtn:SetText("职责确认宏")
roleMacroBtn:SetScript("OnClick", function()
    if InCombatLockdown() then print("|cffff0000[组队助手]|r 战斗中无法创建宏！") return end
    local macroName = "职责确认"
    local macroBody = "/click LFDRoleCheckPopupAcceptButton"
    local idx = GetMacroIndexByName(macroName)
    if idx > 0 then EditMacro(idx, macroName, "INV_Misc_QuestionMark", macroBody)
    else CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, true) end
    print("|cff00ff00[组队助手]|r 角色专用宏【职责确认】已生成/更新。")
end)

local enterMacroBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
enterMacroBtn:SetSize(90, 24)
enterMacroBtn:SetPoint("LEFT", roleMacroBtn, "RIGHT", 10, 0)
enterMacroBtn:SetText("进入副本宏")
enterMacroBtn:SetScript("OnClick", function()
    if InCombatLockdown() then print("|cffff0000[组队助手]|r 战斗中无法创建宏！") return end
    local macroName = "进入副本"
    local macroBody = "/click LFGDungeonReadyDialogEnterDungeonButton"
    local idx = GetMacroIndexByName(macroName)
    if idx > 0 then EditMacro(idx, macroName, "INV_Misc_QuestionMark", macroBody)
    else CreateMacro(macroName, "INV_Misc_QuestionMark", macroBody, true) end
    print("|cff00ff00[组队助手]|r 角色专用宏【进入副本】已生成/更新。")
end)

local infoBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
infoBtn:SetSize(90, 24)
infoBtn:SetPoint("LEFT", enterMacroBtn, "RIGHT", 10, 0)
infoBtn:SetText("队伍信息")
infoBtn:SetScript("OnClick", function()
    if PartyAssistantInfoFrame:IsShown() then PartyAssistantInfoFrame:Hide()
    else PartyAssistantInfoFrame:Show() end
end)

-- ==========================================
-- 2.5 队伍独立信息面板
-- ==========================================
local infoFrame = CreateFrame("Frame", "PartyAssistantInfoFrame", UIParent, "BasicFrameTemplateWithInset")
infoFrame:SetSize(220, 150)
infoFrame:SetPoint("CENTER", UIParent, "CENTER", 300, 0)
infoFrame:Hide()
infoFrame:SetMovable(true)
infoFrame:EnableMouse(true)
infoFrame:RegisterForDrag("LeftButton")
infoFrame:SetScript("OnDragStart", infoFrame.StartMoving)
infoFrame:SetScript("OnDragStop", infoFrame.StopMovingOrSizing)

infoFrame.title = infoFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
infoFrame.title:SetPoint("CENTER", infoFrame.TitleBg, "CENTER", 0, 0)
infoFrame.title:SetText("队伍等级信息")

infoFrame.hideNameCb = CreateFrame("CheckButton", nil, infoFrame, "UICheckButtonTemplate")
infoFrame.hideNameCb:SetPoint("BOTTOMLEFT", infoFrame, "BOTTOMLEFT", 12, 8)
infoFrame.hideNameCb:SetSize(24, 24)
infoFrame.hideNameCb.text = infoFrame.hideNameCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
infoFrame.hideNameCb.text:SetPoint("LEFT", infoFrame.hideNameCb, "RIGHT", 2, 1)
infoFrame.hideNameCb.text:SetText("匿名模式(隐藏角色名)")
infoFrame.hideNameCb:SetScript("OnClick", function(self)
    PartyAssistantDB.hideNames = self:GetChecked()
    if infoFrame.UpdateInfo then infoFrame.UpdateInfo() end
    if PartyAssistantFrame and PartyAssistantFrame:IsShown() then
        PartyAssistantFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
        PartyAssistant_UpdateUI()
    end
end)

infoFrame:SetScript("OnShow", function()
    infoFrame.hideNameCb:SetChecked(PartyAssistantDB.hideNames)
    if infoFrame.UpdateInfo then infoFrame.UpdateInfo() end
end)

infoFrame.rows = {}
local MAX_INFO_ROWS = 40
for i = 1, MAX_INFO_ROWS do
    local row = CreateFrame("Frame", nil, infoFrame)
    row:SetSize(190, 20)
    if i == 1 then row:SetPoint("TOPLEFT", infoFrame, "TOPLEFT", 15, -30)
    else row:SetPoint("TOPLEFT", infoFrame.rows[i-1], "BOTTOMLEFT", 0, 0) end

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.nameText:SetPoint("LEFT", row, "LEFT", 0, 0)
    row.nameText:SetJustifyH("LEFT")

    row.levelText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.levelText:SetPoint("RIGHT", row, "RIGHT", -5, 0)
    row.levelText:SetJustifyH("RIGHT")
    row:Hide()
    infoFrame.rows[i] = row
end

infoFrame.UpdateInfo = function()
    if not infoFrame:IsShown() then return end
    
    local num = IsInGroup() and GetNumGroupMembers() or 0
    local hideNames = PartyAssistantDB.hideNames
    
    if num == 0 then
        infoFrame.rows[1].nameText:SetText("|cff888888当前不在队伍中。|r")
        infoFrame.rows[1].levelText:SetText("")
        infoFrame.rows[1]:Show()
        for i = 2, MAX_INFO_ROWS do infoFrame.rows[i]:Hide() end
        infoFrame:SetHeight(85)
        return
    end

    local isRaid = IsInRaid()
    local prefix = isRaid and "raid" or "party"
    local displayCount = 0

    for i = 1, MAX_INFO_ROWS do
        if i <= num then
            local unit = isRaid and (prefix..i) or (i == num and "player" or prefix..i)
            if UnitExists(unit) then
                displayCount = displayCount + 1
                local name = UnitName(unit)
                local level = UnitLevel(unit)
                local classColor = "ffffffff"
                
                if not UnitIsConnected(unit) then
                    classColor = "ff888888"
                else
                    local _, classToken = UnitClass(unit)
                    if classToken and RAID_CLASS_COLORS[classToken] then
                        classColor = RAID_CLASS_COLORS[classToken].colorStr
                    end
                end
                
                local displayName = hideNames and string.format("队友 %d", displayCount) or name
                infoFrame.rows[i].nameText:SetText(string.format("|c%s%s|r", classColor, displayName))
                if level and level > 0 then infoFrame.rows[i].levelText:SetText(string.format("|cffffff00%d级|r", level))
                else infoFrame.rows[i].levelText:SetText("|cff888888未知|r") end
                infoFrame.rows[i]:Show()
            else
                infoFrame.rows[i]:Hide()
            end
        else
            infoFrame.rows[i]:Hide()
        end
    end
    infoFrame:SetHeight(30 + (displayCount * 20) + 40)
end

-- ==========================================
-- Tracker 更新
-- ==========================================
function PartyAssistant_UpdateTrackerDisplay()
    local count, timeRemaining = GetInstanceTimerInfo()
    local countColor = (count >= INSTANCE_LIMIT) and "|cffff0000" or ((count >= 8) and "|cffff9900" or "|cff00ff00")
    mainFrame.trackerText:SetText(string.format("1小时刷本: %s%d/%d|r 次", countColor, count, INSTANCE_LIMIT))
    
    if count >= INSTANCE_LIMIT then
        mainFrame.timerText:SetText(string.format("|cffff0000[爆本中] 首刷解锁: %s|r", FormatTimer(timeRemaining)))
    elseif timeRemaining > 0 then
        mainFrame.timerText:SetText(string.format("首刷解锁倒计时: %s", FormatTimer(timeRemaining)))
    else
        mainFrame.timerText:SetText("首刷解锁倒计时: 无")
    end
end

local lastUpdateTimer = 0
mainFrame:SetScript("OnUpdate", function(self, elapsed)
    lastUpdateTimer = lastUpdateTimer + elapsed
    if lastUpdateTimer >= 1 then
        lastUpdateTimer = 0
        if mainFrame:IsShown() then PartyAssistant_UpdateTrackerDisplay() end
    end
end)

-- ==========================================
-- 3. 数据渲染逻辑
-- ==========================================
function PartyAssistant_BuildData()
    table.wipe(mainFrame.listData)
    
    if mainFrame.currentTab == 1 then
        if IsInGroup() then
            local isRaid = IsInRaid()
            local numMembers = GetNumGroupMembers()
            local prefix = isRaid and "raid" or "party"
            local displayCount = 0
            
            for i = 1, numMembers do
                local unit = isRaid and (prefix..i) or (i == numMembers and "player" or prefix..i)
                local name, realm = UnitName(unit)
                local isHex = name and name:match("^%x+$") and #name >= 6
                if isHex and activeGroupNames[unit] then
                    name = activeGroupNames[unit].name
                    realm = activeGroupNames[unit].realm
                end
                
                if name and name ~= "未知" and not name:match("^%x+$") then
                    displayCount = displayCount + 1
                    realm = realm or GetRealmName()
                    local fullName = name .. "-" .. realm
                    local _, classToken = UnitClass(unit)
                    local level = UnitLevel(unit)
                    
                    if not classToken and PartyAssistantDB[fullName] then classToken = PartyAssistantDB[fullName].class end
                    if (not level or level == 0) and PartyAssistantDB[fullName] then level = PartyAssistantDB[fullName].level end
                    
                    table.insert(mainFrame.listData, {
                        type = "CURRENT",
                        unit = unit,
                        fullName = fullName,
                        shortName = name,
                        anonName = "队友 " .. displayCount,
                        realm = realm,
                        class = classToken,
                        level = level,
                        zone = GetUnitLocation(unit),
                        isLeader = UnitIsGroupLeader(unit),
                        isOnline = UnitIsConnected(unit)
                    })
                end
            end
        end
    elseif mainFrame.currentTab == 2 then
        PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
        PartyAssistantDB.groupCollapsed = PartyAssistantDB.groupCollapsed or {}
        
        local groupMap = {}
        for _, gName in ipairs(PartyAssistantDB.groups) do
            groupMap[gName] = { name = gName, members = {} }
        end
        
        for fullName, data in pairs(PartyAssistantDB) do
            if fullName ~= "instanceRuns" and fullName ~= "groups" and fullName ~= "groupCollapsed" and fullName ~= "hideNames" and fullName ~= "autoLeader" and fullName ~= "autoReset" and type(data) == "table" and data.time and data.shortName and data.shortName ~= "未知" then
                local gName = data.group or "无分组"
                if not groupMap[gName] then
                    groupMap[gName] = { name = gName, members = {} }
                    table.insert(PartyAssistantDB.groups, gName)
                end
                table.insert(groupMap[gName].members, {
                    type = "RECENT",
                    fullName = fullName,
                    shortName = data.shortName,
                    realm = data.realm,
                    class = data.class,
                    level = data.level,
                    time = data.time or 0,
                    group = gName
                })
            end
        end
        
        for _, gData in pairs(groupMap) do table.sort(gData.members, function(a, b) return a.time > b.time end) end
        
        for _, gName in ipairs(PartyAssistantDB.groups) do
            local gData = groupMap[gName]
            if gData then
                local total = #gData.members
                local isCollapsed = PartyAssistantDB.groupCollapsed[gName] or false
                table.insert(mainFrame.listData, { type = "HEADER", groupName = gName, count = total, members = gData.members, isCollapsed = isCollapsed })
                if not isCollapsed then
                    for _, member in ipairs(gData.members) do table.insert(mainFrame.listData, member) end
                end
            end
        end
    end
end

-- ==========================================
-- 公用工具：构建队员管理菜单
-- ==========================================
local function BuildManageMenu(owner, rootDescription, data)
    rootDescription:CreateTitle("角色管理操作")
    
    local groupSub = rootDescription:CreateButton("移动到分组")
    for _, gName in ipairs(PartyAssistantDB.groups) do
        groupSub:CreateButton(gName, function()
            PartyAssistantDB[data.fullName].group = gName
            print(string.format("|cff00ff00[组队助手]|r 已将 |cffffcc00%s|r 移动至分组: |cff00ffff%s|r", data.shortName, gName))
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
        end)
    end
    
    if PartyAssistantDB.autoLeader == data.fullName then
        rootDescription:CreateButton("取消自动转移队长", function()
            PartyAssistantDB.autoLeader = nil
            print(string.format("|cff00ff00[组队助手]|r 已取消 |cffffcc00%s|r 的自动队长状态。", data.shortName))
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
        end)
    else
        rootDescription:CreateButton("设为自动转移队长", function()
            PartyAssistantDB.autoLeader = data.fullName
            print(string.format("|cff00ff00[组队助手]|r 已将 |cffffcc00%s|r 设为核心自动队长，上线或进组时自动交接！", data.shortName))
            PartyAssistant_BuildData()
            PartyAssistant_UpdateUI()
            CheckAndPromoteDesignatedLeader()
        end)
    end

    rootDescription:CreateButton("复制角色名字", function()
        StaticPopupDialogs["PA_COPY_NAME"] = {
            text = "请按 Ctrl+C 复制名字：",
            button1 = "关闭",
            hasEditBox = true,
            OnShow = function(self)
                self.EditBox:SetText(data.fullName)
                self.EditBox:HighlightText()
                self.EditBox:SetFocus()
            end,
            timeout = 0, whileDead = true, hideOnEscape = true,
        }
        StaticPopup_Show("PA_COPY_NAME")
    end)
end

function PartyAssistant_UpdateUI()
    if not mainFrame:IsShown() then return end
    mainFrame.zoneText:SetText("当前地图: " .. GetUnitLocation("player"))
    PartyAssistant_UpdateTrackerDisplay()
    
    local totalItems = #mainFrame.listData
    FauxScrollFrame_Update(scrollFrame, totalItems, ROW_COUNT, ROW_HEIGHT)
    local offset = FauxScrollFrame_GetOffset(scrollFrame)
    local isPlayerLeader = UnitIsGroupLeader("player")

    for i = 1, ROW_COUNT do
        local idx = offset + i
        local row = mainFrame.rows[i]
        row:SetScript("OnMouseDown", nil)

        if idx <= totalItems then
            local data = mainFrame.listData[idx]
            
            if data.type == "HEADER" then
                row.bg:SetColorTexture(0.15, 0.15, 0.15, 0.8)
                if data.isCollapsed then row.classIcon:SetTexture("Interface\\Buttons\\UI-PlusButton-UP")
                else row.classIcon:SetTexture("Interface\\Buttons\\UI-MinusButton-UP") end
                row.classIcon:SetTexCoord(0, 1, 0, 1)
                row.classIcon:SetDesaturated(false)

                row.nameText:SetText(string.format("|cffffcc00[%s]|r  |cffaaaaaa(%d)|r", data.groupName, data.count))
                row.subText:SetText("")
                
                row.actionBtn:Show()
                row.extraBtn:Show()
                row.macroBtn:Hide()
                row.removeBtn:Show()

                row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -5, 0)
                row.extraBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -2, 0)
                row.actionBtn:SetPoint("RIGHT", row.extraBtn, "LEFT", -2, 0)

                row.actionBtn:SetText("命名")
                row.actionBtn:Enable()
                row.actionBtn:SetScript("OnClick", function()
                    StaticPopupDialogs["PARTY_ASSISTANT_RENAME_GROUP"] = {
                        text = string.format("请输入 [%s] 的新分组名称：", data.groupName),
                        button1 = "确定",
                        button2 = "取消",
                        hasEditBox = true,
                        OnAccept = function(self)
                            local newName = self.EditBox:GetText()
                            if newName and newName ~= "" and newName ~= data.groupName then
                                PartyAssistantDB.groups = PartyAssistantDB.groups or { "无分组" }
                                for _, g in ipairs(PartyAssistantDB.groups) do
                                    if g == newName then print("|cffff0000[组队助手]|r 分组名已存在！") return end
                                end
                                for j, g in ipairs(PartyAssistantDB.groups) do
                                    if g == data.groupName then PartyAssistantDB.groups[j] = newName break end
                                end
                                for fn, pData in pairs(PartyAssistantDB) do
                                    if fn ~= "instanceRuns" and fn ~= "groups" and fn ~= "groupCollapsed" and fn ~= "hideNames" and fn ~= "autoLeader" and fn ~= "autoReset" and type(pData) == "table" then
                                        if pData.group == data.groupName then pData.group = newName end
                                    end
                                end
                                PartyAssistant_BuildData()
                                PartyAssistant_UpdateUI()
                            end
                        end,
                        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
                    }
                    StaticPopup_Show("PARTY_ASSISTANT_RENAME_GROUP")
                end)

                row.extraBtn:SetText("邀")
                if data.count > 0 then
                    row.extraBtn:Enable()
                    row.extraBtn:SetScript("OnClick", function()
                        local count = 0
                        local myFullName = UnitName("player") .. "-" .. GetRealmName()
                        for fullName, pData in pairs(PartyAssistantDB) do
                            if fullName ~= "instanceRuns" and fullName ~= "groups" and fullName ~= "groupCollapsed" and fullName ~= "hideNames" and fullName ~= "autoLeader" and fullName ~= "autoReset" and type(pData) == "table" then
                                if (pData.group or "无分组") == data.groupName and fullName ~= myFullName then
                                    InviteUnit(fullName)
                                    count = count + 1
                                end
                            end
                        end
                        print(string.format("|cff00ff00[组队助手]|r 已向分组 |cffffcc00[%s]|r 中的 %d 位成员发送邀请。", data.groupName, count))
                    end)
                else
                    row.extraBtn:Disable()
                    row.extraBtn:SetScript("OnClick", nil)
                end

                if data.groupName == "无分组" then
                    row.removeBtn:SetText("删")
                    row.removeBtn:Disable()
                    row.removeBtn:SetScript("OnClick", nil)
                else
                    row.removeBtn:SetText("删")
                    row.removeBtn:Enable()
                    row.removeBtn:SetScript("OnClick", function()
                        for fn, pData in pairs(PartyAssistantDB) do
                            if fn ~= "instanceRuns" and fn ~= "groups" and fn ~= "groupCollapsed" and fn ~= "hideNames" and fn ~= "autoLeader" and fn ~= "autoReset" and type(pData) == "table" then
                                if pData.group == data.groupName then pData.group = "无分组" end
                            end
                        end
                        for j, g in ipairs(PartyAssistantDB.groups) do
                            if g == data.groupName then table.remove(PartyAssistantDB.groups, j) break end
                        end
                        PartyAssistantDB.groupCollapsed[data.groupName] = nil
                        PartyAssistant_BuildData()
                        PartyAssistant_UpdateUI()
                        print("|cff00ff00[组队助手]|r 已删除分组: " .. data.groupName)
                    end)
                end

                row:SetScript("OnMouseDown", function()
                    PartyAssistantDB.groupCollapsed[data.groupName] = not data.isCollapsed
                    PartyAssistant_BuildData()
                    PartyAssistant_UpdateUI()
                end)

            else
                row.bg:SetColorTexture(1, 1, 1, (idx % 2 == 0) and 0.02 or 0.06)

                if data.class and CLASS_ICON_TCOORDS[data.class] then
                    row.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
                    row.classIcon:SetTexCoord(unpack(CLASS_ICON_TCOORDS[data.class]))
                else
                    row.classIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
                    row.classIcon:SetTexCoord(0, 1, 0, 1)
                end

                local classColor = (data.class and RAID_CLASS_COLORS[data.class]) and RAID_CLASS_COLORS[data.class].colorStr or "ffffffff"
                if data.type == "CURRENT" and not data.isOnline then classColor = "ff888888" end

                local leaderIcon = (data.type == "CURRENT" and data.isLeader) and "|TInterface\\GroupFrame\\UI-Group-LeaderIcon:14:14|t " or ""
                local levelStr = (data.level and data.level > 0) and string.format("|cffffff00%d级|r ", data.level) or ""

                if data.type == "CURRENT" then
                    local fullTitle
                    if PartyAssistantDB.hideNames then fullTitle = data.anonName or "队友"
                    else fullTitle = string.format("%s - %s", data.shortName or "未知", data.realm or GetRealmName()) end
                    
                    if PartyAssistantDB.autoLeader == data.fullName then
                        fullTitle = fullTitle .. " |cff00ff00[自动队长]|r"
                    end

                    row.classIcon:SetDesaturated(not data.isOnline)
                    row.nameText:SetText(leaderIcon .. levelStr .. string.format("|c%s%s|r", classColor, fullTitle))
                    row.subText:SetText("位置: " .. (data.zone or "未知位置"))
                    
                    row.actionBtn:Show()
                    row.extraBtn:Show()
                    row.macroBtn:Show()
                    row.removeBtn:Show()

                    row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -5, 0)
                    row.macroBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -2, 0)
                    row.extraBtn:SetPoint("RIGHT", row.macroBtn, "LEFT", -2, 0)
                    row.actionBtn:SetPoint("RIGHT", row.extraBtn, "LEFT", -2, 0)

                    row.actionBtn:SetText("队长")
                    if isPlayerLeader and not UnitIsUnit(data.unit, "player") and data.isOnline then
                        row.actionBtn:Enable()
                        row.actionBtn:SetScript("OnClick", function() PromoteToLeader(data.unit) end)
                    else
                        row.actionBtn:Disable()
                    end

                    row.extraBtn:SetText("管理")
                    row.extraBtn:Enable()
                    row.extraBtn:SetScript("OnClick", function()
                        PartyAssistantDB[data.fullName] = PartyAssistantDB[data.fullName] or {
                            time = time(), class = data.class, level = data.level,
                            realm = data.realm, shortName = data.shortName, group = "无分组"
                        }
                        MenuUtil.CreateContextMenu(row.extraBtn, function(owner, rootDesc) BuildManageMenu(owner, rootDesc, data) end)
                    end)

                    row.macroBtn:SetText("雪球")
                    row.macroBtn:Enable()
                    row.macroBtn:SetScript("OnClick", function() UpdateSnowballMacroSingle(data) end)

                    if isPlayerLeader and not UnitIsUnit(data.unit, "player") then
                        row.removeBtn:SetText("移")
                        row.removeBtn:Enable()
                        row.removeBtn:SetScript("OnClick", function() UninviteUnit(data.unit) end)
                    else
                        row.removeBtn:SetText("移")
                        row.removeBtn:Disable()
                    end
                    
                    if UnitIsUnit(data.unit, "player") then
                        row.actionBtn:Hide()
                        row.macroBtn:Hide()
                        row.removeBtn:Hide()
                    end
                    
                elseif data.type == "RECENT" then
                    local fullTitle = string.format("%s - %s", data.shortName or "未知", data.realm or GetRealmName())
                    if PartyAssistantDB.autoLeader == data.fullName then
                        fullTitle = fullTitle .. " |cff00ff00[自动队长]|r"
                    end
                    
                    row.classIcon:SetDesaturated(false)
                    row.nameText:SetText(levelStr .. string.format("|c%s%s|r", classColor, fullTitle))
                    
                    local timeDiff = time() - (data.time or time())
                    local timeStr = "刚刚"
                    if timeDiff >= 86400 then timeStr = math.floor(timeDiff/86400) .. "天前"
                    elseif timeDiff >= 3600 then timeStr = math.floor(timeDiff/3600) .. "小时前"
                    elseif timeDiff >= 60 then timeStr = math.floor(timeDiff/60) .. "分钟前" end
                    row.subText:SetText(string.format("[%s] %s", data.group or "无分组", timeStr))
                    
                    row.actionBtn:Show()
                    row.extraBtn:Show()
                    row.macroBtn:Show() 
                    row.removeBtn:Show()

                    row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -5, 0)
                    row.macroBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -2, 0)
                    row.extraBtn:SetPoint("RIGHT", row.macroBtn, "LEFT", -2, 0)
                    row.actionBtn:SetPoint("RIGHT", row.extraBtn, "LEFT", -2, 0)

                    row.actionBtn:SetText("邀")
                    row.actionBtn:Enable()
                    row.actionBtn:SetScript("OnClick", function()
                        InviteUnit(data.fullName)
                        print("|cff00ff00[组队助手]|r 已向 " .. data.fullName .. " 发送邀请。")
                    end)

                    row.macroBtn:SetText("密")
                    row.macroBtn:Enable()
                    row.macroBtn:SetScript("OnClick", function() ChatFrame_OpenChat(string.format("/w %s ", data.fullName)) end)

                    row.extraBtn:SetText("管理")
                    row.extraBtn:Enable()
                    row.extraBtn:SetScript("OnClick", function()
                        MenuUtil.CreateContextMenu(row.extraBtn, function(owner, rootDesc) BuildManageMenu(owner, rootDesc, data) end)
                    end)

                    row.removeBtn:SetText("删")
                    row.removeBtn:Enable()
                    row.removeBtn:SetScript("OnClick", function()
                        PartyAssistantDB[data.fullName] = nil
                        if PartyAssistantDB.autoLeader == data.fullName then PartyAssistantDB.autoLeader = nil end
                        PartyAssistant_BuildData()
                        PartyAssistant_UpdateUI()
                        print(string.format("|cff00ff00[组队助手]|r 已从近期往来中删除: |cffffcc00%s|r", data.shortName))
                    end)
                end
            end
            row:Show()
        else
            row:Hide()
        end
    end
end

scrollFrame:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, ROW_HEIGHT, PartyAssistant_UpdateUI)
end)

-- ==========================================
-- 4. 事件监听与指令注册
-- ==========================================
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("ZONE_CHANGED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == addonName then
            PartyAssistantDB = PartyAssistantDB or {}
            PartyAssistantDB.instanceRuns = PartyAssistantDB.instanceRuns or {}
            if PartyAssistantDB.hideNames == nil then PartyAssistantDB.hideNames = false end
            if PartyAssistantDB.autoReset == nil then PartyAssistantDB.autoReset = false end
            CleanupRecentDB()
            SwitchTab(1)
        end
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        CheckInstanceEntry()
        RecordGroupMembers()
        CheckAndPromoteDesignatedLeader()
        CheckAllOfflineAutoReset()
        if mainFrame:IsShown() then PartyAssistant_BuildData(); PartyAssistant_UpdateUI() end
        if PartyAssistantInfoFrame:IsShown() and PartyAssistantInfoFrame.UpdateInfo then PartyAssistantInfoFrame.UpdateInfo() end
    elseif event == "GROUP_ROSTER_UPDATE" or event == "ZONE_CHANGED" then
        RecordGroupMembers()
        CheckAndPromoteDesignatedLeader()
        CheckAllOfflineAutoReset()
        if mainFrame:IsShown() then PartyAssistant_BuildData(); PartyAssistant_UpdateUI() end
        if PartyAssistantInfoFrame:IsShown() and PartyAssistantInfoFrame.UpdateInfo then PartyAssistantInfoFrame.UpdateInfo() end
    end
end)

SLASH_PARTYASSISTANT1 = "/pa"
SLASH_PARTYASSISTANT2 = "/partyassist"
SlashCmdList["PARTYASSISTANT"] = function()
    if mainFrame:IsShown() then mainFrame:Hide()
    else mainFrame:Show(); PartyAssistant_BuildData(); PartyAssistant_UpdateUI() end
end