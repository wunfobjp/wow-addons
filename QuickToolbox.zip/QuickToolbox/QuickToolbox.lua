local ADDON_NAME, AddOn = ...

-- 默认配置初始化
local defaultDB = {
    autoAcceptParty = true,
    autoQuest = true,
    selectedCommunity = "",
    customCommunities = {},
    windowPosition = {"CENTER", nil, "CENTER", 0, 0}
}

QuickToolboxDB = QuickToolboxDB or {}

local function InitDB()
    for k, v in pairs(defaultDB) do
        if QuickToolboxDB[k] == nil then
            QuickToolboxDB[k] = v
        end
    end
end

-- 声明全局 UI 控件变量以便后续刷新
local AutoPartyBtn, AutoQuestBtn, DropDown

-- ==================== 核心逻辑函数 ====================

-- 1. 一键邀请公会在线成员
local function InviteGuildMembers()
    if not IsInGuild() then
        print("|cFFFF0000[工具箱]|r 你当前未加入任何公会！")
        return
    end

    C_GuildInfo.GuildRoster()
    local numTotal = GetNumGuildMembers()
    local invitedCount = 0
    local myName = UnitName("player")

    for i = 1, numTotal do
        local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
        if online and name and name ~= myName then
            if C_PartyInfo and C_PartyInfo.InviteUnit then
                C_PartyInfo.InviteUnit(name)
            else
                InviteUnit(name)
            end
            invitedCount = invitedCount + 1
        end
    end
    print(string.format("|cFF00FF00[工具箱]|r 已向公会在线的 %d 名玩家发送组队邀请", invitedCount))
end

-- 2. 一键邀请指定社区在线成员
local function InviteCommunityMembers(targetClubName)
    if not targetClubName or targetClubName == "" then
        print("|cFFFF0000[工具箱]|r 请先选择或添加社区名称！")
        return
    end

    local clubs = C_Club.GetSubscribedClubs()
    local targetClubId = nil

    for _, club in ipairs(clubs) do
        if club.name == targetClubName then
            targetClubId = club.clubId
            break
        end
    end

    if not targetClubId then
        print("|cFFFF0000[工具箱]|r 未找到匹配的社区: " .. targetClubName)
        return
    end

    if C_Club.FocusClub then
        C_Club.FocusClub(targetClubId)
    end

    local memberIds = C_Club.GetClubMembers(targetClubId)
    local invitedCount = 0
    local myGUID = UnitGUID("player")

    for _, memberId in ipairs(memberIds) do
        local info = C_Club.GetMemberInfo(targetClubId, memberId)
        if info and info.guid and info.guid ~= myGUID then
            local isOnline = (info.presence == Enum.ClubMemberPresence.Online or 
                              info.presence == Enum.ClubMemberPresence.Away or 
                              info.presence == Enum.ClubMemberPresence.Busy)

            if isOnline and info.name and info.name ~= "" then
                local targetName = info.name
                if not string.find(targetName, "-") and info.realm then
                    targetName = targetName .. "-" .. info.realm
                end

                if C_PartyInfo and C_PartyInfo.InviteUnit then
                    C_PartyInfo.InviteUnit(targetName)
                else
                    InviteUnit(targetName)
                end
                invitedCount = invitedCount + 1
            end
        end
    end

    if invitedCount == 0 then
        print(string.format("|cFFFFCC00[工具箱]|r 社区 [%s] 暂未刷新到在线成员，请按 J 键打开一次社区界面后再试。", targetClubName))
    else
        print(string.format("|cFF00FF00[工具箱]|r 已向社区 [%s] 在线的 %d 名玩家发送组队邀请", targetClubName, invitedCount))
    end
end

-- 下拉菜单文本刷新
local function RefreshDropDownText()
    local currentText = QuickToolboxDB and QuickToolboxDB.selectedCommunity
    if not currentText or currentText == "" then
        currentText = "选择社区"
    end
    if DropDown then
        UIDropDownMenu_SetText(DropDown, currentText)
    end
end

-- 整体 UI 文本同步刷新
local function RefreshUI()
    if AutoPartyBtn then
        AutoPartyBtn:SetText(QuickToolboxDB.autoAcceptParty and "自动组队: 开" or "自动组队: 关")
    end
    if AutoQuestBtn then
        AutoQuestBtn:SetText(QuickToolboxDB.autoQuest and "自动交接: 开" or "自动交接: 关")
    end
    RefreshDropDownText()
end

-- ==================== 事件监听机制 ====================

local EventFrame = CreateFrame("Frame")
EventFrame:RegisterEvent("ADDON_LOADED")
EventFrame:RegisterEvent("PARTY_INVITE_REQUEST")
-- 任务相关事件
EventFrame:RegisterEvent("GOSSIP_SHOW") -- 关键：新增对话列表显示事件
EventFrame:RegisterEvent("QUEST_DETAIL")
EventFrame:RegisterEvent("QUEST_ACCEPT_CONFIRM")
EventFrame:RegisterEvent("QUEST_PROGRESS")
EventFrame:RegisterEvent("QUEST_COMPLETE")

EventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == ADDON_NAME then
            InitDB()
            RefreshUI()
        end
    elseif event == "PARTY_INVITE_REQUEST" then
        if QuickToolboxDB.autoAcceptParty then
            local inviterName = ...
            AcceptGroup()
            StaticPopup_Hide("PARTY_INVITE")
            print("|cFF00FF00[工具箱]|r 已自动接受来自 [" .. tostring(inviterName) .. "] 的组队邀请")
        end
    elseif QuickToolboxDB.autoQuest then
        -- 按住 Shift 键时临时暂停自动交接（方便手动选择或看对话/买东西）
        if IsShiftKeyDown() then return end

        if event == "GOSSIP_SHOW" then
            -- 1. 优先点击已完成待交付的任务
            local activeQuests = C_GossipInfo.GetActiveQuests()
            if activeQuests then
                for _, quest in ipairs(activeQuests) do
                    if quest.isComplete then
                        C_GossipInfo.SelectActiveQuest(quest.questID)
                        return
                    end
                end
            end

            -- 2. 自动点击可接取的任务
            local availableQuests = C_GossipInfo.GetAvailableQuests()
            if availableQuests and #availableQuests > 0 then
                C_GossipInfo.SelectAvailableQuest(availableQuests[1].questID)
                return
            end

        elseif event == "QUEST_DETAIL" then
            AcceptQuest()
        elseif event == "QUEST_ACCEPT_CONFIRM" then
            ConfirmAcceptQuest()
        elseif event == "QUEST_PROGRESS" then
            if IsQuestCompletable() then
                CompleteQuest()
            end
        elseif event == "QUEST_COMPLETE" then
            if GetNumQuestChoices() <= 1 then
                GetQuestReward(1)
            end
        end
    end
end)

-- ==================== UI 界面构建 ====================

local MainFrame = CreateFrame("Frame", "QuickToolboxMainFrame", UIParent, "BackdropTemplate")
MainFrame:SetSize(130, 190)
MainFrame:SetPoint(unpack(QuickToolboxDB.windowPosition or {"CENTER", nil, "CENTER", 0, 0}))
MainFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
MainFrame:SetBackdropColor(0.05, 0.15, 0.1, 0.85)
MainFrame:SetBackdropBorderColor(0.2, 0.9, 0.4, 0.9)

MainFrame:EnableMouse(true)
MainFrame:SetMovable(true)
MainFrame:RegisterForDrag("LeftButton")
MainFrame:SetScript("OnDragStart", MainFrame.StartMoving)
MainFrame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, relPoint, x, y = self:GetPoint()
    QuickToolboxDB.windowPosition = {point, nil, relPoint, x, y}
end)

local function CreateStyledButton(parent, text, onClick)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(106, 28)
    btn:SetText(text)
    btn:SetScript("OnClick", onClick)
    return btn
end

-- 1. 邀请公会
local GuildInviteBtn = CreateStyledButton(MainFrame, "邀请公会", function()
    InviteGuildMembers()
end)
GuildInviteBtn:SetPoint("TOP", MainFrame, "TOP", 0, -12)

-- 2. 邀请社区
local ClubInviteBtn = CreateStyledButton(MainFrame, "邀请社区", function()
    InviteCommunityMembers(QuickToolboxDB.selectedCommunity)
end)
ClubInviteBtn:SetPoint("TOP", GuildInviteBtn, "BOTTOM", 0, -6)

-- 3. 社区选择下拉菜单
DropDown = CreateFrame("Frame", "QuickToolboxCommunityDropDown", MainFrame, "UIDropDownMenuTemplate")
DropDown:SetPoint("TOP", ClubInviteBtn, "BOTTOM", 1, -4)
UIDropDownMenu_SetWidth(DropDown, 80)

UIDropDownMenu_Initialize(DropDown, function(self, level)
    local info = UIDropDownMenu_CreateInfo()

    local clubs = C_Club.GetSubscribedClubs()
    if #clubs > 0 then
        info.isTitle = true
        info.text = "--- 已加入的社区 ---"
        info.notCheckable = true
        UIDropDownMenu_AddButton(info, level)

        for _, club in ipairs(clubs) do
            info = UIDropDownMenu_CreateInfo()
            info.text = club.name
            info.func = function()
                QuickToolboxDB.selectedCommunity = club.name
                RefreshDropDownText()
            end
            info.checked = (QuickToolboxDB.selectedCommunity == club.name)
            UIDropDownMenu_AddButton(info, level)
        end
    end

    if QuickToolboxDB.customCommunities and #QuickToolboxDB.customCommunities > 0 then
        info = UIDropDownMenu_CreateInfo()
        info.isTitle = true
        info.text = "--- 自定义记录 ---"
        info.notCheckable = true
        UIDropDownMenu_AddButton(info, level)

        for _, cName in ipairs(QuickToolboxDB.customCommunities) do
            info = UIDropDownMenu_CreateInfo()
            info.text = cName
            info.func = function()
                QuickToolboxDB.selectedCommunity = cName
                RefreshDropDownText()
            end
            info.checked = (QuickToolboxDB.selectedCommunity == cName)
            UIDropDownMenu_AddButton(info, level)
        end
    end

    info = UIDropDownMenu_CreateInfo()
    info.text = "|cFF00FF00+ 手动输入社区|r"
    info.notCheckable = true
    info.func = function()
        StaticPopup_Show("QUICKTOOLBOX_ADD_COMMUNITY")
    end
    UIDropDownMenu_AddButton(info, level)
end)

StaticPopupDialogs["QUICKTOOLBOX_ADD_COMMUNITY"] = {
    text = "请输入社区完整名称：",
    button1 = "添加",
    button2 = "取消",
    hasEditBox = true,
    OnAccept = function(self)
        local text = self.editBox:GetText()
        if text and text ~= "" then
            QuickToolboxDB.selectedCommunity = text
            table.insert(QuickToolboxDB.customCommunities, text)
            RefreshDropDownText()
            print("|cFF00FF00[工具箱]|r 已保存社区名称: " .. text)
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

-- 4. 自动组队开关
AutoPartyBtn = CreateStyledButton(MainFrame, "", function(self)
    QuickToolboxDB.autoAcceptParty = not QuickToolboxDB.autoAcceptParty
    RefreshUI()
end)
AutoPartyBtn:SetPoint("TOP", ClubInviteBtn, "BOTTOM", 0, -40)

-- 5. 自动交接开关
AutoQuestBtn = CreateStyledButton(MainFrame, "", function(self)
    QuickToolboxDB.autoQuest = not QuickToolboxDB.autoQuest
    RefreshUI()
end)
AutoQuestBtn:SetPoint("TOP", AutoPartyBtn, "BOTTOM", 0, -6)

-- 斜杠命令支持
SLASH_QUICKTOOLBOX1 = "/qt"
SLASH_QUICKTOOLBOX2 = "/quicktoolbox"
SlashCmdList["QUICKTOOLBOX"] = function()
    if MainFrame:IsShown() then
        MainFrame:Hide()
    else
        MainFrame:Show()
    end
end