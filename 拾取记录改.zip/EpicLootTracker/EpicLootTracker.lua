print("|cff00ff00[调试] 成功读取了优化布局与插槽●显示的Lua文件！|r")
local addonName, addonTable = ...
local GetItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo

-- ==========================================
-- 0. 物品额外属性（插槽●与第三属性）解析辅助函数
-- ==========================================
local EpicLootTooltipScan = nil
local function GetItemExtraDetails(itemLink)
    if not itemLink then return "-", "-" end
    
    local socketCount = 0
    local tertiaryMap = {}
    
    local function parseLine(text)
        if not text or text == "" then return end
        
        -- 过滤掉“装备：”和“使用：”等特效描述行，防止将特效文字误认为第三属性
        if string.find(text, "装备：") or string.find(text, "装备:") or 
           string.find(text, "使用：") or string.find(text, "使用:") or
           string.find(text, "Equip:") or string.find(text, "Use:") then
            return
        end
        
        if string.find(text, "插槽") or string.find(text, "Socket") then
            socketCount = socketCount + 1
        end
        
        if string.find(text, "加速") or string.find(text, "吸血") or string.find(text, "闪避") or string.find(text, "回避") or string.find(text, "永不磨损") or string.find(text, "不坏") or
           string.find(text, "Speed") or string.find(text, "Leech") or string.find(text, "Avoidance") or string.find(text, "Indestructible") then
            if string.find(text, "加速") or string.find(text, "Speed") then tertiaryMap["加速"] = true end
            if string.find(text, "吸血") or string.find(text, "Leech") then tertiaryMap["吸血"] = true end
            if string.find(text, "闪避") or string.find(text, "回避") or string.find(text, "Avoidance") then tertiaryMap["闪避"] = true end
            if string.find(text, "永不磨损") or string.find(text, "不坏") or string.find(text, "Indestructible") then tertiaryMap["永不磨损"] = true end
        end
    end
    
    if C_TooltipInfo and C_TooltipInfo.GetHyperlink then
        local data = C_TooltipInfo.GetHyperlink(itemLink)
        if data and data.lines then
            -- 从第 2 行开始遍历，跳过第 1 行的物品名称
            for i = 2, #data.lines do
                parseLine(data.lines[i].leftText)
            end
        end
    else
        if not EpicLootTooltipScan then
            EpicLootTooltipScan = CreateFrame("GameTooltip", "EpicLootTooltipScan", nil, "GameTooltipTemplate")
            EpicLootTooltipScan:SetOwner(UIParent, "ANCHOR_NONE")
        end
        EpicLootTooltipScan:ClearLines()
        EpicLootTooltipScan:SetHyperlink(itemLink)
        -- 从第 2 行开始遍历，跳过第 1 行的物品名称
        for i = 2, EpicLootTooltipScan:NumLines() do
            local left = _G["EpicLootTooltipScanTextLeft" .. i]
            if left then
                parseLine(left:GetText())
            end
        end
    end
    
    local socketStr = socketCount > 0 and string.format("|cff00ff00%s|r", string.rep("●", socketCount)) or "-"
    
    local tertiaryList = {}
    for k, _ in pairs(tertiaryMap) do
        table.insert(tertiaryList, k)
    end
    local tertiaryStr = #tertiaryList > 0 and string.format("|cffff8000%s|r", table.concat(tertiaryList, "/")) or "-"
    
    return socketStr, tertiaryStr
end

-- ==========================================
-- 1. 弹窗二次确认注册
-- ==========================================
StaticPopupDialogs["EPIC_LOOT_TRACKER_CONFIRM_DELETE"] = {
    text = "确定要删除 [%s] 的拾取记录吗？",
    button1 = "确定",
    button2 = "取消",
    OnAccept = function(self, data)
        if data and data.dbIndex and EpicLootTrackerDB[data.dbIndex] then
            table.remove(EpicLootTrackerDB, data.dbIndex)
            EpicLootTracker_BuildData()
            EpicLootTracker_UpdateUI()
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["EPIC_LOOT_TRACKER_CONFIRM_CLEAR"] = {
    text = "|cffFF0000确定要清空当前列表显示的所有记录吗？|r\n此操作无法撤销！",
    button1 = "确定清空",
    button2 = "取消",
    OnAccept = function(self)
        if mainFrame.currentTimeFilter == "ALL" and mainFrame.searchBox:GetText() == "" then
            table.wipe(EpicLootTrackerDB)
        else
            for i = #mainFrame.filteredData, 1, -1 do
                local dbIdx = mainFrame.filteredData[i].dbIndex
                table.remove(EpicLootTrackerDB, dbIdx)
            end
        end
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["EPIC_LOOT_TRACKER_ADD_WHITELIST"] = {
    text = "请输入物品ID，或按住Shift将物品贴入框内：",
    button1 = "添加",
    button2 = "取消",
    hasEditBox = true,
    OnAccept = function(self)
        local text = self.editBox:GetText()
        local itemID = tonumber(string.match(text, "item:(%d+)")) or tonumber(text)
        if itemID then
            EpicLootTrackerConfig.whitelist = EpicLootTrackerConfig.whitelist or {}
            EpicLootTrackerConfig.whitelist[itemID] = true
            if EpicLootTracker_UpdateWhitelistUI then EpicLootTracker_UpdateWhitelistUI() end
            print("|cff00ff00[EpicLootTracker] 物品已被加入白名单！|r")
        else
            print("|cffff0000[EpicLootTracker] 格式错误，请贴入物品链接或输入纯数字ID。|r")
        end
    end,
    EditBoxOnEnterPressed = function(self)
        local parent = self:GetParent()
        StaticPopupDialogs["EPIC_LOOT_TRACKER_ADD_WHITELIST"].OnAccept(parent)
        parent:Hide()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

-- ==========================================
-- 1.5 黑名单 UI 独立模块
-- ==========================================
local BlacklistFrame = nil

local function UpdateBlacklistScroll(scrollChild)
    for _, child in ipairs({scrollChild:GetChildren()}) do
        child:Hide()
        child:SetParent(nil)
    end

    local yOffset = -5
    for itemID, _ in pairs(EpicLootTrackerConfig.blacklist or {}) do
        local row = CreateFrame("Frame", nil, scrollChild)
        row:SetSize(260, 25)
        row:SetPoint("TOPLEFT", 10, yOffset)

        local itemName, itemLink, itemRarity, _, _, _, _, _, _, itemIcon = GetItemInfo(itemID)
        
        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", 0, 0)
        icon:SetTexture(itemIcon or "Interface\\Icons\\INV_Misc_QuestionMark")

        local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameText:SetPoint("LEFT", icon, "RIGHT", 8, 0)
        nameText:SetText(itemLink or ("未知物品 (ID: " .. itemID .. ")"))

        local removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        removeBtn:SetSize(50, 20)
        removeBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        removeBtn:SetText("移除")
        removeBtn:SetScript("OnClick", function()
            EpicLootTrackerConfig.blacklist[itemID] = nil
            print("|cff00ff00[EpicLootTracker]|r 已将 " .. (itemLink or itemID) .. " 移出黑名单。")
            UpdateBlacklistScroll(scrollChild)
        end)
        yOffset = yOffset - 28
    end
    scrollChild:SetHeight(math.abs(yOffset) + 10)
end

local function CreateBlacklistManagerUI()
    if BlacklistFrame then 
        BlacklistFrame:SetShown(not BlacklistFrame:IsShown())
        return 
    end

    if not EpicLootTrackerConfig.blacklist then EpicLootTrackerConfig.blacklist = {} end

    BlacklistFrame = CreateFrame("Frame", "EpicLootTrackerBlacklistUI", UIParent, "BasicFrameTemplateWithInset")
    BlacklistFrame:SetSize(320, 400)
    BlacklistFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    BlacklistFrame:SetMovable(true)
    BlacklistFrame:EnableMouse(true)
    BlacklistFrame:RegisterForDrag("LeftButton")
    BlacklistFrame:SetScript("OnDragStart", BlacklistFrame.StartMoving)
    BlacklistFrame:SetScript("OnDragStop", BlacklistFrame.StopMovingOrSizing)
    BlacklistFrame:SetFrameStrata("DIALOG") 

    BlacklistFrame.title = BlacklistFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    BlacklistFrame.title:SetPoint("TOPLEFT", BlacklistFrame.TitleBg, "TOPLEFT", 5, -3)
    BlacklistFrame.title:SetText("黑名单物品管理 (无视掉落)")

    local inputBox = CreateFrame("EditBox", nil, BlacklistFrame, "InputBoxTemplate")
    inputBox:SetSize(150, 20)
    inputBox:SetPoint("TOPLEFT", BlacklistFrame, "TOPLEFT", 20, -35)
    inputBox:SetAutoFocus(false)
    inputBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    local scrollFrame = CreateFrame("ScrollFrame", nil, BlacklistFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 10, -65)
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10)

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(280, 100)
    scrollFrame:SetScrollChild(scrollChild)

    local addBtn = CreateFrame("Button", nil, BlacklistFrame, "UIPanelButtonTemplate")
    addBtn:SetSize(60, 22)
    addBtn:SetPoint("LEFT", inputBox, "RIGHT", 10, 0)
    addBtn:SetText("添加")
    addBtn:SetScript("OnClick", function()
        local text = inputBox:GetText()
        if not text or text == "" then return end
        
        local itemID = tonumber(string.match(text, "item:(%d+)") or text)
        if itemID then
            C_Item.RequestLoadItemDataByID(itemID) 
            EpicLootTrackerConfig.blacklist[itemID] = true
            inputBox:SetText("")
            inputBox:ClearFocus()
            
            C_Timer.After(0.2, function()
                local _, link = GetItemInfo(itemID)
                print("|cff00ff00[EpicLootTracker]|r 已将 " .. (link or itemID) .. " 加入黑名单。")
                UpdateBlacklistScroll(scrollChild)
            end)
        else
            print("|cffff0000[EpicLootTracker]|r 错误：请输入正确的物品 ID 或物品链接！")
        end
    end)

    BlacklistFrame:SetScript("OnShow", function()
        UpdateBlacklistScroll(scrollChild)
    end)
end

-- ==========================================
-- 2. UI 界面构建
-- ==========================================
mainFrame = CreateFrame("Frame", "EpicLootTrackerFrame", UIParent, "BasicFrameTemplateWithInset")
mainFrame:SetSize(980, 520)
mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
mainFrame:Hide()
mainFrame:SetMovable(true)
mainFrame:EnableMouse(true)
mainFrame:RegisterForDrag("LeftButton")
mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing)

mainFrame.title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.title:SetPoint("CENTER", mainFrame.TitleBg, "CENTER", 0, 0)
mainFrame.title:SetText("高级战利品拾取记录")

mainFrame.filteredData = {}
mainFrame.currentTimeFilter = "ALL"

-- --- 顶部控制栏区 ---
-- 1. 搜索框
mainFrame.searchBox = CreateFrame("EditBox", nil, mainFrame, "InputBoxTemplate")
mainFrame.searchBox:SetSize(160, 22)
mainFrame.searchBox:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 25, -35)
mainFrame.searchBox:SetAutoFocus(false)
mainFrame.searchBox.label = mainFrame.searchBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
mainFrame.searchBox.label:SetPoint("BOTTOMLEFT", mainFrame.searchBox, "TOPLEFT", -5, 2)
mainFrame.searchBox.label:SetText("模糊搜索 (物品/地点/角色):")
mainFrame.searchBox:SetScript("OnTextChanged", function(self)
    EpicLootTracker_BuildData()
    EpicLootTracker_UpdateUI()
end)

-- ================= 白名单管理按钮与侧边面板 =================
mainFrame.whitelistBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
mainFrame.whitelistBtn:SetSize(90, 22)
mainFrame.whitelistBtn:SetPoint("LEFT", mainFrame.searchBox, "RIGHT", 15, 0)
mainFrame.whitelistBtn:SetText("白名单管理")

-- 黑名单管理按钮
mainFrame.blacklistBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
mainFrame.blacklistBtn:SetSize(90, 22)
mainFrame.blacklistBtn:SetPoint("LEFT", mainFrame.whitelistBtn, "RIGHT", 10, 0)
mainFrame.blacklistBtn:SetText("黑名单管理")
mainFrame.blacklistBtn:SetScript("OnClick", function()
    CreateBlacklistManagerUI()
end)

-- 白名单面板 
mainFrame.wlPanel = CreateFrame("Frame", nil, mainFrame, "BasicFrameTemplateWithInset")
mainFrame.wlPanel:SetSize(280, 480)
mainFrame.wlPanel:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 5, 0) 
mainFrame.wlPanel:Hide()
mainFrame.wlPanel.title = mainFrame.wlPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.wlPanel.title:SetPoint("CENTER", mainFrame.wlPanel.TitleBg, "CENTER", 0, 0)
mainFrame.wlPanel.title:SetText("蓝装白名单")

mainFrame.whitelistBtn:SetScript("OnClick", function()
    if mainFrame.wlPanel:IsShown() then
        mainFrame.wlPanel:Hide()
    else
        mainFrame.wlPanel:Show()
        EpicLootTracker_UpdateWhitelistUI()
    end
end)

local wlAddBtn = CreateFrame("Button", nil, mainFrame.wlPanel, "UIPanelButtonTemplate")
wlAddBtn:SetSize(120, 24)
wlAddBtn:SetPoint("TOP", mainFrame.wlPanel, "TOP", 0, -35)
wlAddBtn:SetText("添加新物品")
wlAddBtn:SetScript("OnClick", function()
    StaticPopup_Show("EPIC_LOOT_TRACKER_ADD_WHITELIST")
end)

local wlScroll = CreateFrame("ScrollFrame", "EpicLootTrackerWLScroll", mainFrame.wlPanel, "FauxScrollFrameTemplate")
wlScroll:SetPoint("TOPLEFT", mainFrame.wlPanel, "TOPLEFT", 10, -70)
wlScroll:SetPoint("BOTTOMRIGHT", mainFrame.wlPanel, "BOTTOMRIGHT", -30, 10)

mainFrame.wlPanel.rows = {}
local WL_ROW_COUNT = 18
for i = 1, WL_ROW_COUNT do
    local row = CreateFrame("Frame", nil, mainFrame.wlPanel)
    row:SetSize(230, 22)
    if i == 1 then row:SetPoint("TOPLEFT", wlScroll, "TOPLEFT", 0, 0)
    else row:SetPoint("TOPLEFT", mainFrame.wlPanel.rows[i-1], "BOTTOMLEFT", 0, -2) end

    row.itemFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.itemFS:SetPoint("LEFT", row, "LEFT", 5, 0)
    row.itemFS:SetWidth(170)
    row.itemFS:SetJustifyH("LEFT")
    row.itemFS:SetWordWrap(false)
    
    row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.delBtn:SetSize(45, 20)
    row.delBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
    row.delBtn:SetText("移除")
    row.delBtn:SetScript("OnClick", function()
        if row.itemID and EpicLootTrackerConfig.whitelist then
            EpicLootTrackerConfig.whitelist[row.itemID] = nil
            EpicLootTracker_UpdateWhitelistUI()
        end
    end)
    
    row:EnableMouse(true)
    row:SetScript("OnEnter", function(self)
        if row.itemID then
            local _, link = GetItemInfo(row.itemID)
            if link then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetHyperlink(link)
                GameTooltip:Show()
            end
        end
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    mainFrame.wlPanel.rows[i] = row
end

function EpicLootTracker_UpdateWhitelistUI()
    if not mainFrame.wlPanel:IsShown() then return end
    
    local wlData = {}
    if EpicLootTrackerConfig and EpicLootTrackerConfig.whitelist then
        for id, _ in pairs(EpicLootTrackerConfig.whitelist) do
            table.insert(wlData, id)
        end
    end
    
    FauxScrollFrame_Update(wlScroll, #wlData, WL_ROW_COUNT, 22)
    local offset = FauxScrollFrame_GetOffset(wlScroll)
    
    for i = 1, WL_ROW_COUNT do
        local idx = offset + i
        local row = mainFrame.wlPanel.rows[i]
        if idx <= #wlData then
            local itemID = wlData[idx]
            row.itemID = itemID
            local _, itemLink = GetItemInfo(itemID)
            if itemLink then
                row.itemFS:SetText(itemLink)
            else
                row.itemFS:SetText("物品ID: " .. itemID)
            end
            row:Show()
        else
            row.itemID = nil
            row:Hide()
        end
    end
end

wlScroll:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, 22, EpicLootTracker_UpdateWhitelistUI)
end)

-- 2. 是否记录蓝装开关
mainFrame.chkRecordBlue = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkRecordBlue:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -140, -35)
mainFrame.chkRecordBlue.text = mainFrame.chkRecordBlue:CreateFontString(nil, "OVERLAY", "GameFontNormal")
mainFrame.chkRecordBlue.text:SetPoint("LEFT", mainFrame.chkRecordBlue, "RIGHT", 2, 1)
mainFrame.chkRecordBlue.text:SetText("记录精良(蓝装)")
mainFrame.chkRecordBlue:SetScript("OnClick", function(self)
    EpicLootTrackerConfig.recordBlue = self:GetChecked()
end)

-- 3. 是否记录单人拾取开关
mainFrame.chkRecordSolo = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkRecordSolo:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -290, -35)
mainFrame.chkRecordSolo.text = mainFrame.chkRecordSolo:CreateFontString(nil, "OVERLAY", "GameFontNormal")
mainFrame.chkRecordSolo.text:SetPoint("LEFT", mainFrame.chkRecordSolo, "RIGHT", 2, 1)
mainFrame.chkRecordSolo.text:SetText("记录单人拾取")
mainFrame.chkRecordSolo:SetScript("OnClick", function(self)
    EpicLootTrackerConfig.recordSolo = self:GetChecked()
end)

-- 4. 显示品质与类型过滤
mainFrame.chkShowPurple = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowPurple:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -70)
mainFrame.chkShowPurple:SetChecked(true)
mainFrame.chkShowPurple.text = mainFrame.chkShowPurple:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowPurple.text:SetPoint("LEFT", mainFrame.chkShowPurple, "RIGHT", 2, 1)
mainFrame.chkShowPurple.text:SetText("紫装")
mainFrame.chkShowPurple:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

mainFrame.chkShowBlue = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowBlue:SetPoint("LEFT", mainFrame.chkShowPurple.text, "RIGHT", 10, -1)
mainFrame.chkShowBlue:SetChecked(true)
mainFrame.chkShowBlue.text = mainFrame.chkShowBlue:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowBlue.text:SetPoint("LEFT", mainFrame.chkShowBlue, "RIGHT", 2, 1)
mainFrame.chkShowBlue.text:SetText("蓝装")
mainFrame.chkShowBlue:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

mainFrame.chkShowEquip = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowEquip:SetPoint("LEFT", mainFrame.chkShowBlue.text, "RIGHT", 15, 0)
mainFrame.chkShowEquip:SetChecked(true)
mainFrame.chkShowEquip.text = mainFrame.chkShowEquip:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowEquip.text:SetPoint("LEFT", mainFrame.chkShowEquip, "RIGHT", 2, 1)
mainFrame.chkShowEquip.text:SetText("装备")
mainFrame.chkShowEquip:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

mainFrame.chkShowRecipe = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowRecipe:SetPoint("LEFT", mainFrame.chkShowEquip.text, "RIGHT", 10, 0)
mainFrame.chkShowRecipe:SetChecked(true)
mainFrame.chkShowRecipe.text = mainFrame.chkShowRecipe:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowRecipe.text:SetPoint("LEFT", mainFrame.chkShowRecipe, "RIGHT", 2, 1)
mainFrame.chkShowRecipe.text:SetText("图纸")
mainFrame.chkShowRecipe:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

-- 杂项过滤开关
mainFrame.chkShowMisc = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
mainFrame.chkShowMisc:SetPoint("LEFT", mainFrame.chkShowRecipe.text, "RIGHT", 10, 0)
mainFrame.chkShowMisc:SetChecked(true)
mainFrame.chkShowMisc.text = mainFrame.chkShowMisc:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
mainFrame.chkShowMisc.text:SetPoint("LEFT", mainFrame.chkShowMisc, "RIGHT", 2, 1)
mainFrame.chkShowMisc.text:SetText("杂项")
mainFrame.chkShowMisc:SetScript("OnClick", function() EpicLootTracker_BuildData(); EpicLootTracker_UpdateUI() end)

-- 5. 快捷日期过滤按钮
local timeFilters = {
    { key = "ALL", label = "全部" },
    { key = "TODAY", label = "今天" },
    { key = "3DAYS", label = "近3天" },
    { key = "1WEEK", label = "一周" },
    { key = "HALFMONTH", label = "半个月" },
    { key = "1MONTH", label = "一个月" }
}
local filterBtns = {}
for i, filter in ipairs(timeFilters) do
    local btn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
    btn:SetSize(65, 22)
    if i == 1 then
        btn:SetPoint("LEFT", mainFrame.chkShowMisc.text, "RIGHT", 15, 0)
    else
        btn:SetPoint("LEFT", filterBtns[i-1], "RIGHT", 5, 0)
    end
    btn:SetText(filter.label)
    btn:SetScript("OnClick", function()
        mainFrame.currentTimeFilter = filter.key
        for _, b in ipairs(filterBtns) do b:Enable() end
        btn:Disable()
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end)
    filterBtns[i] = btn
end
filterBtns[1]:Disable()

-- --- 表头排版定义（已扩充地点与角色-服务器宽度，并将删除按钮移至右侧边缘） ---
local headers = {
    { title = "物品名", width = 140, xOffset = 50, align = "LEFT" },
    { title = "装等", width = 40, xOffset = 172, align = "CENTER" },
    { title = "需求", width = 40, xOffset = 217, align = "CENTER" },
    { title = "插槽", width = 55, xOffset = 262, align = "CENTER" },
    { title = "三属性", width = 65, xOffset = 323, align = "CENTER" },
    { title = "时间", width = 135, xOffset = 425, align = "LEFT" },
    { title = "地点", width = 145, xOffset = 535, align = "LEFT" },
    { title = "角色-服务器", width = 205, xOffset = 683, align = "LEFT" },
    { title = "操作", width = 45, xOffset = 890, align = "CENTER" },
}

for _, h in ipairs(headers) do
    local font = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    font:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", h.xOffset, -105)
    font:SetWidth(h.width)
    font:SetJustifyH(h.align or "LEFT")
    font:SetText(h.title)
end

-- 滚动列表
local scrollFrame = CreateFrame("ScrollFrame", "EpicLootTrackerScroll", mainFrame, "FauxScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 15, -125)
scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -35, 45)

local ROW_COUNT = 14
mainFrame.rows = {}
for i = 1, ROW_COUNT do
    local row = CreateFrame("Frame", nil, mainFrame)
    row:SetSize(930, 24)
    if i == 1 then row:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0)
    else row:SetPoint("TOPLEFT", mainFrame.rows[i-1], "BOTTOMLEFT", 0, -1) end

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.03 or 0.08)

    row.itemText = CreateFrame("Frame", nil, row)
    row.itemText:SetSize(140, 20)
    row.itemText:SetPoint("LEFT", row, "LEFT", 20, 0)
    row.itemFS = row.itemText:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.itemFS:SetAllPoints()
    row.itemFS:SetJustifyH("LEFT")
    row.itemFS:SetWordWrap(false)

    row.itemText:EnableMouse(true)
    row.itemText:SetScript("OnEnter", function(self)
        if row.itemLink then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetHyperlink(row.itemLink)
            GameTooltip:Show()
        end
    end)
    row.itemText:SetScript("OnLeave", function() GameTooltip:Hide() end)
    row.itemText:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" and IsShiftKeyDown() and row.itemLink then
            ChatEdit_InsertLink(row.itemLink)
        end
    end)

    row.ilvlText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.ilvlText:SetPoint("LEFT", row, "LEFT", 162, 0)
    row.ilvlText:SetWidth(40)
    row.ilvlText:SetJustifyH("CENTER")

    row.reqLevelText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.reqLevelText:SetPoint("LEFT", row, "LEFT", 205, 0)
    row.reqLevelText:SetWidth(40)
    row.reqLevelText:SetJustifyH("CENTER")

    -- 插槽显示（●符号）
    row.socketText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.socketText:SetPoint("LEFT", row, "LEFT", 248, 0)
    row.socketText:SetWidth(55)
    row.socketText:SetJustifyH("CENTER")

    -- 第三属性显示
    row.tertiaryText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.tertiaryText:SetPoint("LEFT", row, "LEFT", 308, 0)
    row.tertiaryText:SetWidth(65)
    row.tertiaryText:SetJustifyH("CENTER")

    -- 时间显示（单行不换行）
    row.timeText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.timeText:SetPoint("LEFT", row, "LEFT", 378, 0)
    row.timeText:SetWidth(135)
    row.timeText:SetJustifyH("LEFT")
    row.timeText:SetWordWrap(false)

    -- 地点显示（加宽防截断）
    row.locationText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.locationText:SetPoint("LEFT", row, "LEFT", 518, 0)
    row.locationText:SetWidth(145)
    row.locationText:SetJustifyH("LEFT")
    row.locationText:SetWordWrap(false)

    -- 角色-服务器显示（向后移并加宽防截断）
    row.playerText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.playerText:SetPoint("LEFT", row, "LEFT", 668, 0)
    row.playerText:SetWidth(205) 
    row.playerText:SetJustifyH("LEFT")
    row.playerText:SetWordWrap(false)

    -- 删除按钮（靠右侧边缘）
    row.delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.delBtn:SetSize(45, 20)
    row.delBtn:SetPoint("LEFT", row, "LEFT", 880, 0)
    row.delBtn:SetText("删除")
    row.delBtn:SetScript("OnClick", function()
        if row.dbIndex then
            local dialog = StaticPopup_Show("EPIC_LOOT_TRACKER_CONFIRM_DELETE", row.itemNameOnly or "该物品")
            if dialog then dialog.data = { dbIndex = row.dbIndex } end
        end
    end)

    mainFrame.rows[i] = row
end

local clearAllBtn = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
clearAllBtn:SetSize(110, 24)
clearAllBtn:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -20, 12)
clearAllBtn:SetText("清空当前列表")
clearAllBtn:SetScript("OnClick", function()
    if #mainFrame.filteredData > 0 then
        StaticPopup_Show("EPIC_LOOT_TRACKER_CONFIRM_CLEAR")
    end
end)

-- ==========================================
-- 3. 数据过滤与排序引擎
-- ==========================================
function EpicLootTracker_BuildData()
    table.sort(EpicLootTrackerDB, function(a, b)
        return (a.timestamp or 0) > (b.timestamp or 0)
    end)

    table.wipe(mainFrame.filteredData)
    local searchText = mainFrame.searchBox:GetText():lower()
    local currentTimestamp = time()
    
    local t_date = date("*t")
    local todayMidnight = time({year=t_date.year, month=t_date.month, day=t_date.day, hour=0, min=0, sec=0})
    
    local showPurple = mainFrame.chkShowPurple:GetChecked()
    local showBlue = mainFrame.chkShowBlue:GetChecked()
    local showEquip = mainFrame.chkShowEquip:GetChecked()
    local showRecipe = mainFrame.chkShowRecipe:GetChecked()
    local showMisc = mainFrame.chkShowMisc:GetChecked()

    for i, data in ipairs(EpicLootTrackerDB) do
        local match = true
        
        -- 1. 品质过滤
        local rarity = data.rarity or 4
        if not ((showPurple and rarity >= 4) or (showBlue and rarity == 3)) then
            match = false
        end

        -- 2. 装备、图纸与杂项分类精准过滤
        if match then
            local isRecipe = false
            local isEquip = false
            local isMisc = false
            
            local _, _, _, _, _, _, _, _, itemEquipLoc, _, _, classID = GetItemInfo(data.itemLink)
            
            if classID then
                if classID == 9 then 
                    isRecipe = true 
                elseif classID == 2 or classID == 4 or (itemEquipLoc and itemEquipLoc ~= "") then
                    isEquip = true
                else
                    isMisc = true 
                end
            else
                local itemName = string.match(data.itemLink or "", "%[(.-)%]") or ""
                if string.find(itemName, "设计图：") or string.find(itemName, "图样：") or 
                   string.find(itemName, "公式：") or string.find(itemName, "结构图：") or 
                   string.find(itemName, "指南：") or string.find(itemName, "图纸：") then
                    isRecipe = true
                else
                    isEquip = true 
                end
            end
            
            if isMisc and not showMisc then
                match = false 
            elseif isRecipe and not showRecipe then
                match = false
            elseif isEquip and not showEquip then
                match = false
            end
        end

        -- 3. 搜索过滤
        if match and searchText ~= "" then
            local searchStr = string.lower((data.itemLink or "") .. (data.location or "") .. (data.player or "") .. (data.recorder or ""))
            if not string.find(searchStr, searchText, 1, true) then
                match = false
            end
        end

        -- 4. 时间过滤
        if match and mainFrame.currentTimeFilter ~= "ALL" then
            local recTime = data.timestamp or 0 
            if recTime > 0 then
                local diff = currentTimestamp - recTime
                local filter = mainFrame.currentTimeFilter
                if filter == "TODAY" and recTime < todayMidnight then match = false
                elseif filter == "3DAYS" and diff > 3*24*3600 then match = false
                elseif filter == "1WEEK" and diff > 7*24*3600 then match = false
                elseif filter == "HALFMONTH" and diff > 15*24*3600 then match = false
                elseif filter == "1MONTH" and diff > 30*24*3600 then match = false
                end
            else
                match = false 
            end
        end

        if match then
            table.insert(mainFrame.filteredData, { dbIndex = i, record = data })
        end
    end
end

function EpicLootTracker_UpdateUI()
    if not mainFrame:IsShown() then return end
    local totalItems = #mainFrame.filteredData
    FauxScrollFrame_Update(scrollFrame, totalItems, ROW_COUNT, 24)

    local offset = FauxScrollFrame_GetOffset(scrollFrame)
    for i = 1, ROW_COUNT do
        local idx = offset + i
        local row = mainFrame.rows[i]

        if idx <= totalItems then
            local dbWrapper = mainFrame.filteredData[idx]
            local data = dbWrapper.record
            row.dbIndex = dbWrapper.dbIndex
            row.itemLink = data.itemLink
            row.itemNameOnly = string.match(data.itemLink, "%[(.-)%]") or "未知装备"

            row.itemFS:SetText(data.itemLink)
            
            local _, _, _, itemLevel, itemMinLevel = GetItemInfo(data.itemLink)
            
            local displayIlvl = itemLevel or data.itemLevel or 0
            local displayReqLvl = itemMinLevel or data.reqLevel or 0
            
            if displayIlvl > 1 then row.ilvlText:SetText(displayIlvl) else row.ilvlText:SetText("-") end
            if displayReqLvl > 1 then row.reqLevelText:SetText(displayReqLvl) else row.reqLevelText:SetText("-") end
            
            -- 更新插槽（●表示）与第三属性
            local socketStr, tertiaryStr = GetItemExtraDetails(data.itemLink)
            row.socketText:SetText(socketStr)
            row.tertiaryText:SetText(tertiaryStr)

            row.timeText:SetText(data.time)
            row.locationText:SetText(data.location)
            
            local classColor = "ffffffff"
            if data.className and RAID_CLASS_COLORS[data.className] then
                classColor = RAID_CLASS_COLORS[data.className].colorStr
            end
            row.playerText:SetText(string.format("|c%s%s|r", classColor, data.player))

            row:Show()
        else
            row.dbIndex = nil
            row:Hide()
        end
    end
end

scrollFrame:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, 24, EpicLootTracker_UpdateUI)
end)

-- ==========================================
-- 4. 事件监听
-- ==========================================
local eventHandler = CreateFrame("Frame")
eventHandler:RegisterEvent("ADDON_LOADED")
eventHandler:RegisterEvent("ENCOUNTER_LOOT_RECEIVED")
eventHandler:RegisterEvent("CHAT_MSG_LOOT")

local function FormatPlayerName(rawName)
    if not rawName or rawName == "" then return UnitName("player") .. "-" .. GetRealmName() end
    if not string.find(rawName, "-") then return rawName .. "-" .. GetRealmName() end
    return rawName
end

local function RecordLoot(itemLink, playerName, className)
    if not itemLink then return end
    
    local _, _, itemRarity, itemLevel, itemMinLevel, _, _, _, itemEquipLoc, _, _, classID = GetItemInfo(itemLink)
    if not itemRarity or itemRarity < 3 then return end
    
    local itemID = tonumber(string.match(itemLink, "item:(%d+)"))
    
    -- 1. UI 黑名单拦截
    if not EpicLootTrackerConfig.blacklist then EpicLootTrackerConfig.blacklist = {} end
    if itemID and EpicLootTrackerConfig.blacklist[itemID] then return end 

    -- 2. 动态UI白名单拦截逻辑
    if itemRarity == 3 and not EpicLootTrackerConfig.recordBlue then 
        if not (itemID and EpicLootTrackerConfig.whitelist and EpicLootTrackerConfig.whitelist[itemID]) then
            return 
        end
    end

    local record = {
        itemLink = itemLink,
        rarity = itemRarity,
        itemLevel = itemLevel or 0, 
        reqLevel = itemMinLevel or 0, 
        timestamp = time(),
        time = date("%Y-%m-%d %H:%M:%S"),
        location = GetRealZoneText() or "未知区域",
        player = FormatPlayerName(playerName),
        className = className,
        recorder = UnitName("player")
    }

    table.insert(EpicLootTrackerDB, 1, record)
    if mainFrame:IsShown() then 
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI() 
    end
end

eventHandler:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local addon = ...
        if addon == addonName then
            EpicLootTrackerDB = EpicLootTrackerDB or {}
            
            local currentYear = tonumber(date("%Y"))
            for _, data in ipairs(EpicLootTrackerDB) do
                if not data.rarity then data.rarity = 4 end
                if not data.timestamp then
                    if data.time then
                        local mo, d, h, m, s = string.match(data.time, "^(%d%d)%-(%d%d) (%d%d):(%d%d):(%d%d)$")
                        if mo then
                            data.timestamp = time({year=currentYear, month=tonumber(mo), day=tonumber(d), hour=tonumber(h), min=tonumber(m), sec=tonumber(s)})
                            data.time = string.format("%04d-%02d-%02d %02d:%02d:%02d", currentYear, tonumber(mo), tonumber(d), tonumber(h), tonumber(m), tonumber(s))
                        else
                            data.timestamp = time()
                        end
                    else
                        data.timestamp = time()
                        data.time = date("%Y-%m-%d %H:%M:%S", data.timestamp)
                    end
                end
            end
            
            EpicLootTrackerConfig = EpicLootTrackerConfig or {}
            if EpicLootTrackerConfig.recordBlue == nil then EpicLootTrackerConfig.recordBlue = false end
            if EpicLootTrackerConfig.recordSolo == nil then EpicLootTrackerConfig.recordSolo = false end
            
            if not EpicLootTrackerConfig.blacklist then EpicLootTrackerConfig.blacklist = {} end
         
            if not EpicLootTrackerConfig.whitelist then
                EpicLootTrackerConfig.whitelist = {
                    [9425] = true,
                    [9423] = true,
                    [9431] = true,
                    [9429] = true,
                }
            end
            
            mainFrame.chkRecordBlue:SetChecked(EpicLootTrackerConfig.recordBlue)
            mainFrame.chkRecordSolo:SetChecked(EpicLootTrackerConfig.recordSolo)
        end

    elseif event == "ENCOUNTER_LOOT_RECEIVED" then
        if not IsInGroup() and not EpicLootTrackerConfig.recordSolo then return end
        local encounterID, itemID, itemLink, quantity,playerName, className = ...
        RecordLoot(itemLink, playerName, className)

    elseif event == "CHAT_MSG_LOOT" then
        if not IsInGroup() and not EpicLootTrackerConfig.recordSolo then return end
        local text, rawPlayer = ...
        local itemLink = string.match(text, "(|c%x+|Hitem:.-|h%[.-%] |h|r)")
        if itemLink then
            if string.find(itemLink:lower(), "|cff0070dd") or string.find(itemLink:lower(), "|cffa335ee") then
                RecordLoot(itemLink, rawPlayer, nil)
            end
        end
    end
end)

-- ==========================================
-- 5. Slash 指令绑定
-- ==========================================
SLASH_EPICLOOTTRACKER1 = "/elt"
SLASH_EPICLOOTTRACKER2 = "/epicloot"
SlashCmdList["EPICLOOTTRACKER"] = function()
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        mainFrame:Show()
        EpicLootTracker_BuildData()
        EpicLootTracker_UpdateUI()
    end
end