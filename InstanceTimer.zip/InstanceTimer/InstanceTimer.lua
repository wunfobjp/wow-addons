local ADDON_NAME, AddOn = ...

-- ==================== 1. 默认配置与数据库 ====================

local defaultDB = {
    mode = 1,             -- 1 = 进入副本开始计时 | 2 = 首次进入战斗开始计时
    announce = true,      -- 是否开启组队频道通报
    pos = { point = "CENTER", x = 0, y = 200 },
    maxRecords = 10,      -- 默认最大保存条数
    history = {},         -- 历史记录列表
    runCount = 0,         -- 副本完成次数统计
    counterActive = true, -- 次数统计开启状态
    showPartyFrame = true,-- 是否默认展开队伍面板
    isAnonymous = false   -- 匿名模式记忆
}

-- 已知副本尾王映射
local KNOWN_FINAL_BOSSES = {
    ["青龙寺"] = "疑之煞",
    ["Temple of the Jade Serpent"] = "Sha of Doubt",
    ["残阳关"] = "瑞亚克斯将军",
    ["影踪禅院"] = "祝踏岚",
    ["风暴烈酒酿造厂"] = "炎干",
    ["魔古山宫殿"] = "王之溟",
    ["围攻砮燥寺"] = "翼将席卡尔",
    ["通灵学院"] = "黑暗院长加丁",
    ["血色大厅"] = "织焰者赫洛阿斯",
    ["血色修道院"] = "大检察官怀特迈恩",
    ["巨龙之魂"] = "疯狂的死亡之翼",
}

-- 运行时状态变量
local startTime = 0
local accumulatedTime = 0
local isTiming = false
local isPaused = false
local inInstance = false
local lastAnnounceTime = 0
local pendingStartOnLoadEnd = false 

-- 声明前置函数引用
local UpdateHistoryUI
local UpdateCounterDisplay
local OpenContextMenu
local TogglePartyFrame

-- ==================== 2. 主计时器 UI (timerFrame) ====================

local timerFrame = CreateFrame("Frame", "InstanceTimerFrame", UIParent, "BackdropTemplate")
timerFrame:SetSize(280, 50)
timerFrame:SetPoint("CENTER", 0, 200)
timerFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 10,
    insets = { left = 2, right = 2, top = 2, bottom = 2 }
})
timerFrame:SetBackdropColor(0, 0, 0, 0.4)
timerFrame:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.6)

-- 拖动逻辑
local function OnDragStart(self)
    if IsAltKeyDown() or not inInstance then
        timerFrame:StartMoving()
        timerFrame.isDragging = true
    end
end

local function OnDragStop(self)
    timerFrame:StopMovingOrSizing()
    timerFrame.isDragging = false
    local point, _, _, x, y = timerFrame:GetPoint()
    InstanceTimerDB.pos = { point = point, x = x, y = y }
end

timerFrame:SetMovable(true)
timerFrame:SetClampedToScreen(true) -- 限制框体不能移出屏幕边缘

-- ---------- 左侧：计时器交互区 ----------
local timerBtn = CreateFrame("Button", nil, timerFrame)
timerBtn:SetPoint("TOPLEFT", timerFrame, "TOPLEFT", 2, -2)
timerBtn:SetPoint("BOTTOMRIGHT", timerFrame, "BOTTOMLEFT", 155, 2)
timerBtn:EnableMouse(true)
timerBtn:RegisterForDrag("LeftButton")
timerBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
timerBtn:SetScript("OnDragStart", OnDragStart)
timerBtn:SetScript("OnDragStop", OnDragStop)

local timerText = timerBtn:CreateFontString(nil, "OVERLAY")
timerText:SetFont(STANDARD_TEXT_FONT, 24, "OUTLINE")
timerText:SetPoint("CENTER", timerBtn, "CENTER", 0, 0)
timerText:SetTextColor(0, 1, 0.5, 1)
timerText:SetText("00:00:00")

-- 分割线
local sepLine = timerFrame:CreateTexture(nil, "OVERLAY")
sepLine:SetSize(1, 26)
sepLine:SetPoint("LEFT", timerFrame, "LEFT", 155, 0)
sepLine:SetColorTexture(0.5, 0.5, 0.5, 0.5)

-- ---------- 右侧：次数统计交互区 ----------
local countBtn = CreateFrame("Button", nil, timerFrame)
countBtn:SetPoint("TOPLEFT", timerFrame, "TOPLEFT", 156, -2)
countBtn:SetPoint("BOTTOMRIGHT", timerFrame, "BOTTOMRIGHT", -24, 2)
countBtn:EnableMouse(true)
countBtn:RegisterForDrag("LeftButton")
countBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
countBtn:SetScript("OnDragStart", OnDragStart)
countBtn:SetScript("OnDragStop", OnDragStop)

local countText = countBtn:CreateFontString(nil, "OVERLAY")
countText:SetFont(STANDARD_TEXT_FONT, 20, "OUTLINE")
countText:SetPoint("CENTER", countBtn, "CENTER", 0, 0)
countText:SetText("|cffffd1000|r次")

-- ---------- 队伍面板展开/收缩 切换按钮 ----------
local togglePartyBtn = CreateFrame("Button", nil, timerFrame)
togglePartyBtn:SetSize(20, 20)
togglePartyBtn:SetPoint("RIGHT", timerFrame, "RIGHT", -3, 0)

local togglePartyText = togglePartyBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
togglePartyText:SetPoint("CENTER", 0, 0)
togglePartyText:SetText("▼")

togglePartyBtn:SetScript("OnClick", function()
    TogglePartyFrame()
end)
togglePartyBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText("点击 展开/收起 队伍信息面板")
    GameTooltip:Show()
end)
togglePartyBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

-- 更新次数显示
UpdateCounterDisplay = function()
    local count = (InstanceTimerDB and InstanceTimerDB.runCount) or 0
    local active = InstanceTimerDB and InstanceTimerDB.counterActive
    if active then
        countText:SetText(string.format("|cffffd100%d|r次", count))
    else
        countText:SetText(string.format("|cff808080%d(暂停)|r", count))
    end
end

-- 格式化时间
local function FormatTime(seconds)
    local hours = math.floor(seconds / 3600)
    local mins = math.floor((seconds % 3600) / 60)
    local secs = math.floor(seconds % 60)
    return string.format("%02d:%02d:%02d", hours, mins, secs)
end

-- 实时刷新计时
timerFrame:SetScript("OnUpdate", function(self, elapsed)
    if isTiming and not isPaused then
        local currentElapsed = (GetTime() - startTime) + accumulatedTime
        timerText:SetText(FormatTime(currentElapsed))
    end
end)

-- ==================== 3. 队伍信息面板（下挂于计时器底部） ====================

local PartyFrame = CreateFrame("Frame", "PartyHelperMainFrame", timerFrame, "BackdropTemplate")
PartyFrame:SetSize(280, 185)
PartyFrame:SetPoint("TOPLEFT", timerFrame, "BOTTOMLEFT", 0, -2) -- 紧贴计时器下方

PartyFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
PartyFrame:SetBackdropColor(0.05, 0.05, 0.08, 0.92)
PartyFrame:SetBackdropBorderColor(0.2, 0.2, 0.25, 0.8)

-- 标题与关闭按钮
local title = PartyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightMedium")
title:SetPoint("TOP", 0, -8)
title:SetText("队伍信息")

local closeBtn = CreateFrame("Button", nil, PartyFrame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -2, -2)
closeBtn:SetScript("OnClick", function()
    TogglePartyFrame(false)
end)

-- 队伍列表行
local memberRows = {}

local function GetUnitNameFormatted(unit)
    if not UnitExists(unit) then return nil end
    local name, realm = UnitName(unit)
    if not name or name == "" then return nil end
    if not realm or realm == "" then realm = GetRealmName() end
    return name .. "-" .. realm, name
end

for i = 1, 5 do
    local row = CreateFrame("Frame", nil, PartyFrame)
    row:SetSize(250, 22)
    row:SetPoint("TOPLEFT", 15, -30 - (i - 1) * 24)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("LEFT", 0, 0)
    row.nameText:SetWidth(130)
    row.nameText:SetJustifyH("LEFT")

    row.levelText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.levelText:SetPoint("LEFT", 135, 0)
    row.levelText:SetWidth(55)
    row.levelText:SetJustifyH("RIGHT")

    row.removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.removeBtn:SetSize(46, 20)
    row.removeBtn:SetPoint("RIGHT", 0, 0)
    row.removeBtn:SetText("移除")

    memberRows[i] = row
end

-- 宏创建与放置逻辑
local function CreateAndPlaceMacro(macroName, icon, macroBody, targetSlot)
    if InCombatLockdown() then
        print("|cFFFF0000[队伍助手]|r 战斗中无法修改宏或动作条！")
        return
    end

    local macroIcon = icon or 134400
    local numAccount, numCharacter = GetNumMacros()
    local index = GetMacroIndexByName(macroName)

    if index > 0 then
        EditMacro(index, macroName, macroIcon, macroBody)
    else
        if numCharacter < 18 then
            index = CreateMacro(macroName, macroIcon, macroBody, true)
        elseif numAccount < 120 then
            index = CreateMacro(macroName, macroIcon, macroBody, false)
            print(string.format("|cFFFF9900[队伍助手]|r 角色宏已满，自动创建为通用宏【%s】", macroName))
        else
            print(string.format("|cFFFF0000[队伍助手]|r 创建宏【%s】失败！栏位已满。", macroName))
            return
        end
    end

    if not index or index == 0 then
        print(string.format("|cFFFF0000[队伍助手]|r 创建宏【%s】失败！", macroName))
        return
    end

    ClearCursor()
    PickupMacro(macroName)

    local cursorType = GetCursorInfo()
    if cursorType == "macro" then
        PlaceAction(targetSlot)
        ClearCursor()
        print(string.format("|cFF00FF00[队伍助手]|r 已成功将【%s】绑定至动作条 2！", macroName))
    else
        print(string.format("|cFFFF0000[队伍助手]|r 抓取宏【%s】失败！", macroName))
    end
end

-- 底部匿名勾选 + 快捷功能按钮
local AnonCheck = CreateFrame("CheckButton", nil, PartyFrame, "UICheckButtonTemplate")
AnonCheck:SetPoint("TOPLEFT", 10, -152)
AnonCheck.text = AnonCheck:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
AnonCheck.text:SetPoint("LEFT", AnonCheck, "RIGHT", 0, 0)
AnonCheck.text:SetText("匿名")

AnonCheck:SetScript("OnClick", function(self)
    InstanceTimerDB.isAnonymous = self:GetChecked()
    AddOn.UpdatePartyList()
end)

local btnSnowball = CreateFrame("Button", nil, PartyFrame, "UIPanelButtonTemplate")
btnSnowball:SetSize(56, 20)
btnSnowball:SetPoint("LEFT", AnonCheck.text, "RIGHT", 6, 0)
btnSnowball:SetText("雪球宏")
btnSnowball:SetScript("OnClick", function()
    local body = "#showtooltip 静滞砂砾\n/promote Teamos-熊猫酒仙\n/use 静滞砂砾\n/logout"
    CreateAndPlaceMacro("雪球", 134400, body, 61)
end)

local btnEnter = CreateFrame("Button", nil, PartyFrame, "UIPanelButtonTemplate")
btnEnter:SetSize(56, 20)
btnEnter:SetPoint("LEFT", btnSnowball, "RIGHT", 4, 0)
btnEnter:SetText("进本宏")
btnEnter:SetScript("OnClick", function()
    local body = "/click LFGDungeonReadyDialogEnterDungeonButton"
    CreateAndPlaceMacro("进本", 134400, body, 66)
end)

local btnLedger = CreateFrame("Button", nil, PartyFrame, "UIPanelButtonTemplate")
btnLedger:SetSize(48, 20)
btnLedger:SetPoint("LEFT", btnEnter, "RIGHT", 4, 0)
btnLedger:SetText("账本")
btnLedger:SetScript("OnClick", function()
    local editBox = ChatFrame1EditBox
    if editBox then
        local text = editBox:GetText()
        editBox:SetText("/gbt")
        ChatEdit_SendText(editBox)
        editBox:SetText(text)
    end
end)

-- 刷新队伍列表
function AddOn.UpdatePartyList()
    local units = {"player", "party1", "party2", "party3", "party4"}
    local isAnon = InstanceTimerDB and InstanceTimerDB.isAnonymous

    for i = 1, 5 do
        local unit = units[i]
        local row = memberRows[i]

        if UnitExists(unit) then
            local fullName, shortName = GetUnitNameFormatted(unit)
            local level = UnitLevel(unit)
            local _, classFile = UnitClass(unit)
            local color = classFile and RAID_CLASS_COLORS[classFile] or {r=1, g=1, b=1}

            if isAnon then
                row.nameText:SetText(string.format("|cff888888party%d|r", i))
            else
                row.nameText:SetText(string.format("|cff%02x%02x%02x%s|r", color.r*255, color.g*255, color.b*255, shortName))
            end

            row.levelText:SetText(string.format("|cffffd100%d级|r", level))

            row.removeBtn:SetScript("OnClick", function()
                if unit == "player" then
                    if C_PartyInfo and C_PartyInfo.LeaveParty then
                        C_PartyInfo.LeaveParty()
                    elseif LeaveParty then LeaveParty() end
                else
                    if C_PartyInfo and C_PartyInfo.UninviteUnit then
                        C_PartyInfo.UninviteUnit(fullName)
                    elseif UninviteUnit then UninviteUnit(fullName) end
                end
            end)

            row:Show()
        else
            row:Hide()
        end
    end
end

-- 显隐切换控制函数
TogglePartyFrame = function(state)
    if state == nil then
        state = not PartyFrame:IsShown()
    end
    
    if state then
        AddOn.UpdatePartyList()
        PartyFrame:Show()
        togglePartyText:SetText("▲")
    else
        PartyFrame:Hide()
        togglePartyText:SetText("▼")
    end
    if InstanceTimerDB then
        InstanceTimerDB.showPartyFrame = state
    end
end

-- ==================== 4. 确认弹窗注册 ====================

StaticPopupDialogs["INSTANCE_TIMER_CONFIRM_RESET_COUNT"] = {
    text = "确定要重置副本完成次数统计吗？",
    button1 = "重置次数",
    button2 = "取消",
    OnAccept = function()
        InstanceTimerDB.runCount = 0
        UpdateCounterDisplay()
        print("|cff00ff00[副本计时器]|r 副本完成次数已重置为 0。")
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

StaticPopupDialogs["INSTANCE_TIMER_CONFIRM_RESET_TIME"] = {
    text = "确定要重置当前计时器吗？",
    button1 = "重置计时",
    button2 = "取消",
    OnAccept = function()
        isTiming = false
        isPaused = false
        pendingStartOnLoadEnd = false
        startTime = 0
        accumulatedTime = 0
        timerText:SetTextColor(0, 1, 0.5, 1)
        timerText:SetText("00:00:00")
        print("|cff00ff00[副本计时器]|r 计时器已重置。")
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

-- ==================== 5. 通关历史 UI 面板 ====================

local historyFrame = CreateFrame("Frame", "InstanceTimerHistoryFrame", UIParent, "BasicFrameTemplateWithInset")
historyFrame:SetSize(360, 320)
historyFrame:SetPoint("CENTER", 0, 0)
historyFrame:SetMovable(true)
historyFrame:EnableMouse(true)
historyFrame:RegisterForDrag("LeftButton")
historyFrame:SetScript("OnDragStart", historyFrame.StartMoving)
historyFrame:SetScript("OnDragStop", historyFrame.StopMovingOrSizing)
historyFrame:Hide()

if historyFrame.TitleText then historyFrame.TitleText:SetText("副本通关历史记录") end

local scrollFrame = CreateFrame("ScrollFrame", nil, historyFrame, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", historyFrame, "TOPLEFT", 12, -32)
scrollFrame:SetPoint("BOTTOMRIGHT", historyFrame, "BOTTOMRIGHT", -32, 40)

local scrollContent = CreateFrame("Frame", nil, scrollFrame)
scrollContent:SetSize(300, 1)
scrollFrame:SetScrollChild(scrollContent)

local clearBtn = CreateFrame("Button", nil, historyFrame, "UIPanelButtonTemplate")
clearBtn:SetSize(90, 22)
clearBtn:SetPoint("BOTTOMRIGHT", historyFrame, "BOTTOMRIGHT", -12, 10)
clearBtn:SetText("清空历史")
clearBtn:SetScript("OnClick", function()
    InstanceTimerDB.history = {}
    UpdateHistoryUI()
    print("|cff00ff00[副本计时器]|r 历史记录已清空。")
end)

local rowPool = {}
UpdateHistoryUI = function()
    if not historyFrame:IsShown() then return end
    for _, row in ipairs(rowPool) do row:Hide() end

    local history = InstanceTimerDB.history or {}
    local rowHeight = 24
    scrollContent:SetHeight(math.max(#history * rowHeight, 1))

    for i, rec in ipairs(history) do
        local row = rowPool[i]
        if not row then
            row = CreateFrame("Frame", nil, scrollContent)
            row:SetSize(295, 22)
            local txt = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            txt:SetPoint("LEFT", 4, 0)
            txt:SetPoint("RIGHT", -4, 0)
            txt:SetJustifyH("LEFT")
            row.txt = txt
            rowPool[i] = row
        end

        row:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 0, -(i - 1) * rowHeight)
        row.txt:SetText(string.format("|cff808080[%s]|r |cffffd100%s|r: |cff00ff00%s|r", 
            rec.date or "--", rec.instance or "副本", rec.timeStr or "00:00:00"))
        row:Show()
    end
end

historyFrame:SetScript("OnShow", UpdateHistoryUI)

local function SaveRecord(instanceName, seconds, modeText)
    InstanceTimerDB.history = InstanceTimerDB.history or {}
    table.insert(InstanceTimerDB.history, 1, {
        date = date("%m-%d %H:%M"),
        instance = instanceName or "未知副本",
        timeStr = FormatTime(seconds),
        seconds = seconds,
        mode = modeText
    })

    local maxCount = InstanceTimerDB.maxRecords or 10
    while #InstanceTimerDB.history > maxCount do table.remove(InstanceTimerDB.history) end
    UpdateHistoryUI()
end

-- ==================== 6. 核心计时与判断逻辑 ====================

local function ResetTimer()
    isTiming = false
    isPaused = false
    pendingStartOnLoadEnd = false
    startTime = 0
    accumulatedTime = 0
    timerText:SetTextColor(0, 1, 0.5, 1)
    timerText:SetText("00:00:00")
end

local function StartTimer(reason)
    ResetTimer()
    startTime = GetTime()
    isTiming = true
    local modeDesc = (InstanceTimerDB.mode == 1) and "进入副本" or "进入战斗"
    print(string.format("|cff00ff00[副本计时器]|r 开始计时（%s，模式：%s）", reason, modeDesc))
end

local function ToggleTimerState()
    if not isTiming then
        StartTimer("手动开启")
        return
    end

    if isPaused then
        isPaused = false
        startTime = GetTime()
        timerText:SetTextColor(0, 1, 0.5, 1)
        print("|cff00ff00[副本计时器]|r 继续计时")
    else
        isPaused = true
        accumulatedTime = accumulatedTime + (GetTime() - startTime)
        timerText:SetTextColor(1, 0.8, 0, 1)
        print("|cffffcc00[副本计时器]|r 计时已暂停")
    end
end

local function ToggleCounterState()
    InstanceTimerDB.counterActive = not InstanceTimerDB.counterActive
    UpdateCounterDisplay()
    if InstanceTimerDB.counterActive then
        print("|cff00ff00[副本计时器]|r 副本次数统计已【开启】")
    else
        print("|cffffcc00[副本计时器]|r 副本次数统计已【暂停】")
    end
end

local function SafeSendChatMessage(msg)
    print("|cff00ff00[副本计时器]|r " .. msg)
    if not InstanceTimerDB or not InstanceTimerDB.announce then return end

    local function trySend(attempt)
        if InCombatLockdown() then
            if attempt < 5 then C_Timer.After(1.0, function() trySend(attempt + 1) end) end
            return
        end
        local channel = IsInGroup(LE_PARTY_CATEGORY_INSTANCE) and "INSTANCE_CHAT" 
            or IsInRaid() and "RAID" 
            or IsInGroup() and "PARTY"
        if channel then SendChatMessage(msg, channel) end
    end
    trySend(1)
end

local function StopAndAnnounce()
    if not isTiming then return end

    local now = time()
    if now - lastAnnounceTime < 5 then return end
    lastAnnounceTime = now

    local totalElapsed = isPaused and accumulatedTime or ((GetTime() - startTime) + accumulatedTime)
    isTiming = false

    local timeStr = FormatTime(totalElapsed)
    local modeText = (InstanceTimerDB.mode == 1) and "进本到通关" or "首战到通关"
    local instanceName = GetInstanceInfo() or "副本"

    local countMsg = ""
    if InstanceTimerDB.counterActive then
        InstanceTimerDB.runCount = (InstanceTimerDB.runCount or 0) + 1
        UpdateCounterDisplay()
        countMsg = string.format("[已完成 %d 次]", InstanceTimerDB.runCount)
    else
        countMsg = "[次数统计已暂停]"
    end

    SaveRecord(instanceName, totalElapsed, modeText)
    SafeSendChatMessage(string.format("【副本通关】%s 通关！耗时：%s（%s）%s", instanceName, timeStr, modeText, countMsg))
end

-- 尾王判定
local cachedInstanceName = nil
local cachedJournalInstanceID = nil

local function IsFinalEncounter(killedEncounterID, killedEncounterName)
    local instanceName = GetInstanceInfo()
    if not instanceName or instanceName == "" then return false end

    local targetFinalBoss = KNOWN_FINAL_BOSSES[instanceName]
    if targetFinalBoss then
        if type(targetFinalBoss) == "number" and killedEncounterID == targetFinalBoss then return true
        elseif type(targetFinalBoss) == "string" and killedEncounterName == targetFinalBoss then return true end
    end

    if cachedInstanceName ~= instanceName then
        cachedInstanceName = instanceName
        cachedJournalInstanceID = nil
        if EJ_GetNumTiers then
            for tier = 1, EJ_GetNumTiers() do
                if pcall(EJ_SelectTier, tier) then
                    local index = 1
                    while true do
                        local id, name = EJ_GetInstanceByIndex(index, false)
                        if not id then break end
                        if name == instanceName then cachedJournalInstanceID = id; break end
                        index = index + 1
                    end
                    if cachedJournalInstanceID then break end
                end
            end
        end
    end

    if cachedJournalInstanceID then
        pcall(EJ_SelectInstance, cachedJournalInstanceID)
        local lastBossID, lastBossName, bossCount, index = nil, nil, 0, 1
        if EJ_GetEncounterInfoByIndex then
            while true do
                local name, _, _, _, _, _, dEncounterID = EJ_GetEncounterInfoByIndex(index)
                if not name then break end
                if dEncounterID then lastBossID = dEncounterID; lastBossName = name; bossCount = bossCount + 1 end
                index = index + 1
            end
        end
        if bossCount >= 2 then
            if killedEncounterID and lastBossID then return killedEncounterID == lastBossID
            elseif killedEncounterName and lastBossName then return killedEncounterName == lastBossName end
        end
    end
    return false
end

-- ==================== 7. 右键菜单与交互点击 ====================

OpenContextMenu = function(anchor)
    if MenuUtil and MenuUtil.CreateContextMenu then
        MenuUtil.CreateContextMenu(anchor, function(ownerRegion, rootDescription)
            rootDescription:CreateTitle("副本计时器 设置")
            rootDescription:CreateCheckbox("展开/收起 队伍信息面板",
                function() return PartyFrame:IsShown() end,
                function() TogglePartyFrame() end)
            rootDescription:CreateButton("查看 / 隐藏历史记录", function() historyFrame:SetShown(not historyFrame:IsShown()) end)

            rootDescription:CreateRadio("模式1：过图结束1秒后开始计时",
                function() return InstanceTimerDB.mode == 1 end,
                function() InstanceTimerDB.mode = 1; print("|cff00ff00[副本计时器]|r 已切换为模式 1") end)

            rootDescription:CreateRadio("模式2：首次战斗开始计时",
                function() return InstanceTimerDB.mode == 2 end,
                function() InstanceTimerDB.mode = 2; print("|cff00ff00[副本计时器]|r 已切换为模式 2") end)

            rootDescription:CreateCheckbox("开启次数统计自动累加",
                function() return InstanceTimerDB.counterActive end,
                function() ToggleCounterState() end)

            rootDescription:CreateCheckbox("开启小队频道通报",
                function() return InstanceTimerDB.announce end,
                function() InstanceTimerDB.announce = not InstanceTimerDB.announce end)

            rootDescription:CreateButton("重置当前计时", function() StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_TIME") end)
            rootDescription:CreateButton("重置完成次数", function() StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_COUNT") end)
        end)
    elseif EasyMenu then
        local menu = {
            { text = "副本计时器 设置", isTitle = true, notCheckable = true },
            { text = "展开/收起 队伍信息面板", checked = function() return PartyFrame:IsShown() end, func = function() TogglePartyFrame() end },
            { text = "查看 / 隐藏历史记录", notCheckable = true, func = function() historyFrame:SetShown(not historyFrame:IsShown()) end },
            { text = "模式1：过图结束1秒后开始计时", checked = function() return InstanceTimerDB.mode == 1 end, func = function() InstanceTimerDB.mode = 1 end },
            { text = "模式2：首次战斗开始计时", checked = function() return InstanceTimerDB.mode == 2 end, func = function() InstanceTimerDB.mode = 2 end },
            { text = "开启次数统计自动累加", checked = function() return InstanceTimerDB.counterActive end, func = function() ToggleCounterState() end },
            { text = "开启小队频道通报", checked = function() return InstanceTimerDB.announce end, func = function() InstanceTimerDB.announce = not InstanceTimerDB.announce end },
            { text = "重置当前计时", notCheckable = true, func = function() StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_TIME") end },
            { text = "重置完成次数", notCheckable = true, func = function() StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_COUNT") end },
        }
        EasyMenu(menu, CreateFrame("Frame", nil, UIParent, "UIDropDownMenuTemplate"), "cursor", 0, 0, "MENU")
    end
end

timerBtn:SetScript("OnClick", function(self, button)
    if timerFrame.isDragging then return end
    if button == "LeftButton" then
        ToggleTimerState()
    elseif button == "RightButton" then
        if IsShiftKeyDown() then OpenContextMenu(timerFrame)
        else StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_TIME") end
    end
end)

countBtn:SetScript("OnClick", function(self, button)
    if timerFrame.isDragging then return end
    if button == "LeftButton" then
        ToggleCounterState()
    elseif button == "RightButton" then
        if IsShiftKeyDown() then OpenContextMenu(timerFrame)
        else StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_COUNT") end
    end
end)

-- Hover 提示
timerBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:AddLine("副本计时器 - 计时区域", 1, 1, 1)
    GameTooltip:AddLine("左键：开启 / 暂停 / 继续计时", 0, 1, 0)
    GameTooltip:AddLine("右键：弹窗重置当前计时器", 1, 0.3, 0.3)
    GameTooltip:AddLine("Shift + 右键：打开详细设置菜单", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("Alt + 左键：拖动悬浮窗位置", 0.5, 0.5, 0.5)
    GameTooltip:Show()
end)
timerBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

countBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:AddLine("副本计时器 - 次数统计区域", 1, 1, 1)
    GameTooltip:AddLine("左键：开启 / 暂停 次数自动累计", 0, 1, 0)
    GameTooltip:AddLine("右键：弹窗重置完成次数", 1, 0.3, 0.3)
    GameTooltip:AddLine("Shift + 右键：打开详细设置菜单", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("Alt + 左键：拖动悬浮窗位置", 0.5, 0.5, 0.5)
    GameTooltip:Show()
end)
countBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

-- ==================== 8. 事件监听 ====================

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("LOADING_SCREEN_DISABLED")
eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
eventFrame:RegisterEvent("ENCOUNTER_START")
eventFrame:RegisterEvent("ENCOUNTER_END")
eventFrame:RegisterEvent("LFG_COMPLETION_REWARD")
eventFrame:RegisterEvent("SCENARIO_COMPLETED")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("UNIT_LEVEL")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == ADDON_NAME then
            InstanceTimerDB = InstanceTimerDB or {}
            for k, v in pairs(defaultDB) do
                if InstanceTimerDB[k] == nil then InstanceTimerDB[k] = v end
            end

            UpdateCounterDisplay()
            AnonCheck:SetChecked(InstanceTimerDB.isAnonymous)

            if InstanceTimerDB.pos then
                timerFrame:ClearAllPoints()
                timerFrame:SetPoint(InstanceTimerDB.pos.point or "CENTER", UIParent, InstanceTimerDB.pos.point or "CENTER", InstanceTimerDB.pos.x or 0, InstanceTimerDB.pos.y or 200)
            end

            TogglePartyFrame(InstanceTimerDB.showPartyFrame)
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        local isInitialLogin, isReloading = ...
        local isInstance, instanceType = IsInInstance()
        inInstance = isInstance and (instanceType == "party" or instanceType == "raid")

        if inInstance then
            if not isReloading then
                ResetTimer()
                if InstanceTimerDB.mode == 1 then pendingStartOnLoadEnd = true end
            end
        else
            ResetTimer()
        end

        if PartyFrame:IsShown() then AddOn.UpdatePartyList() end

    elseif event == "GROUP_ROSTER_UPDATE" or event == "UNIT_LEVEL" then
        if PartyFrame:IsShown() then AddOn.UpdatePartyList() end

    elseif event == "LOADING_SCREEN_DISABLED" then
        if inInstance and pendingStartOnLoadEnd then
            pendingStartOnLoadEnd = false
            C_Timer.After(1.0, function()
                if inInstance and InstanceTimerDB.mode == 1 and not isTiming then
                    StartTimer("过图蓝条加载完毕(延迟1秒)")
                end
            end)
        end

    elseif event == "PLAYER_REGEN_DISABLED" or event == "ENCOUNTER_START" then
        if inInstance and InstanceTimerDB.mode == 2 and not isTiming then
            StartTimer("进入战斗/Boss开战")
        end

    elseif event == "ENCOUNTER_END" then
        local encounterID, encounterName, difficultyID, groupSize, success = ...
        if inInstance and isTiming and success == 1 then
            if IsFinalEncounter(encounterID, encounterName) then
                StopAndAnnounce()
            end
        end

    elseif event == "LFG_COMPLETION_REWARD" or event == "SCENARIO_COMPLETED" or event == "CHALLENGE_MODE_COMPLETED" then
        if inInstance and isTiming then
            StopAndAnnounce()
        end
    end
end)

-- ==================== 9. 斜杠命令 ====================

SLASH_INSTANCETIMER1 = "/it"
SlashCmdList["INSTANCETIMER"] = function(msg)
    local cmd = string.lower(strtrim(msg or ""))
    if cmd == "reset" then
        StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_TIME")
    elseif cmd == "resetcount" then
        StaticPopup_Show("INSTANCE_TIMER_CONFIRM_RESET_COUNT")
    elseif cmd == "pos" or cmd == "resetpos" then
        timerFrame:ClearAllPoints()
        timerFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        InstanceTimerDB.pos = { point = "CENTER", x = 0, y = 0 }
        print("|cff00ff00[副本计时器]|r 窗口位置已重置至屏幕中央。")
    elseif cmd == "history" or cmd == "h" then
        historyFrame:SetShown(not historyFrame:IsShown())
    elseif cmd == "party" or cmd == "p" then
        TogglePartyFrame()
    else
        print("|cff00ff00[副本计时器]|r 命令指南:")
        print("  /it pos - 重置计时器位置到屏幕中央")
        print("  /it party (或 /it p) - 展开/收起队伍面板")
        print("  /it history (或 /it h) - 查看/隐藏历史面板")
        print("  /it reset - 重置当前计时器")
        print("  /it resetcount - 重置副本完成次数统计")
    end
end
SLASH_PARTYHELPER1 = "/ph"
SlashCmdList["PARTYHELPER"] = function()
    TogglePartyFrame()
end